"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[7644],{94475:function(e,t,a){a.d(t,{G:function(){return d}});var i=a(52322),r=a(72779),n=a.n(r),o=a(2784),s=a(19596),l=a(88169),c=a(86704);let d=e=>{let{palette:{baseColor:t}}=(0,o.useContext)(l.ThemeContext),{title:a,message:r,className:s,action:c,displayType:d}=e;return(0,i.jsx)(g,{className:n()(s,t),baseColor:"none",children:(0,i.jsxs)("div",{className:"inner",children:[(0,i.jsx)("div",{className:"title",role:"alert",children:a}),!!e.message&&(0,i.jsx)("div",{className:"message",role:"alert",children:r}),!!c&&(0,i.jsx)("compact"===d?p:u,{children:c})]})})},p=s.ZP.div.withConfig({componentId:"sc-46b1addd-0"})(["margin-top:",";"],c.spacing.s),u=s.ZP.div.withConfig({componentId:"sc-46b1addd-1"})(["margin-top:",";"],c.spacing.l),g=(0,s.ZP)(l.PageSection).withConfig({componentId:"sc-46b1addd-2"})([".inner{max-width:480px;margin:0 auto;text-align:center;}.message{margin-top:",";}&.base{.title{",";}.message{",";}}&.baseColor{.title{",";}.message{",";}}"],c.spacing.m,(0,c.setPropertyToColorVar)("color","ipt-on-base-textPrimary-color"),(0,c.setPropertyToColorVar)("color","ipt-on-base-textSecondary-color"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color"))},64072:function(e,t,a){a.d(t,{w:function(){return n}});var i=a(30382),r=a.n(i);let n=r()`
    fragment ImageListItemMetadata on Image {
        id
        url
        height
        width
        caption {
            plainText
        }
        names(limit: 4) {
            id
            nameText {
                text
            }
        }
        titles(limit: 1) {
            id
            titleText {
                text
            }
            originalTitleText {
                text
            }
            releaseYear {
                year
                endYear
            }
        }
    }
`},88758:function(e,t,a){a.d(t,{E:function(){return n},k:function(){return o}});var i=a(30382),r=a.n(i);let n=r()`
    fragment NameListItemMetadata on Name {
        id
        primaryImage {
            url
            caption {
                plainText
            }
            width
            height
        }
        nameText {
            text
        }
        primaryProfessions {
            category {
                text
            }
        }
        # IMDB_WEB_PACE_SPECIFIC_PROFESSIONS_DISPLAY_1112523
        professions {
            profession {
                text
            }
        }
        knownForV2(limit: 1) @include(if: $isInPace) {
            credits {
                title {
                    id
                    originalTitleText {
                        text
                    }
                    titleText {
                        text
                    }
                    titleType {
                        canHaveEpisodes
                    }
                    releaseYear {
                        year
                        endYear
                    }
                }
                episodeCredits(first: 0) {
                    yearRange {
                        year
                        endYear
                    }
                }
            }
        }
        knownFor(first: 1) {
            edges {
                node {
                    summary {
                        yearRange {
                            year
                            endYear
                        }
                    }
                    title {
                        id
                        originalTitleText {
                            text
                        }
                        titleText {
                            text
                        }
                        titleType {
                            canHaveEpisodes
                        }
                    }
                }
            }
        }
        bio {
            displayableArticle {
                body {
                    plaidHtml(
                        queryParams: $refTagQueryParam
                        showOriginalTitleText: $originalTitleText
                    )
                }
            }
        }
    }
`,o=r()`
    fragment NameMeterRanking on Name {
        meterRanking {
            currentRank
            rankChange {
                changeDirection
                difference
            }
        }
    }
`},36543:function(e,t,a){a.d(t,{$z:function(){return l},Dl:function(){return o},Zz:function(){return c},_A:function(){return d},f1:function(){return p},qp:function(){return u},vO:function(){return s}});var i=a(30382),r=a.n(i),n=a(85018);let o=r()`
    fragment TitleTopCastAndCrew on Title {
        id
        principalCredits(
            filter: { categories: ["cast", "director", "creator"] }
        ) {
            category {
                id
                text
            }
            credits {
                name {
                    id
                    nameText {
                        text
                    }
                }
            }
        }
        principalCreditsV2(filter: { mode: "NARROWED" }, useEntitlement: false)
            @include(if: $isInPace) {
            grouping {
                groupingId
                text
            }
            credits(limit: 4) {
                name {
                    id
                    nameText {
                        text
                    }
                }
            }
        }
    }
`,s=r()`
    fragment TitleMeterRanking on Title {
        meterRanking {
            currentRank
            rankChange {
                changeDirection
                difference
            }
        }
    }
`,l=r()`
    fragment TitleListItemMetadataEssentials on Title {
        ...BaseTitleCard
        series {
            series {
                id
                originalTitleText {
                    text
                }
                releaseYear {
                    endYear
                    year
                }
                titleText {
                    text
                }
            }
        }
    }
    ${n.sq}
`,c=r()`
    fragment TitleListItemMetadata on Title {
        ...TitleListItemMetadataEssentials
        latestTrailer {
            id
        }
        plot {
            plotText {
                plainText
            }
        }
        releaseDate {
            day
            month
            year
        }
        productionStatus {
            currentProductionStage {
                id
                text
            }
        }
    }
    ${l}
`,d=r()`
    fragment TitleListItemMetascore on Title {
        metacritic {
            metascore {
                score
            }
        }
    }
`,p=r()`
    fragment TitleTotalEpisodes on Title {
        episodes {
            episodes(first: 0) {
                total
            }
        }
    }
`,u=r()`
    fragment TitleListFacetFields on TitleListItemSearchConnection {
        genres: facet(facetField: GENRES) {
            filterId
            text
            total
        }

        keywords: facet(facetField: KEYWORDS) {
            filterId
            text
            total
        }

        watchOptions: facet(facetField: WATCH_PROVIDERS) {
            filterId
            text
            total
        }

        titleTypes: facet(facetField: TITLE_TYPE) {
            filterId
            text
            total
        }
    }
`},97149:function(e,t,a){a.d(t,{X:function(){return n}});var i=a(30382),r=a.n(i);let n=r()`
    fragment VideoListItemMetadata on Video {
        id
        thumbnail {
            url
            width
            height
        }
        name {
            value
            language
        }
        description {
            value
            language
        }
        runtime {
            unit
            value
        }
        primaryTitle {
            id
            originalTitleText {
                text
            }
            titleText {
                text
            }
            titleType {
                canHaveEpisodes
            }
            releaseYear {
                year
                endYear
            }
        }
    }
`},68283:function(e,t,a){a.d(t,{_q:function(){return b},ZP:function(){return P}});var i=a(52322),r=a(72779),n=a.n(r),o=a(2784),s=a(9162),l=a(53665),c=a(19596),d=a(27722),p=a(11438),u=a(14438);let g={CREDIT_CHANGE:p.Cd.FILMOGRAPHY,"CONTACT_CHANGE|CONTACT__RELATIONSHIP_TYPE|REPRESENTATION":p.Cd.REPRESENTATION,EMPLOYMENT_CHANGE:p.Cd.EMPLOYMENT,"CONTACT_CHANGE|CONTACT__RELATIONSHIP_TYPE|CLIENT":p.Cd.CLIENTS,NEWS_ADDITION:p.Cd.NEWS};var m=a(17503),T=a(11602);let f=()=>{let[e,t]=(0,m.Z)(T.Vc),a=async e=>t(e);return{success:e.data?.untrackConst?.success,error:e.error,fetching:e.fetching,updateUntrackingForConst:a}},C=()=>{let[e,t]=(0,m.Z)(T.qb),a=async e=>t(e);return{success:e.data?.trackConst?.success,error:e.error,fetching:e.fetching,updateTrackingForConst:a}},I=e=>{let[t,a]=(0,o.useState)(e),[i,r]=(0,o.useState)(!1),{updateTrackingForConst:n}=C(),{updateUntrackingForConst:s}=f(),l=async e=>{if(!1===e.isTracking&&!1!==t.isTracking){r(!0);let e=await s({input:{id:t.id}}),i={...t,isTracking:!1};e.data?.untrackConst?.success&&a(i),r(!1)}else if(!0===e.isTracking&&!1===t.isTracking){r(!0);let e=t.notificationPreferences?.map(e=>({...e,interested:!0})),i=await n({input:{id:t.id,notificationTypeStates:e?.map(e=>{let{interested:t,type:a}=e;return{typeId:a.typeId,interested:t}})}});i.data?.trackConst?.success&&a({...t,isTracking:!0,notificationPreferences:e}),r(!1)}else if(!0===e.isTracking&&e.notificationPreferences!==t.notificationPreferences){r(!0);let i={...t,isTracking:!0,notificationPreferences:t.notificationPreferences?.map(t=>{let a=t;return e.notificationPreferences?.map(e=>{e.type.typeId===t.type.typeId&&e.interested!==t.interested&&(a=e)}),a})},o=await n({input:{id:t.id,notificationTypeStates:i.notificationPreferences?.map(e=>({typeId:e.type.typeId,interested:e.interested}))}});o.data?.trackConst?.success&&a(i),r(!1)}};return{state:t,updateTracking:l,isFetching:i}},x={TRACK:{id:"pro_name_page_shared_connections_track",defaultMessage:"Track"},TRACKING:{id:"pro_name_page_shared_connections_tracking",defaultMessage:"Tracking"},STOP_TRACKING:{id:"pro_name_page_shared_connections_stop_tracking",defaultMessage:"Stop tracking"}},h={track:"track",trackButton:"track-on",trackMenu:"track-menu-open"},b="protrackbutton--tracking--post-icon",E=e=>{let t,{id:a,data:r,buttonProps:c,buttonType:m="button",displayTrackOptionsMenu:T=!0,className:f}=e,C=(0,l.Z)(),E=(0,u.EO)(),{state:{isTracking:P,notificationPreferences:k},updateTracking:M,isFetching:N}=I({id:a,isTracking:r?.isTracking||!1,notificationPreferences:r?.notificationPreferences||[]}),[S,A]=(0,o.useState)(!1),v={className:n()(c?.className,T?void 0:f),onColor:void 0};switch(m){case"secondaryButton":t=d.SecondaryButton,v.onColor="accent2";break;case"textButton":t=d.TextButton,v.onColor="accent2";break;default:t=d.Button}let R={},$=T?y:o.Fragment;T&&(R.className=f);let O=()=>E({pageAction:`${h.trackButton}-${a}`,refMarkerSuffix:p.Cd.EMPTY}),V=()=>E({pageAction:h.trackMenu,refMarkerSuffix:p.Cd.EMPTY}),w=()=>E({pageAction:`${h.track}-${p.Cd.OFF}-${a}`,refMarkerSuffix:p.Cd.MENU}),j=(e,t)=>{let a=g[e],i=t?p.Cd.OFF:p.Cd.ON;E({pageAction:`${a}-${i}`,refMarkerSuffix:p.Cd.MENU})};return(0,i.jsxs)($,{...R,children:[!!N&&(0,i.jsx)(t,{...c,...v,children:(0,i.jsx)(d.Loader,{})}),!N&&(0,i.jsx)(t,{onSelect:()=>{P?(V(),T?A(!S):M({isTracking:!1})):(O(),M({isTracking:!0}))},preIcon:P?"notifications-add-check":"notifications-add",postIcon:P&&T?"arrow":void 0,postIconClassName:P&&T?b:void 0,...c,...v,children:P?C.formatMessage(x.TRACKING):C.formatMessage(x.TRACK)}),!!P&&!!T&&(0,i.jsx)(d.SetPalette,{palette:"light",children:(0,i.jsx)(L,{isVisible:S,mode:"absolute",expandFrom:"top-right",children:(0,i.jsx)(s.Y,{onEscapeKey:()=>A(!1),onClickOutside:()=>A(!1),children:(0,i.jsxs)(d.MenuList,{children:[k?.map(e=>{let{type:t,interested:a}=e;return i.jsx(_,{onClick:()=>{j(t.typeId,a),M({isTracking:!0,notificationPreferences:[{interested:!a,type:t}]})},preIconName:a?"checkbox-checked":"checkbox-unchecked",preIconProps:{name:a?"checkbox-checked":"checkbox-unchecked",spanClassName:"checkbox-icon"},children:t.text},t.text)}),(0,i.jsx)(d.MenuListDivider,{}),(0,i.jsx)(d.MenuListItem,{onClick:()=>{w(),A(!1),M({isTracking:!1})},children:C.formatMessage(x.STOP_TRACKING)})]})})})})]})};var P=e=>(0,i.jsx)(p.xm,{value:p.Cd.TRACK,children:(0,i.jsx)(E,{...e})});let y=c.ZP.div.withConfig({componentId:"sc-7fbe872c-0"})(["position:relative;"]),_=(0,c.ZP)(d.MenuListItem).withConfig({componentId:"sc-7fbe872c-1"})([".checkbox-icon{","}"],(0,d.setPropertyToColorVar)("color","ipt-on-base-accent2-color")),L=(0,c.ZP)(d.Menu).withConfig({componentId:"sc-7fbe872c-2"})(["right:0;top:100%;"])},11602:function(e,t,a){a.d(t,{Vc:function(){return o},qb:function(){return n},vW:function(){return s}});var i=a(30382),r=a.n(i);let n=r()`
    mutation TrackConst($input: SetTrackNotificationPreferencesInput!) {
        trackConst(input: $input) {
            constId
            message {
                language
                value
            }
            success
        }
    }
`,o=r()`
    mutation UntrackConst($input: UntrackConstInput!) {
        untrackConst(input: $input) {
            constId
            message {
                language
                value
            }
            success
        }
    }
`,s=r()`
    fragment TrackPreferences on TrackNotificationPreferences {
        isTracking
        notificationPreferences {
            interested
            type {
                text
                typeId
            }
        }
    }
`},96557:function(e,t,a){a.d(t,{Z:function(){return U}});var i=a(52322),r=a(14973),n=a(30382),o=a.n(n),s=a(2784),l=a(53665),c=a(19596),d=a(88169),p=a(86704),u=a(31885),g=a(20608),m=a(84314),T=a(49666),f=a(49996),C=a(4363),I=a(66724),x=a(11438),h=a(37179),b=a(6935),E=a(14438),P=a(1833),y=a(94475),_=a(67353),L=a(22619),k=a(25436),M=a(75824),N=a(75808);let S=o()`
    fragment AddConstToListMenuItem on List {
        id
        name {
            originalText
        }
    }
`,A=e=>{let{value:t}=(0,x.Lz)(),{listMainLinkBuilder:a}=(0,I.WOb)(),{palette:{baseColor:r}}=(0,s.useContext)(d.ThemeContext),{constId:n,onError:o}=e,{pageType:l}=(0,f.y)(),c=(0,T.ik)()&&l===k.PageType.NAME,p=e.listData.id,u=e.listData.name?.originalText||"",g=(0,M.N)({id:"addConstToListMenuItem_goToList_ariaLabel",defaultMessage:"Go to list: {listTitle}"},{listTitle:u}),m=(0,M.N)({id:"user_your_checkins",defaultMessage:"Your Check-Ins"}),[C,h]=(0,s.useState)(e.isElementInList),{addConstToList:b,removeConstFromList:E}=(0,N.j8)({overrideRefTag:c?t+`_${p}`:t}),{addToWatchedTitles:P}=(0,L.V)(),{executeAddConstToList:y,addConstToListResult:S}=b,{executeRemoveConstFromList:A,removeConstFromListResult:v}=E,R=S?.error||v?.error,D=()=>{C?(A(p,n),h(!1)):(y(p,n),h(!0),"CHECK_INS"===e.listClass&&P(n))};return R?(o(R),null):(0,i.jsxs)($,{children:[(0,i.jsxs)(O,{onClick:D,onKeyDown:e=>{(0,_.isEnterOrSpaceKey)(e)&&D()},role:"button",tabIndex:0,"data-titleinlist":C,className:r,children:[!!C&&(0,i.jsx)(w,{name:"playlist-add-check",className:r}),!C&&(0,i.jsx)(V,{name:"add"}),"CHECK_INS"===e.listClass?m:u]}),(0,i.jsx)(j,{href:a({lsconst:p,refSuffix:x.Cd.EMPTY}),"aria-label":g,className:r,children:(0,i.jsx)(d.Icon,{name:"chevron-right"})})]})};A.fragments={addConstToListMenuItem:S};let v=`
    &:focus {
        ${(0,p.focusOnBaseAlt)()}
    }

    &:hover {
        background: rgba(
            ${(0,p.getColorVarValue)("ipt-on-baseAlt-rgb")},
            ${(0,p.getColorVarValue)("ipt-baseAlt-hover-opacity")}
        );
        background: rgba(
            ${(0,p.getColorVar)("ipt-on-baseAlt-rgb")},
            ${(0,p.getColorVar)("ipt-baseAlt-hover-opacity")}
        );
    }

    &:active {
        background: rgba(
            ${(0,p.getColorVarValue)("ipt-on-baseAlt-rgb")},
            ${(0,p.getColorVarValue)("ipt-baseAlt-pressed-opacity")}
        );
        background: rgba(
            ${(0,p.getColorVar)("ipt-on-baseAlt-rgb")},
            ${(0,p.getColorVar)("ipt-baseAlt-pressed-opacity")}
        );
    }
`,R=`
    &:focus {
        ${(0,p.focusOnBase)()}
    }

    &:hover {
        background: rgba(
            ${(0,p.getColorVarValue)("ipt-on-base-rgb")},
            ${(0,p.getColorVarValue)("ipt-base-hover-opacity")}
        );
        background: rgba(
            ${(0,p.getColorVar)("ipt-on-base-rgb")},
            ${(0,p.getColorVar)("ipt-base-hover-opacity")}
        );
    }

    &:active {
        background: rgba(
            ${(0,p.getColorVarValue)("ipt-on-base-rgb")},
            ${(0,p.getColorVarValue)("ipt-base-pressed-opacity")}
        );
        background: rgba(
            ${(0,p.getColorVar)("ipt-on-base-rgb")},
            ${(0,p.getColorVar)("ipt-base-pressed-opacity")}
        );
    }
`,$=c.ZP.div.withConfig({componentId:"sc-ad2b51b3-0"})(["display:flex;align-items:center;width:100%;"]),O=c.ZP.div.withConfig({componentId:"sc-ad2b51b3-1"})(["flex-grow:1;cursor:pointer;padding:0.75rem 1rem 0.75rem 0.75rem;position:relative;text-overflow:ellipsis;overflow:hidden;word-break:break-all;white-space:nowrap;&::after{position:absolute;content:'';right:0;top:20%;height:60%;width:1px;}&.base::after{","}&.baseAlt::after{","}"],(0,p.setPropertyToColorVar)("background-color","ipt-base-border-color"),(0,p.setPropertyToColorVar)("background-color","ipt-baseAlt-border-color")),V=(0,c.ZP)(d.Icon).withConfig({componentId:"sc-ad2b51b3-2"})(["margin-right:0.5rem;"]),w=(0,c.ZP)(V).withConfig({componentId:"sc-ad2b51b3-3"})(["&.base{","}&.baseAlt{","}"],(0,p.setPropertyToColorVar)("color","ipt-on-base-accent4-color"),(0,p.setPropertyToColorVar)("color","ipt-on-baseAlt-accent4-color")),j=c.ZP.a.withConfig({componentId:"sc-ad2b51b3-4"})(["padding:0.75rem 1rem;flex-shrink:0;&.base{"," ","}&.baseAlt{"," ","}"],(0,p.setPropertyToColorVar)("color","ipt-on-base-textHint-color"),R,(0,p.setPropertyToColorVar)("color","ipt-on-baseAlt-textHint-color"),v),D={PROMPT_TITLE:{id:"common_add_to_list_buttonText",defaultMessage:"Add to list"},CREATE_LIST:{id:"addConstToListPrompt_label_createList",defaultMessage:"Create new list"},ERROR_TITLE:{id:"error_emptyStates_addConstToList_title",defaultMessage:"There was a problem. Please try again."},VIEW_WATCHLIST:{id:"common_label_viewWatchlist",defaultMessage:"View Watchlist"},SIGNED_OUT_ERROR_TITLE:{id:"error_signedOut_addConstToList_title",defaultMessage:"Sign in to create or view a list."},CLOSE_PROMPT_LABEL:{id:"common_ariaLabel_closePrompt",defaultMessage:"Close Prompt"},NO_LISTS_FOUND:{id:"addConstToListPrompt_no_lists_found",defaultMessage:"No lists found"}},Z={LOADER:"actlp-loader",ERROR:"actlp-error",CREATE_LIST:"actlp-creat-list",VIEW_WATCHLIST:"actlp-watchlist",NO_LIST:"actlp-no-list"},F="addConstToListPrompt__panel",W=o()`
    query ACTLP_Prompt(
        $count: Int!
        $constId: ID!
        $after: ID
        $listElementType: ListTypeId
        $classTypes: [ListClassId!]
    ) {
        lists(
            first: $count
            filter: {
                listElementType: $listElementType
                classTypes: $classTypes
            }
            after: $after
        ) {
            total
            edges {
                node {
                    ...AddConstToListMenuItem
                    isElementInList(itemElementId: $constId)
                    listClass {
                        id
                    }
                }
            }
            pageInfo {
                hasNextPage
                endCursor
            }
        }
    }
    ${A.fragments.addConstToListMenuItem}
`,Y={hasNextPage:!0,listItems:[],endCursor:null},H=e=>{let t,a;let{isOpen:n,onClose:o,primaryImage:c,primaryText:p,imageType:y}=e,_=c?.caption?.plainText||"",L=(0,m.n)(),k=(0,T.ik)(),M=(0,l.Z)(),{makeRefMarker:N}=(0,x.Lz)(),{listCreateLinkBuilder:S,listWatchlistLinkBuilder:v,registrationSignInLinkBuilder:R}=(0,I.WOb)(),{pageType:$,pageConst:O}=(0,f.y)(),V=e.constId||O,w=V?.startsWith("tt"),j=V?.startsWith("nm"),H=k?[u.JQJ.ProList]:[u.JQJ.CheckIns,u.JQJ.List],U=(0,E.EO)(),Q="poster";w&&(t=u.lZo.Titles),j&&(t=u.lZo.People,Q="avatar");let[z,J]=(0,s.useState)(Y),[X]=(0,C.E)({query:W,requestPolicy:"network-only",variables:{constId:V,count:100,after:z.endCursor,listElementType:t,classTypes:H},context:{serverSideCacheable:!1,personalized:!0},pause:!n||!L||!V}),[ee,et]=(0,s.useState)(void 0),ea=X.fetching,ei=X.error||ee,er=X.data?.lists?.total,en=$&&V?(0,i.jsx)(d.TextLink,{href:R({refSuffix:[x.Cd.LIST,x.Cd.MENU],query:{u:`/${$}/${V}/`}}),text:M.formatMessage(D.SIGNED_OUT_ERROR_TITLE)}):null,eo=M.formatMessage(D.ERROR_TITLE);(0,s.useEffect)(()=>{n&&!ea&&X.data?.lists&&z.hasNextPage&&J({listItems:X.data?.lists?.edges?z.listItems.concat(X.data.lists.edges):z.listItems,hasNextPage:X.data?.lists?.pageInfo?.hasNextPage,endCursor:X.data?.lists?.pageInfo?.endCursor})},[z.hasNextPage,X.data]),(0,s.useEffect)(()=>{if(n){U({pageAction:h.QJ.ADD_TO_LIST_OPEN,hitType:r.HitType.POP_UP,refMarkerSuffix:x.Cd.EMPTY});return}J({...Y})},[n]);let es=!ei&&n&&L&&er!==z.listItems.length;return(0,i.jsxs)(B,{"data-testid":"styled-list-prompt",isOpen:n,onCloseClicked:()=>{o(),U({pageAction:h.QJ.ADD_TO_LIST_CLOSE,hitType:r.HitType.POP_UP,refMarkerSuffix:x.Cd.EMPTY})},panelClassName:F,baseColor:k?"base":"baseAlt",header:(0,i.jsx)(G,{type:Q,subtitle:p,reverseTitleOrder:!0,title:M.formatMessage(D.PROMPT_TITLE),ariaLabel:_,imageModel:(0,b.K0)(c,_),imageType:y}),closePromptLabel:M.formatMessage(D.CLOSE_PROMPT_LABEL),children:[L?(0,i.jsxs)(d.MenuList,{children:[!!w&&!k&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(d.MenuListItem,{className:Z.VIEW_WATCHLIST,href:v({refSuffix:x.Cd.WATCHLIST}),postIconName:"chevron-right",children:(0,i.jsx)(g.q,{...D.VIEW_WATCHLIST})}),(0,i.jsx)(d.MenuListDivider,{})]}),(0,i.jsx)(d.MenuListItem,{className:Z.CREATE_LIST,href:k?(0,P.Ae)(`${P.Wr}/list/`,N(x.Cd.NEW),{}):S({refSuffix:x.Cd.NEW}),target:k?"_blank":void 0,postIconName:k?"launch":"chevron-right",children:(0,i.jsx)(g.q,{...D.CREATE_LIST})}),(0,i.jsx)(d.MenuListDivider,{}),!!ei&&(0,i.jsx)(K,{className:Z.ERROR,title:(a=ee,a?.graphQLErrors[0]?.extensions?.code==="FORBIDDEN")?en:eo}),!es&&0===z.listItems.length&&(0,i.jsx)(K,{className:Z.NO_LIST,title:(0,i.jsx)(g.q,{...D.NO_LISTS_FOUND})}),!ei&&!!V&&z.listItems.map(e=>(0,i.jsx)(A,{listData:e.node,listClass:e.node?.listClass?.id,isElementInList:e.node.isElementInList||!1,constId:V,onError:et},e.node.id))]}):(0,i.jsx)(K,{className:Z.ERROR,title:en}),!!es&&(0,i.jsx)(q,{"data-testid":Z.LOADER,children:(0,i.jsx)(d.Loader,{})})]})},B=(0,c.ZP)(d.Prompt).withConfig({componentId:"sc-c36b4240-0"})([".","{padding:0;",";min-height:18rem;}"],F,(0,p.setPropertyToShapeVar)("border-radius","ipt-cornerRadius")),G=(0,c.ZP)(d.PromptHeader).withConfig({componentId:"sc-c36b4240-1"})([""," ",""],(0,p.setPropertyToShapeVar)("border-top-left-radius","ipt-cornerRadius"),(0,p.setPropertyToShapeVar)("border-top-right-radius","ipt-cornerRadius")),K=(0,c.ZP)(y.G).withConfig({componentId:"sc-c36b4240-2"})([""," background:initial;min-height:7rem;padding:3rem;"],(0,p.setTypographyType)("body")),q=c.ZP.div.withConfig({componentId:"sc-c36b4240-3"})(["display:flex;min-height:7rem;justify-content:center;padding:3rem;"]);var U=e=>(0,i.jsx)(x.xm,{value:x.Cd.LIST,children:(0,i.jsx)(H,{...e})})},75808:function(e,t,a){a.d(t,{j8:function(){return h}});var i=a(30382),r=a.n(i),n=a(64072),o=a(88758),s=a(80032),l=a(36543),c=a(97149),d=a(25436),p=a(48687),u=a(86958),g=a(49666),m=a(11438),T=a(14438),f=a(83163),C=a(17503);let I="list-item-add",x="list-item-delete",h=e=>{let[t,a]=(0,C.Z)(b),[i,r]=(0,C.Z)(E),n=(0,u.B)().context,{makeRefMarker:o}=(0,m.Lz)(),s=(0,T.EO)(),l=(0,p.hg)({weblabID:f.lh.IMDB_WEB_PACE_CREDITS_1201882,treatments:{T1:!0}}),c=(0,g.ik)()&&n.pageType===d.PageType.NAME,h=!!n.sidecar?.localizationResponse.isOriginalTitlePreferenceSet;return{addConstToList:{executeAddConstToList:(t,i)=>{let r=e.overrideRefTag??o([m.Cd.ADD,m.Cd.ITEMS]);return s({refMarkerString:r,pageAction:e.overrideAddPageAction??(c?`${I}-${i}`:I),customPageMetadata:{id:i}}),a({listId:t,constId:i,includeListItemMetadata:!!e.includeListItemMetadata,refTagQueryParam:r,originalTitleText:h,isInPace:l})},addConstToListResult:t},removeConstFromList:{executeRemoveConstFromList:(t,a)=>(s({refMarkerString:e.overrideRefTag??o([m.Cd.DELETE,m.Cd.ITEMS]),pageAction:e.overrideRemovePageAction??(c?`${x}-${a}`:x),customPageMetadata:{id:a}}),r({listId:t,constId:a})),removeConstFromListResult:i}}},b=r()`
    mutation AddConstToList(
        $listId: ID!
        $constId: ID!
        $includeListItemMetadata: Boolean!
        $refTagQueryParam: String
        $originalTitleText: Boolean
        $isInPace: Boolean! = false
    ) {
        addItemToList(
            input: { listId: $listId, item: { itemElementId: $constId } }
        ) {
            listId
            modifiedItem {
                ...EditListItemMetadata
                listItem @include(if: $includeListItemMetadata) {
                    ... on Title {
                        ...TitleListItemMetadata
                    }
                    ... on Name {
                        ...NameListItemMetadata
                    }
                    ... on Image {
                        ...ImageListItemMetadata
                    }
                    ... on Video {
                        ...VideoListItemMetadata
                    }
                }
            }
        }
    }

    ${s.rc}
    ${l.Zz}
    ${o.E}
    ${n.w}
    ${c.X}
`,E=r()`
    mutation RemoveConstFromList($listId: ID!, $constId: ID!) {
        removeElementFromList(
            input: { listId: $listId, itemElementId: $constId }
        ) {
            listId
        }
    }
`}}]);