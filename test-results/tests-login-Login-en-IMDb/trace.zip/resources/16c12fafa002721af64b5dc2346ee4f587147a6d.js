"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4538],{85018:function(t,e,i){i.d(e,{F4:function(){return o},sq:function(){return r},uN:function(){return l}});var a=i(30382),n=i.n(a);let r=n()`
    fragment BaseTitleCard on Title {
        id
        titleText {
            text
        }
        titleType {
            id
            text
            canHaveEpisodes
            displayableProperty {
                value {
                    plainText
                }
            }
        }
        originalTitleText {
            text
        }
        primaryImage {
            id
            width
            height
            url
            caption {
                plainText
            }
        }
        releaseYear {
            year
            endYear
        }
        ratingsSummary {
            aggregateRating
            voteCount
        }
        runtime {
            seconds
        }
        certificate {
            rating
        }
        canRate {
            isRatable
        }
        titleGenres {
            genres(limit: 3) {
                genre {
                    text
                }
            }
        }
    }
`,o=n()`
    fragment TitleCardTrailer on Title {
        latestTrailer {
            id
        }
    }
`,l=n()`
    fragment PersonalizedTitleCardUserRating on Title {
        userRating @include(if: $includeUserRating) {
            value
        }
    }
`},40981:function(t,e,i){i.d(e,{Nf:function(){return p},z7:function(){return m}});var a=i(52322),n=i(86704),r=i(72779),o=i.n(r);i(2784);var l=i(53665),s=i(19596),d=i(88169),u=i(94471),g=i(92847);let m={CONTAINER:"ratingGroup--container",IMDB_RATING:"ratingGroup--imdb-rating",OTHER_USER_RATING:"ratingGroup--other-user-rating",PLACEHOLDER:"ratingGroup--placeholder",USER_RATING:"ratingGroup--user-rating"},c="hide-vote-count",f="standalone-star",p=t=>{let{canRate:e,className:i,hideMaxIMDbRating:n,hideVoteCountOnSmallBreakpoints:r,otherUserRating:s,titleId:p,ratingsSummary:h,rateButtonLabel:T,showPlaceholderStarIfApplicable:x,titleText:I,refOverride:b}=t,N=(0,l.Z)(),{rating:v}=(0,d.useRatingsContext)(p)||{},C=(0,u.P)(v,"user"),P=(0,u.P)(h?.aggregateRating,"imdb"),M=(0,u.P)(s,"user"),L=N.formatMessage({id:"common_ariaLabels_IMDbRating",defaultMessage:"IMDb rating: {rating}"},{rating:P||""}),E=N.formatMessage({id:"common_ariaLabels_other_user_rating",defaultMessage:"User rating: {value}"},{value:s}),S=N.formatMessage({id:"common_ariaLabels_ratingButtonRated",defaultMessage:"Your rating: {rating}"},{rating:C||""}),w=N.formatMessage({id:"common_ariaLabels_ratingButtonUnrated",defaultMessage:"Rate {titleName}"},{titleName:I}),$=N.formatMessage({id:"common_ratingPrompt_rate",defaultMessage:"Rate"}),y=h?.voteCount?N.formatNumber(h?.voteCount,{notation:"compact",compactDisplay:"short"}):void 0,U=x&&!P&&!(e&&I);return(0,a.jsxs)(R,{className:i,"data-testid":m.CONTAINER,children:[!!P&&(0,a.jsx)(d.RatingStar,{"data-testid":m.IMDB_RATING,ariaLabel:L,className:m.IMDB_RATING,formattedRating:P,maxRating:n?void 0:10,formattedVoteCount:y,voteCountClassName:r?c:""}),!!s&&(0,a.jsx)(d.RatingStar,{ariaLabel:E,className:m.OTHER_USER_RATING,"data-testid":m.OTHER_USER_RATING,formattedRating:M,type:"otherUser"}),!!e&&!!I&&(0,a.jsx)(g.T,{title:{id:p,titleText:I,canRate:e},refOverride:b,ratingTriggerComponent:t=>{let{onUserRatingClick:e}=t;return(0,a.jsx)(_,{ariaLabelRated:S,ariaLabelUnrated:w,formattedRating:C,className:o()(m.USER_RATING,{[f]:!P}),onClick:e,rateLabel:"string"==typeof T?T:$})}}),!!U&&(0,a.jsx)(d.RatingStar,{"data-testid":m.PLACEHOLDER,"aria-hidden":!0,className:o()(m.PLACEHOLDER,f),type:"placeholder"})]})},R=s.ZP.div.withConfig({componentId:"sc-17ce9e4b-0"})(["align-items:center;display:inline-flex;flex-flow:row wrap;flex-direction:row;gap:0 ",";.","{padding:0;min-width:0;}.","{","{display:none;}}"],n.spacing.xs,f,c,n.mediaQueries.breakpoints.below.m),_=(0,s.ZP)(d.RateButton).withConfig({componentId:"sc-17ce9e4b-1"})(["font-size:inherit;height:fit-content;padding:0;"])},92847:function(t,e,i){i.d(e,{T:function(){return T}});var a=i(52322),n=i(77725),r=i(2784),o=i(88169),l=i(44958),s=i(75824),d=i(82433),u=i(84314),g=i(11438),m=i(14438),c=i(37179),f=i(30634);let p={id:"common_ratingPrompt_header",defaultMessage:"Rate this"},R={id:"common_ratingPrompt_rate",defaultMessage:"Rate"},_={id:"common_ratingPrompt_removeRating",defaultMessage:"Remove rating"},h={id:"common_ratingPrompt_ariaLabelPrefix",defaultMessage:"Rating"},T=t=>{let{title:{id:e,titleText:i,canRate:T},ratingTriggerComponent:x,refOverride:I}=t,[b,N]=(0,r.useState)(!1),v=(0,u.n)(),{makeRefMarker:C}=(0,g.Lz)(),{rating:P,updateRating:M,deleteRating:L}=(0,o.useRatingsContext)(e)||{},E=C(I?[(0,g.Qk)({refStr:I,explanation:"Not all usages of RatingPrompt have been converted to link builders."}),g.Cd.RATING]:g.Cd.RATING),S=(0,m.EO)(),{updateTitleRating:w,deleteTitleRating:$,tempRateUpdateLogRef:y}=(0,d.vY)({titleId:e,refTag:E,currentRating:P}),U=(0,s.N)(p),A=(0,s.N)(R),O=(0,s.N)(_),k=(0,s.N)(h),D=(0,f.pl)();return(0,a.jsxs)(a.Fragment,{children:[x({onUserRatingClick:()=>{T&&(S({pageAction:c.QJ.USER_RATING_PROMPT_OPEN,hitType:n.Re.POP_UP,refMarkerString:E}),N(!0))}}),!!T&&(0,a.jsx)(o.RatingPrompt,{isOpen:b,tconst:e,title:i,headerLabel:U,rateLabel:A,ariaLabelPrefix:k,shouldUseNewRatingFlow:!0,secondaryButtonText:O,secondaryButtonType:l.uu.RemoveRating,onPrimaryButtonClicked:async(t,e)=>{if(!t){N(!1);return}v?(N(!1),M?.(t,E,()=>w(t,e))):(await y(t,e),D({rating:t,titleId:e,ref:E}))},onSecondaryButtonClicked:async(t,e)=>{N(!1),L?.(E,()=>$(e))},onCloseClicked:()=>{N(!1)}})]})}},2870:function(t,e,i){i.d(e,{f:function(){return d}});var a=i(52322);i(2784);var n=i(19596),r=i(88169),o=i(75824),l=i(11438),s=i(12563);let d=t=>{let{titleId:e,refOverride:i}=t,{makeRefMarker:n}=(0,l.Lz)(),{isInWatchlist:d,isPending:g,onClick:m,ariaLabel:c}=(0,s.X)(e,n(i||[l.Cd.WATCHLIST,l.Cd.BUTTON])),f=(0,o.N)({id:"common_buttons_watchlist",defaultMessage:"Watchlist"});return(0,a.jsxs)(r.SecondaryButton,{ariaLabel:c,onClick:m,width:"full-width",preIcon:g?void 0:d?"done":"add",disabled:g,children:[!!g&&(0,a.jsx)(u,{"data-testid":"watchlist-button-loader",type:"circle"}),!g&&f]})},u=(0,n.ZP)(r.Loader).withConfig({componentId:"sc-eebd0785-0"})(["max-height:30px;max-width:30px;vertical-align:middle;"]);e.Z=d},94471:function(t,e,i){i.d(e,{P:function(){return r}});var a=i(53665);let n={default:{maximumFractionDigits:1,minimumFractionDigits:1},imdb:{maximumFractionDigits:1,minimumFractionDigits:1},user:{maximumFractionDigits:0,minimumFractionDigits:0}},r=function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"default",i=arguments.length>2?arguments[2]:void 0,r=(0,a.Z)();if(!t)return"";if(10===t)return"10";let o="user"===e?Math.trunc(t):Number(t.toFixed(1)),l=i??n[e];return r.formatNumber(o,l)}},22073:function(t,e,i){var a,n;function r(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"default";if(t<=0)return"hours_minutes_explicit"===e?"0min":"hours_minutes_explicit_short"===e?"0m":"iso_8601"===e?"PT0S":"0:00";let i=Math.floor(t/3600),a=Math.floor(t%3600/60),n=Math.floor(t%60);if("hours_minutes_explicit"===e||"hours_minutes_explicit_short"===e)return(t<60&&t>0&&(a=1),i>0&&a<=0)?`${i}h`:`${i>0?i+"h "+a:a}${"hours_minutes_explicit_short"===e?"m":"min"}`;if("iso_8601"!==e)return`${i>0?i+":"+o(a):a}:${o(n)}`;{let t=i?`${i}H`:"",e=a?`${a}M`:"",r=n?`${n}S`:"";return`PT${t}${e}${r}`}}function o(t){return t<=0||!Number.isInteger(t)?"00":t>9?`${t}`:`0${t}`}i.d(e,{A:function(){return a},L:function(){return r}}),(n=a||(a={})).DEFAULT="default",n.HOURS_MINUTES_EXPLICIT="hours_minutes_explicit",n.HOURS_MINUTES_EXPLICIT_SHORT="hours_minutes_explicit_short",n.ISO_8601="iso_8601"},82433:function(t,e,i){i.d(e,{vY:function(){return u}});var a=i(30382),n=i.n(a),r=i(22619),o=i(14438),l=i(17503);let s=n()`
    mutation UpdateTitleRating($rating: Int!, $titleId: ID!) {
        rateTitle(input: { rating: $rating, titleId: $titleId }) {
            rating {
                value
            }
        }
    }
`,d=n()`
    mutation DeleteTitleRating($titleId: ID!) {
        deleteTitleRating(input: { titleId: $titleId }) {
            date
        }
    }
`,u=t=>{let[,e]=(0,l.Z)(s),[,i]=(0,l.Z)(d),a=(0,o.EO)(),{addToWatchedTitles:n}=(0,r.V)(),u=e=>{a({refMarkerString:t.refTag,pageAction:e,customPageMetadata:{id:t.titleId}})};return{updateTitleRating:(t,i)=>(u(`rating-add-${i}-${t}`),n(i),e({rating:t,titleId:i})),deleteTitleRating:t=>(u(`rating-del-${t}`),i({titleId:t})),tempRateUpdateLogRef:async(t,e)=>{u(`tmp-rating-add-${e}-${t}`)}}}},95441:function(t,e,i){i.d(e,{S:function(){return n}});var a=i(19596);let n=t=>(0,a.iv)(["@supports (-webkit-line-clamp:","){display:-webkit-box;-webkit-line-clamp:",";-webkit-box-orient:vertical;overflow:hidden;}"],t,t)}}]);