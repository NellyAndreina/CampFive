(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[5405],{87314:function(e,t,i){(window.__NEXT_P=window.__NEXT_P||[]).push(["/",function(){return i(5102)}])},29914:function(e,t,i){"use strict";i.d(t,{Z:function(){return h}});var r=i(52322),a=i(5632),n=i(2784),s=i(54588),o=i(82453),l=i(22187),d=i(59291);let c={base:"--ipt-base-rgb",baseShade1:"--ipt-base-shade1-rgb",baseShade2:"--ipt-base-shade2-rgb",baseShade3:"--ipt-base-shade3-rgb",onBase:"--ipt-on-base-rgb",onBaseAccent1:"--ipt-on-base-accent1-rgb",onBaseAccent2:"--ipt-on-base-accent2-rgb",onBaseAccent3:"--ipt-on-base-accent3-rgb",onBaseError:"--ipt-on-base-error-rgb",baseAlt:"--ipt-baseAlt-rgb",baseAltShade1:"--ipt-baseAlt-shade1-rgb",baseAltShade2:"--ipt-baseAlt-shade2-rgb",baseAltShade3:"--ipt-baseAlt-shade3-rgb",onBaseAlt:"--ipt-on-baseAlt-rgb",onBaseAltAccent1:"--ipt-on-baseAlt-accent1-rgb",onBaseAltAccent2:"--ipt-on-baseAlt-accent2-rgb",onBaseAltAccent3:"--ipt-on-baseAlt-accent3-rgb",onBaseAltError:"--ipt-on-baseAlt-error-rgb",accent1:"--ipt-accent1-rgb",onAccent1:"--ipt-on-accent1-rgb",accent2:"--ipt-accent2-rgb",onAccent2:"--ipt-on-accent2-rgb"};new d.DOMParser;let p=e=>{if(e&&Object.keys(e).length>0){let t=":root {\n";for(let i in e)if(Object.prototype.hasOwnProperty.call(e,i)&&e[i]&&"null"!==e[i]&&"undefined"!==e[i]&&c[i]){let r=u(e[i]);t+=`    ${c[i]}: ${r};
`}return t+"}\n"}return""},u=e=>{let t=e;if(!t.startsWith("#"))return t;t=t.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i,(e,t,i,r)=>t+t+i+i+r+r);let i=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(t);return i?`${m(i[1])},${m(i[2])},${m(i[3])}`:""},m=e=>parseInt(e,16),g=e=>{let{initialOverrides:t,pathname:i}=e,a=n.useRef(new Map([[i,p(t)]]));n.useEffect(()=>{let e=e=>{a.current.has(i)||a.current.set(i,p(e.detail))};return window.addEventListener("clientSidePlaidOverride",e),()=>{window.removeEventListener("clientSidePlaidOverride",e)}},[i]);let s=a.current.get(i);return s?.length?(0,r.jsx)("style",{id:l.cp,dangerouslySetInnerHTML:{__html:s}}):null};var h=()=>{let e=(0,o.Ok)().adSlotsInfo,t=(0,a.useRouter)();return(0,r.jsx)(s.Z,{name:"IMDbNextAdStyleOverrides",children:(0,r.jsx)(g,{initialOverrides:e.plaidOverrides,pathname:t.asPath})})}},21768:function(e,t,i){"use strict";i.d(t,{R:function(){return r}});let r="inline20-page-background"},51378:function(e,t,i){"use strict";i.d(t,{$L:function(){return j},gK:function(){return a}});var r,a,n=i(52322),s=i(88169);i(2784);var o=i(53665),l=i(90047),d=i(30382),c=i.n(d),p=i(11438),u=i(14438),m=i(17503);let g=()=>{let[e,t]=(0,m.Z)(h,{}),[i,r]=(0,m.Z)(f,{}),a=(0,u.EO)();return{follow:{executeFollow:e=>(a({refMarkerSuffix:[p.Cd.ADD],pageAction:`follow-${e}`,customPageMetadata:{id:e}}),t({id:e})),followResult:e},unfollow:{executeUnfollow:e=>(a({refMarkerSuffix:[p.Cd.DELETE],pageAction:`unfollow-${e}`,customPageMetadata:{id:e}}),r({id:e})),unfollowResult:i}}},h=c()`
    mutation Follow($id: ID!) {
        followEntity(input: { id: $id }) {
            result {
                id
            }
        }
    }
`,f=c()`
    mutation Unfollow($id: ID!) {
        unfollowEntity(input: { id: $id }) {
            result {
                id
            }
        }
    }
`;var x=i(84314),b=i(30634),T=i(27722),v=i(86704),y=i(50738),_=i(19596);let C=e=>{let{isSelected:t,ariaLabel:i,className:r,onSelect:a}=e;return(0,n.jsx)(w,{className:`${t?"active":"inactive"} ${r}`,ariaLabel:i,onSelect:a,children:(0,n.jsx)(T.Icon,{name:t?"done":"add"})})},w=(0,_.zo)(y.SharedButtonBase).withConfig({componentId:"sc-cc1d5099-0"})(["border-radius:50%;cursor:pointer;display:inline-block;line-height:0;margin:0;overflow:hidden;padding:0.3125rem;position:relative;&.active{border:none;",";",";&:hover::before,&:hover::after{opacity:",";}}&.inactive{background:rgba(",",0.8);border:none;",";&:hover::before,&:hover::after{opacity:",";}}&::before,&::after{background:currentcolor;inset:0;content:'';height:100%;margin:auto;opacity:0;pointer-events:none;position:absolute;transform-origin:center center;transition:transform hoveranimation,opacity hoveranimation;width:100%;}"],(0,T.setPropertyToColorVar)("background","ipt-accent1-bg"),(0,T.setPropertyToColorVar)("color","ipt-on-accent1-color"),(0,v.getColorVar)("ipt-base-hover-opacity"),(0,v.getColorVar)("ipt-baseAlt-rgb"),(0,T.setPropertyToColorVar)("color","ipt-on-baseAlt-color"),(0,v.getColorVar)("ipt-baseAlt-hover-opacity"));(r=a||(a={})).CIRCLE_WITH_CHECK="circle",r.CHECK="check",r.TEXT="text";let S={ADD_INTEREST:{id:"interest_add",defaultMessage:"Add to your interests"},ADDED_INTEREST:{id:"interest_added",defaultMessage:"Added to your interests"},ADD_INTEREST_FAILED:{id:"interest_add_failed",defaultMessage:"Adding interest failed. Please try again later."},REMOVE_INTEREST:{id:"interest_del",defaultMessage:"Remove from your interests"},REMOVE_INTEREST_FAILED:{id:"interest_del_failed",defaultMessage:"Removing interest failed. Please try again later."}},j=e=>{let{interestId:t,buttonType:i}=e,r=(0,x.n)(),a=(0,o.Z)(),{value:d}=(0,p.Lz)(),{follow:c,unfollow:u}=g(),{sendSnack:m}=(0,s.useSnackbar)(),{followedInterests:h,onFollowInterest:f,onUnfollowInterest:T,isLoading:v}=(0,l.pG)(),y=()=>{v||(r?h.includes(t)?(T(t),u.executeUnfollow(t).then(e=>{!e?.error&&e?.data?.unfollowEntity?.result?.id||(f(t),m({primaryText:a.formatMessage(S.REMOVE_INTEREST_FAILED),baseColor:"accent3",type:"auto"}))})):(f(t),c.executeFollow(t).then(e=>{!e?.error&&e?.data?.followEntity?.result?.id||(T(t),m({primaryText:a.formatMessage(S.ADD_INTEREST_FAILED),baseColor:"accent3",type:"auto"}))})):(0,b.rf)(d))},_=h.includes(t)?a.formatMessage(S.REMOVE_INTEREST):a.formatMessage(S.ADD_INTEREST);switch(i){case"text":return h.includes(t)?(0,n.jsx)(s.OutlineButton,{preIcon:"done",onColor:"accent2",onSelect:y,children:a.formatMessage(S.ADDED_INTEREST)}):(0,n.jsx)(s.Button,{preIcon:"add",onSelect:y,isLoading:v,children:a.formatMessage(S.ADD_INTEREST)});case"circle":return(0,n.jsx)(C,{isSelected:h.includes(t),ariaLabel:_,className:"add-button",onSelect:y});default:return(0,n.jsx)(s.IconButton,{name:h.includes(t)?"done":"add",label:_,ariaLabel:_,className:"add-button",onColor:"accent2",onSelect:y})}}},77845:function(e,t,i){"use strict";i.d(t,{x:function(){return N}});var r=i(52322),a=i(2784),n=i(14973),s=i(30382),o=i.n(s),l=i(19596),d=i(88169),c=i(86704),p=i(75824),u=i(86958),m=i(66724),g=i(11438),h=i(63370),f=i(19031);let x=e=>{let{isOpen:t,isNotInterested:i,interestStateOnClick:a,recommendation:n,onClose:s}=e,o=(0,p.N)({id:"common_listItem_notInterested",defaultMessage:"Not interested"});return(0,r.jsx)(f.Pz,{isOpen:t,onClose:s,title:n.title,contentOverride:()=>(0,r.jsx)(r.Fragment,{children:!!n&&(0,r.jsx)(b,{recommendation:n})}),actionOverride:()=>(0,r.jsx)(v,{ariaLabel:o,preIcon:i?"thumb-down-filled":"thumb-down",onClick:a})})},b=e=>{let t=(0,u.B)().context,{titleMainLinkBuilder:i}=(0,m.WOb)(),{recommendation:a,className:n}=e,s=(0,p.N)({id:"titleRecommendationPrompt_attributionHeading",defaultMessage:"Because of your interest in"});return(0,r.jsxs)(y,{className:n,children:[(0,r.jsx)("div",{className:"heading",children:s}),(0,r.jsx)("div",{className:"content",children:a.explanations.slice(0,2).map((e,a)=>{let{title:n}=e,s=(0,h.L)(t,n.originalTitleText,n.titleText);return(0,r.jsx)(r.Fragment,{children:!!s&&(0,r.jsx)(d.TextLink,{className:"link",href:i({tconst:n.id,refSuffix:g.Cd.EMPTY}),text:s,inheritColor:!0},a)})})})]})};var T=e=>{let{recommendation:{refTag:t}}=e;return(0,r.jsx)(g.xm,{value:[g.Cd.TITLE_RECOMMENDATION_PROMPT,(0,g.Qk)({refStr:t,explanation:"reftag is dynamic and passed down from graph"})],children:(0,r.jsx)(x,{...e})})};let v=(0,l.ZP)(d.SecondaryButton).withConfig({componentId:"sc-646c92ea-0"})(["width:30%;padding-left:",";"],c.spacing.l),y=l.ZP.div.withConfig({componentId:"sc-646c92ea-1"})(["margin:0;padding:"," "," "," ",";","{padding:"," 0 "," 0;}.content{"," ","}.heading{padding-bottom:",";",";","}.link{text-decoration:none;display:flex;flex-direction:column;","}"],c.spacing.xs,c.spacing.s,c.spacing.s,c.spacing.s,c.mediaQueries.breakpoints.above.m,c.spacing.xs,c.spacing.s,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"),(0,c.setTypographyType)("bodySmall"),c.spacing.xxs,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color"),(0,c.setTypographyType)("bodySmall"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"));var _=i(31885),C=i(17503),w=i(14438);let S={id:"common_featureHeader_link_info",defaultMessage:"More information"},j=o()`
    mutation UpdateTitleInterest(
        $titleId: ID!
        $interestLevel: InterestLevel!
    ) {
        updateTitleInterest(
            input: { titleId: $titleId, interestLevel: $interestLevel }
        ) {
            success
        }
    }
`,I=(e,t)=>{let[i,s]=(0,a.useState)(!1),[o,l]=(0,a.useState)(!1),[,d]=(0,C.Z)(j),{makeRefMarker:c}=(0,g.Lz)(),u=(0,w.EO)(),m=e.title.id,h=c([{t:g.Cd.TITLE,n:t+1},(0,g.Qk)({refStr:e.refTag,explanation:"This refmarker is vended dynamically from the graph"})]);return{iconButtonProps:{name:"info",label:(0,p.N)(S),onClick:()=>{s(!0),u({refMarkerString:h,pageAction:"overflow-expand",hitType:n.HitType.POP_UP,customPageMetadata:{id:m}})}},prompt:(0,r.jsx)(T,{isNotInterested:o,interestStateOnClick:()=>{let e=o?_.FhM.Ambivalent:_.FhM.NotInterested;u({refMarkerString:h,pageAction:o?"reverse-not-interested":"not-interested",customPageMetadata:{id:m}}),d({titleId:m,interestLevel:e}),l(!o)},isOpen:i,onClose:()=>s(!1),recommendation:e})}};var E=i(49175),P=i(23842);let N=e=>{let{recommendation:t,index:i}=e,{createButton:a,createPrompt:n}=(0,E.V1)(),{iconButtonProps:s,prompt:o}=I(t,i);return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(P.c,{className:"top-picks-title",data:t.title,refTagFromGraph:t.refTag,index:i+1,alternateButton:a(t.title,i),iconButtons:[s]},t.title.id),n(),o]})}},43421:function(e,t,i){"use strict";i.d(t,{OW:function(){return b}});var r=i(52322);i(2784);var a=i(53665),n=i(19596),s=i(88169),o=i(86704),l=i(66724),d=i(11438);let c={id:"from_your_watchlist_empty_title",defaultMessage:"Your watchlist is empty"},p={id:"from_your_watchlist_empty_content",defaultMessage:"Save shows and movies to keep track of what you want to watch."},u={id:"from_your_watchlist_all_rated_title",defaultMessage:"No available releases"},m={id:"from_your_watchlist_all_rated_content",defaultMessage:"Add more shows and movies to keep track of what you want to watch."},g={id:"from_your_watchlist_logged_out",defaultMessage:"Sign in to access your Watchlist"},h={id:"from_your_watchlist_logged_out_content",defaultMessage:"Save shows and movies to keep track of what you want to watch."},f={id:"from_your_watchlist_empty_button",defaultMessage:"Browse popular movies"},x={id:"from_your_watchlist_logged_out_button",defaultMessage:"Sign in to IMDb"},b=e=>{let{isLoggedIn:t,hasRatedTitles:i,hasUnreleasedTitlesInWatchlist:n}=e,s=(0,a.Z)(),{chartMovieMeterLinkBuilder:o,registrationSignInLinkBuilder:b}=(0,l.WOb)(),w=i||n,S=t?w?u:c:g,j=t?o({refSuffix:d.Cd.EMPTY_MESSAGE}):b({refSuffix:d.Cd.SIGN_IN});return(0,r.jsxs)(T,{className:"from-your-watchlist__state__container",children:[(0,r.jsx)(v,{className:"from-your-watchlist__ribbon",inWatchlist:!1,ariaLabel:s.formatMessage(S)}),(0,r.jsxs)(y,{className:"from-your-watchlist__status-prompt__container",children:[(0,r.jsx)(_,{className:"from-your-watchlist__status-prompt__title",children:s.formatMessage(S)}),(0,r.jsx)("div",{"data-testid":"empty-state-content",className:"from-your-watchlist_status-prompt_content",children:s.formatMessage(t?w?m:p:h)})]}),(0,r.jsx)(C,{className:"from-your-watchlist__state__button",width:"double-padding",href:j,children:s.formatMessage(t?f:x)})]})},T=(0,n.ZP)(s.PageSection).withConfig({componentId:"sc-5b81157c-0"})([""," text-align:center;padding:",";"],(0,o.setPropertyToSpacingVar)("margin","ipt-pageMargin"),o.spacing.l),v=(0,n.ZP)(s.WatchlistRibbon).withConfig({componentId:"sc-5b81157c-1"})(["pointer-events:none;"]),y=n.ZP.div.withConfig({componentId:"sc-5b81157c-2"})(["margin-top:",";"],o.spacing.xs),_=n.ZP.div.withConfig({componentId:"sc-5b81157c-3"})(["font-weight:bold;"]),C=(0,n.ZP)(s.SecondaryButton).withConfig({componentId:"sc-5b81157c-4"})(["margin-top:",";"],o.spacing.xl)},79544:function(e,t,i){"use strict";i.d(t,{b:function(){return n}});var r=i(30382),a=i.n(r);let n=a()`
    fragment InterestCard on Interest {
        id
        primaryText {
            text
        }
        primaryImage {
            caption {
                plainText
            }
            width
            height
            url
            id
        }
    }
`},78814:function(e,t,i){"use strict";i.d(t,{n:function(){return y}});var r=i(52322),a=i(27722),n=i(31129),s=i(4337),o=i(88169),l=i(86704),d=i(45455),c=i.n(d),p=i(2784),u=i(19596),m=i(66724),g=i(11438),h=i(14438),f=i(6935),x=i(83163),b=i(48687),T=i(51378),v=i(27950);let y=e=>{let{interests:t,refCategoryPrefix:i,shovelerClassName:n}=e,l=(0,g.Lz)().value,{interestSingleLinkBuilder:d}=(0,m.WOb)(),u=(0,h.EJ)(),y=p.useContext(a.Theme).palette.baseColor,S=(0,b.hg)({weblabID:x.lh.IMDB_NEXT_INTEREST_FOLLOWS_1261758,treatments:{T1:!0}});if(!t||c()(t))return null;let j=[];return t.forEach(e=>{e.id&&e.primaryText&&j.push({id:e.id,primaryText:e.primaryText?.text,primaryImage:e.primaryImage})}),(0,r.jsx)(o.Shoveler,{className:n,onPageChange:u,arrowSize:"small",children:j.map((e,t)=>{let a=(0,f.K0)(e.primaryImage&&e.primaryImage.url?e.primaryImage:v.B,e.primaryText),n=[g.Cd.INTEREST,{t:g.Cd.POSTER,n:t+1}],o=[g.Cd.INTEREST,{t:g.Cd.TEXT,n:t+1}];return i&&(n.unshift(i),o.unshift(i)),(0,r.jsx)(s.SubGridItem,{span:3,children:(0,r.jsxs)(_,{className:y,children:[(0,r.jsx)(C,{ariaLabel:e.primaryText,href:d({inconst:e.id,refSuffix:n}),imageProps:{imageModel:a,className:v.p},dynamicWidth:!0,children:!!S&&(0,r.jsx)(T.$L,{interestId:e.id,buttonType:T.gK.CIRCLE_WITH_CHECK})}),(0,r.jsx)(w,{href:d({inconst:e.id,refSuffix:o}),title:e.primaryText,lineClamp:1})]})},`${l}-${e.id}`)})})},_=u.zo.div.withConfig({componentId:"sc-254e031d-0"})(["",";margin-bottom:",";&.base{box-shadow:0 3px 1px -2px rgb(0 0 0 / 20%),0 2px 2px 0 rgb(0 0 0 / 14%),0 1px 5px 0 rgb(0 0 0 / 12%);}&.baseAlt{",";}"],(0,l.setPropertyToShapeVar)("border-radius","ipt-mediaRadius"),l.spacing.s,(0,l.setPropertyToColorVar)("background","ipt-baseAlt-shade2-bg")),C=(0,u.zo)(o.Slate).withConfig({componentId:"sc-254e031d-1"})(["position:relative;z-index:1;.","{border-bottom-left-radius:0;border-bottom-right-radius:0;}.add-button{position:absolute;bottom:0;left:0;z-index:2;margin-left:",";margin-bottom:",";}"],v.p,l.spacing.xs,l.spacing.xs),w=(0,u.zo)(n.SlateCardTitle).withConfig({componentId:"sc-254e031d-2"})(["margin-left:",";margin-bottom:",";"],l.spacing.xs,l.spacing.xs)},27950:function(e,t,i){"use strict";i.d(t,{B:function(){return r},p:function(){return a}});let r={width:1280,height:720,url:"https://m.media-amazon.com/images/G/01/IMDb/Interests/interest_image_placeholder_dark.png"},a="slate-corners"},64411:function(e,t,i){"use strict";var r=i(52322),a=i(14865);i(2784);var n=i(88169),s=i(47130),o=i(10965),l=i(78814),d=i(25436),c=i(75824),p=i(16214),u=i(49996),m=i(55634),g=i(59002),h=i(66724),f=i(11438);let x=e=>{let{interestAllLinkBuilder:t}=(0,h.WOb)(),{pageType:i,subPageType:x}=(0,u.y)(),{data:b}=e,T=(0,c.N)({id:"popularInterests_title",defaultMessage:"Popular interests"}),v=i===d.PageType.INTEREST&&x===d.SubPageType.ALL,y=(0,p.b)(b?.popularInterests?.edges),_=!a.isNode&&e.fetching;return _||y&&0!==y.length?(0,r.jsx)(s.AU,{value:{cti:d.CTIS.INTERESTS_CTI},children:(0,r.jsx)(g.Lz,{componentId:m.NG.PopularInterests,children:(0,r.jsx)(n.PageGrid.Item,{span:3,children:(0,r.jsxs)(n.PageSection,{children:[(0,r.jsx)(n.SubSectionTitle,{href:v?void 0:t({refSuffix:f.Cd.SEE_MORE}),children:T}),(0,r.jsx)(o.Z,{loading:!!_,height:250,children:(0,r.jsx)(l.n,{interests:y})})]})})})}):null};t.Z=e=>(0,r.jsx)(f.xm,{value:f.Cd.POPULAR_INTERESTS,children:(0,r.jsx)(x,{...e})})},96621:function(e,t,i){"use strict";i.d(t,{y:function(){return o}});var r=i(30382),a=i.n(r),n=i(85018),s=i(49175);let o=a()`
    query FromYourWatchlist($first: Int!) {
        predefinedList(classType: WATCH_LIST) {
            items(
                first: $first
                filter: { rated: EXCLUDE, released: INCLUDE }
                sort: { by: POPULARITY, order: ASC }
            ) {
                edges {
                    node {
                        item {
                            ...BaseTitleCard
                            ...TitleCardTrailer
                            ...TitleWatchOption
                        }
                    }
                }
            }
            ratedCount: items(first: 0, filter: { rated: INCLUDE }) {
                total
            }
            unreleasedCount: items(first: 0, filter: { released: EXCLUDE }) {
                total
            }
        }
    }
    ${n.sq}
    ${n.F4}
    ${s.sG.titleWatchOption}
`},3072:function(e,t,i){"use strict";i.d(t,{B:function(){return r}});let r=(e,t,i)=>{let r=a(e),n=a(t),s=i.formatDate(r,{day:"numeric",month:"long"}),o=i.formatDate(n,{day:"numeric",month:"long"});return r.getMonth()===n.getMonth()?s+"-"+i.formatDate(n,{day:"numeric"}):s+"-"+o};function a(e){return new Date(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate())}},29363:function(e,t,i){"use strict";i.d(t,{T:function(){return s}});var r=i(2784),a=i(93855),n=i(99546);let s=(e,t)=>{let[i,s]=(0,r.useState)(!1),[o,l]=(0,r.useState)(!1);(0,r.useEffect)(()=>{i&&!o&&l(!0)},[i,o]);let d=(0,a.Jf)(e,o,s);return(0,n.S)(e,d,t),o}},73013:function(e,t,i){"use strict";i.d(t,{S:function(){return a}});var r=i(86958);let a=()=>r.B()?.context?.sidecar?.placementMap||{}},96115:function(e,t,i){"use strict";i.d(t,{P:function(){return p}});var r=i(88169),a=i(2784),n=i(75824),s=i(66724),o=i(11438),l=i(72416),d=i(48687);let c="sxdshidesnack",p=e=>{let{sixDegreesLinkBuilder:t}=(0,s.WOb)(),i=(0,n.N)({id:"homepage_six_degrees_snack_msg",defaultMessage:"Try IMDb's new daily game Six Degrees."}),p=(0,n.N)({id:"homepage_six_degrees_snack_link",defaultMessage:"Play now"}),u=(0,d.hg)({weblabID:e,treatments:{T1:!0}}),{sendSnack:m}=(0,r.useSnackbar)(),g=(0,l.ID)(c);(0,a.useEffect)(()=>{u&&!g&&m({type:"manual",primaryText:i,textLinks:[{text:p,href:t({refSuffix:[o.Cd.SNACK,o.Cd.GAMES,o.Cd.SIX_DEGREES]}),onClick:()=>(0,l._2)(c,!0)}],closeLabel:"Close",onClose:()=>(0,l._2)(c,!0)})},[])}},30124:function(e,t,i){"use strict";var r=i(52322);i(2784);var a=i(10105),n=i(54588),s=i(14149);t.Z=function(e){let{groupConfig:t,pageQueryData:i,hideErrors:o,hasIntersected:l=!0}=e,{data:d,config:c,error:p,fetching:u=!1,retry:m,shouldRenderError:g=!1,allErrorsRetryable:h=!0}=i,f=!!(m&&h);return u||!l?(0,r.jsx)(a.ZP,{"data-testid":"entity-group-loader",height:"feature"}):o&&g?null:(0,r.jsxs)(r.Fragment,{children:[!!g&&(0,r.jsx)(s.ZP,{error:p,name:c?.queryName,canRetry:f,onClickRetry:()=>f&&m()}),!g&&Object.entries(t).map(e=>{let[t,i]=e;if(i.shouldRender&&d&&!1===i.shouldRender(d))return null;let a=i.component;return(0,r.jsx)(n.Z,{name:t,parent:"PageQueryEntity",children:(0,r.jsx)(a,{data:d,fetching:u,error:p})},t)})]})}},60635:function(e,t,i){"use strict";function r(e){(e||[]).forEach(e=>{let t=e.id,i=e?.userRating?.value;i&&window.imdb?.ratings?.addRating(t,i)})}i.d(t,{Q:function(){return r}})},5102:function(e,t,i){"use strict";i.r(t),i.d(t,{__N_SSP:function(){return rY},default:function(){return rX}});var r=i(52322),a=i(2784),n=i(25436),s=i(19596),o=i(88169),l=i(14865),d=i(4337),c=i(86704),p=i(10965),u=i(75824),m=i(16214),g=i(78716),h=i(55634),f=i(59002),x=i(66724),b=i(11438),T=i(14438),v=i(72779),y=i.n(v),_=i(30382),C=i.n(_),w=i(82925),S=i(15030),j=i(6935);let I=C()`
    fragment PopularCelebrity on Name {
        id
        nameText {
            text
        }
        primaryImage {
            caption {
                plainText
            }
            url
            height
            width
        }
        meterRanking {
            currentRank
            rankChange {
                changeDirection
                difference
            }
        }
    }
`,E={CARD:"popular-celebrity-card",CURRENT_RANK:"popular-celebrity-current-rank",NAME_TEXT:"popular-celebrity-name-text",RANK:"popular-celebrity-rank",RANK_CHANGE:"popular-celebrity-rank-change"},P=e=>{let{className:t,refMarkerSuffix:i,popularCelebrityData:n}=e,{nameMainLinkBuilder:s}=(0,x.WOb)(),l=(0,a.useContext)(w.Theme),d=y()(t,E.CARD),{id:c,primaryImage:p,meterRanking:u}=n,m=n.nameText?.text??"",g=(0,j.K0)(p,m);return(0,r.jsxs)(N,{className:d,href:s({nconst:c,refSuffix:i}),"data-testid":E.CARD,children:[(0,r.jsxs)(o.Avatar,{dynamicWidth:!0,children:[(0,r.jsx)(o.Avatar.Image,{imageModel:g}),(0,r.jsx)(o.Avatar.Overlay,{className:"overlayClasses"})]}),(0,r.jsxs)(M,{className:E.RANK,"data-testid":E.RANK,children:[(0,r.jsx)("div",{className:y()(E.CURRENT_RANK,`${E.CURRENT_RANK}--${l.palette.name}`),children:u?.currentRank}),u?.rankChange&&(0,r.jsxs)(k,{className:y()(E.RANK_CHANGE,`${E.RANK_CHANGE}--${l.palette.name}`),children:[" (",(0,r.jsx)(S.x,{difference:u?.rankChange.changeDirection==="FLAT"?void 0:u?.rankChange.difference,direction:u?.rankChange.changeDirection}),")"]})]}),(0,r.jsx)(R,{className:y()(E.NAME_TEXT,`${E.NAME_TEXT}--${l.palette.name}`),"data-testid":E.NAME_TEXT,children:m})]})},N=s.ZP.a.withConfig({componentId:"sc-5a012df2-0"})(["",";width:100%;text-align:center;overflow:hidden;display:flex;flex-direction:column;&:hover{opacity:0.7;}"],(0,c.setTypographyType)("body")),M=s.ZP.div.withConfig({componentId:"sc-5a012df2-1"})(["display:inline-flex;justify-content:center;width:100%;margin-top:",";line-height:1em;.","--light{",";padding-right:",";}.","--dark{",";padding-right:",";}.","--light{",";}.","--dark{",";}"],c.spacing.s,E.CURRENT_RANK,(0,c.setPropertyToColorVar)("color","ipt-on-base-textPrimary-color"),c.spacing.xxs,E.CURRENT_RANK,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"),c.spacing.xxs,E.RANK_CHANGE,(0,c.setPropertyToColorVar)("color","ipt-on-base-textSecondary-color"),E.RANK_CHANGE,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),k=s.ZP.div.withConfig({componentId:"sc-5a012df2-2"})(["display:flex;align-items:center;"]),R=s.ZP.div.withConfig({componentId:"sc-5a012df2-3"})(["white-space:nowrap;overflow:hidden;text-overflow:ellipsis;&.","--light{",";}&.","--dark{",";}"],E.NAME_TEXT,(0,c.setPropertyToColorVar)("color","ipt-on-base-textPrimary-color"),E.NAME_TEXT,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"));P.fragments={popularCelebrity:I};let O=C()`
    query PopularCelebrities {
        topMeterNames(first: 50) {
            edges {
                node {
                    ...PopularCelebrity
                }
            }
        }
    }

    ${P.fragments.popularCelebrity}
`;var A=i(31885);let D=(e,t)=>e.filter(e=>e?.nameText&&e?.meterRanking?.rankChange?.changeDirection===A.UQd.Up).sort((e,t)=>(t.meterRanking?.rankChange?.difference||0)-(e.meterRanking?.rankChange?.difference||0)).slice(0,t),L={TITLE:"popular-celebrities-title",SHOVELER:"popular-celebrities-shoveler",ITEM_CARD:"popular-celebrities-item-card"},$=e=>{let{delayOnIntersection:t,csmOnLoadHandler:i,csaOnLoadHandler:n,cel_widget_id:s,className:d}=e,c=(0,a.useRef)(null),v=(0,T.EJ)(),{chartStarMeterLinkBuilder:y}=(0,x.WOb)(),_=(0,u.N)({id:"popularCelebrities_title",defaultMessage:"Most popular celebrities"}),C=(0,u.N)({id:"popularCelebrities_topRising_subHeader",defaultMessage:"Top rising"}),w=(0,u.N)({id:"popularCelebrities_topMeter_subHeader",defaultMessage:"By ranking"}),[S]=(0,g.p)({queryOptions:{query:O,context:{personalized:!1,serverSideCacheable:!0}},ref:c,pause:l.isNode,options:{disableIntersection:!t,disableAds:!0}});(0,f.LQ)(S,i,n);let{fetching:j,data:I,error:E}=S;if(E)return null;let P=(0,m.b)(I?.topMeterNames?.edges);if(!j&&(!P||0===P.length))return null;let N=D(P,2);return(0,r.jsx)(f.Lz,{componentId:h.NG.PopularCelebrities,children:(0,r.jsx)(o.PageSection,{"data-testid":s,className:d,children:(0,r.jsxs)("div",{ref:c,children:[(0,r.jsx)(o.SubSectionTitle,{href:y({refSuffix:b.Cd.SEE_MORE}),className:L.TITLE,children:_}),(0,r.jsx)(p.Z,{loading:j,height:230,children:(0,r.jsx)(F,{className:L.SHOVELER,onPageChange:v,children:[...Z(N,b.Cd.TOP,C),...Z(P,b.Cd.RANK,w,N.filter(e=>e.meterRanking?.currentRank&&e.meterRanking?.currentRank<=4))]})})]})})})},Z=(e,t,i,a)=>{let n=1,s=a?.map(e=>e.id)??[],o=[];for(let a=0;a<e.length;a++){let l=e[a];if(!l.nameText||!l.meterRanking||s.includes(l.id))continue;let c=1===n?i:null,p=(0,r.jsx)(d.SubGridItem,{span:2,className:L.ITEM_CARD,children:(0,r.jsxs)("div",{children:[!!c&&(0,r.jsx)(V,{children:c}),(0,r.jsx)(P,{refMarkerSuffix:{t:t,n:n},popularCelebrityData:l,className:`${L.ITEM_CARD}-${t}-${n}`})]})},`${t}_${n}`);o.push(p),n++}return o};var B=e=>(0,r.jsx)(b.xm,{value:b.Cd.POPULAR_CELEBRITIES,children:(0,r.jsx)($,{...e})});let V=s.ZP.div.withConfig({componentId:"sc-790c21c3-0"})(["",";",";padding-bottom:",";white-space:nowrap;overflow:visible;"],(0,c.setPropertyToColorVar)("color","ipt-accent1-color"),(0,c.setTypographyType)("overline"),c.spacing.s),F=(0,s.ZP)(o.Shoveler).withConfig({componentId:"sc-790c21c3-1"})([".","{align-self:end;}"],L.ITEM_CARD);var W=i(21915),G=i(86857),z=i(80380),U=i(55129),q=i(29914),H=i(22431),Q=i(82453),Y=i(21768),X=i(54588),K=i(96115),J=i(83163),ee=i(48687),et=i(82008),ei=i(20608),er=i(30124);let ea=(0,s.ZP)(o.PageGrid).withConfig({componentId:"sc-42bf884a-0"})(["",""],(0,c.setPropertyToColorVar)("background","ipt-baseAlt-bg"));var en=i(64934);let es=e=>{let t=[],i=1,r=1;for(let a=0;a<30;a+=1)eo(a)?(t.push({name:`geo-${e}-${i}`,isGeo:!0,slotNumber:i}),i++):(t.push({name:`${e}-${r}`,isGeo:!1,slotNumber:r}),r++);return t},eo=e=>e<=3||(!(e>24)||!(e<29))&&e%2==1;var el=i(92550),ed=e=>{let t=e.carouselTitle,i=e.carouselDescription,a=e.slotNamePrefix,n=e.refMarkerPrefix,s=(0,T.EJ)(n),l=es(a).map(e=>(0,r.jsx)(el.Z,{slotName:e.name,className:"editorial-item",refMarker:{prefix:n,suffix:`${e.isGeo?"geo_":""}${e.slotNumber}`}},a+"-editorial-item-"+e.slotNumber));return(0,r.jsxs)(r.Fragment,{children:[!!t&&(0,r.jsx)(o.SubSectionTitle,{description:i,children:t}),(0,r.jsx)(o.Shoveler,{className:"editorial-carousel",onPageChange:s,children:l})]})},ec=i(73013);let ep=e=>{let t=e+"-mso";return!(0>Object.values((0,ec.S)()).findIndex(e=>t===e.symphonyMetadata?.msoGroupName))},eu=e=>{let{slotNamePrefix:t,title:i,description:a}=e,n=(0,b.Lz)().value,s=ep(t),l=ep(`geo-${t}`);if(!s&&!l)return null;let d=i?void 0:"none";return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(en.P,{id:t}),(0,r.jsx)(o.PageSection,{topPadding:d,bottomPadding:d,children:(0,r.jsx)(ed,{carouselTitle:i,carouselDescription:a,slotNamePrefix:t,refMarkerPrefix:n})})]})};var em={imdbOriginals:{component:()=>{let e=(0,u.N)({id:"editorialCarousel_imdb_originals",defaultMessage:"IMDb Originals"}),t=(0,u.N)({id:"editorialCarousel_imdb_originals_description",defaultMessage:"Celebrity interviews, trending entertainment stories, and expert analysis"});return(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_IMDB_ORIG,children:(0,r.jsx)(eu,{slotNamePrefix:"imdb-originals",title:e,description:t})})}}},eg=e=>{let{pageQueryData:t}=e;return(0,r.jsx)(X.Z,{name:"ExclusiveVideos",children:(0,r.jsx)(ea,{className:"page-grid",children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsxs)("div",{children:[(0,r.jsx)(o.CategoryTitle,{children:(0,r.jsx)(ei.q,{id:"homepage_main_category_exclusiveVideos",defaultMessage:"Exclusive videos"})}),(0,r.jsx)(er.Z,{groupConfig:em,pageQueryData:t,hideErrors:!1})]})})})})},eh=i(29363),ef=i(85846),ex=i(53665);let eb=e=>{let{children:t,displayStyle:i}=e,a=y()("grid w-full",{"grid-cols-1 m:grid-flow-col m:grid-cols-2 m:grid-rows-3":"dynamic"===i},{"grid-cols-1":"singleColumn"===i});return(0,r.jsx)("div",{className:a,children:t})};var eT=i(86958),ev=i(3072),ey=i(84220),e_=i(62018),eC=i(68139),ew=i(63370);let eS=(e,t,i)=>i.formatNumber(e,{style:"currency",currency:t,notation:"compact",compactDisplay:"short",currencyDisplay:"symbol"}),ej=(e,t,i,r,a)=>{if(!e||!e.title||!e.weekendGross)return;let{title:n,weekendGross:s}=e,o=(0,ew.L)(a,n.originalTitleText,n.titleText),l=(0,eC.k)(a,n.series),d=l?`${l}: ${o}`:`${o}`,c=n.id,p=eS(s.total.amount,s.total.currency,r),u=n.lifetimeGross?eS(n.lifetimeGross?.total.amount,n.lifetimeGross?.total.currency,r):void 0,m=i.titleMainLinkBuilder({tconst:c,refSuffix:{t:b.Cd.EMPTY,n:t}}),g=n.cinemas?.total?i.showtimesTitleLinkBuilder({tconst:c,refSuffix:{t:b.Cd.EMPTY,n:t}}):void 0;return{rankNumber:t,titleName:d,titleId:c,titlePageLink:m,weekendGrossAmount:p,lifeTimeGrossAmount:u,showtimesLink:g}},eI=e=>{let t=(0,ex.Z)(),i=(0,x.WOb)(),r=(0,eT.B)().context;return e?(e?.boxOfficeWeekendChart?.entries??[]).map((e,a)=>ej(e,a+1,i,t,r)).filter(e=>void 0!==e).map(e=>e):[]},eE=(e,t)=>{let{data:i}=e;if(i?.boxOfficeWeekendChart?.weekendStartDate&&i?.boxOfficeWeekendChart?.weekendEndDate)return(0,ev.B)(new Date(i.boxOfficeWeekendChart.weekendStartDate),new Date(i.boxOfficeWeekendChart.weekendEndDate),t)},eP=e=>{let{data:t}=e,i=(0,ex.Z)(),{chartBoxOfficeLinkBuilder:a}=(0,x.WOb)(),n=eI(t),s=eE({data:t},i),o=(0,u.N)({id:"topBoxOffice_header_top_us",defaultMessage:"Top box office (US)"}),l=s?i.formatMessage({id:"topBoxOffice_header_description_date",defaultMessage:"Weekend of {dateRange}"},{dateRange:s}):"",d=(0,ey.JY)({id:"top-box-office",height:"other",title:o,description:l,link:a({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>n.length>4},e),c=n.map(e=>(0,r.jsx)(e_.y,{boxOfficeData:e},e.titleId));return(0,r.jsx)(ey.GN,{...d,children:(0,r.jsx)(eN,{"data-testid":"boxOfficeList",children:(0,r.jsx)(eb,{displayStyle:"dynamic",children:c})})})},eN=s.ZP.div.withConfig({componentId:"sc-5592797c-0"})(["","{display:flex;}"],c.mediaQueries.breakpoints.above.s);var eM=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_BOX_OFFICE,children:(0,r.jsx)(eP,{...e})});let ek={component:e=>(0,r.jsx)(eM,{...e}),shouldRender:()=>!0,fragment:{name:"TopBoxOffice",variables:e=>{let{requestContext:t}=e;return{location:{value:(0,ef.QJ)(t),type:"ShowtimesLocation!"}}},gql:C()`
            fragment TopBoxOffice on Query {
                boxOfficeWeekendChart(limit: 6) {
                    weekendStartDate
                    weekendEndDate
                    entries {
                        title {
                            id
                            titleText {
                                text
                            }
                            originalTitleText {
                                text
                            }
                            series {
                                series {
                                    titleText {
                                        text
                                    }
                                    originalTitleText {
                                        text
                                    }
                                }
                            }
                            cinemas(
                                first: 0
                                request: { location: $location }
                            ) {
                                total
                            }
                            lifetimeGross(boxOfficeArea: DOMESTIC) {
                                total {
                                    amount
                                    currency
                                }
                            }
                        }
                        weekendGross {
                            total {
                                amount
                                currency
                            }
                        }
                    }
                }
            }
        `}};var eR=i(85018);let eO=()=>{let e=new Date;return new Date(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate()+1).toISOString().split("T")[0]};var eA=i(4363),eD=i(20937),eL=i(11778),e$=i(31129),eZ=i(12563),eB=i(69380),eV=i(22073);let eF=(0,s.ZP)(eB.Q).withConfig({componentId:"sc-e7a6d986-0"})(["padding-left:2.75rem;"]),eW=(0,s.ZP)(o.TextLink).withConfig({componentId:"sc-e7a6d986-1"})(["padding-left:0;padding-bottom:0;"]);var eG=e=>{let t=(0,ex.Z)(),{slotNumber:i,model:{titleText:a,titleId:n,releaseDate:s,slate:o,runtimeSeconds:l,videoId:d,hasShowtimes:c}}=e,{makeRefMarker:p}=(0,b.Lz)(),{showtimesTitleLinkBuilder:u,titleMainLinkBuilder:m,videoSingleLinkBuilder:g}=(0,x.WOb)(),{onClick:h,ariaLabel:f,isInWatchlist:T,isPending:v}=(0,eZ.X)(n,p({t:b.Cd.WATCHLIST_RIBBON,n:i+1})),y=a+" "+t.formatMessage({id:"comingSoon_trailer_ariaLabel_suffix",defaultMessage:"trailer"}),_=t.formatMessage({id:"comingSoon_get_tickets",defaultMessage:"Get tickets"}),C=g({viconst:d,refSuffix:{t:b.Cd.POSTER,n:i}}),w={title:a,href:m({tconst:n,refSuffix:{t:b.Cd.TEXT,n:i}}),subtitle:t.formatDate(s,{month:"short",day:"numeric"})},S={ariaLabel:y,imageProps:{aspectRatio:"16:9",imageModel:o},overlayProps:{gradientType:"radial",iconName:"play-circle-outline",text:(0,eV.L)(l)},href:C},j={children:c&&(0,r.jsx)(eW,{"data-testid":"coming-soon-ticket-link",text:_,href:u({tconst:n,refSuffix:{t:b.Cd.EMPTY,n:i}}),touchTarget:!0})},I=(0,r.jsx)(eF,{associatedConstId:d,entityType:"video"});return(0,r.jsx)(e$.SlateCard,{className:"coming-soon-title",watchlistProps:{size:"m",onClick:h,ariaLabel:f,isLoading:v,inWatchlist:T},titleProps:w,slateProps:S,actionProps:j,dynamicWidth:!0,size:"s",children:I})};let ez={id:"comingSoon_trailers_for_upcoming_releases",defaultMessage:"Trailers for upcoming releases"},eU={id:"comingSoon_coming_soon_to_theaters",defaultMessage:"Coming soon to theaters"},eq={id:"comingSoon_add_to_watchlist_for_notifications",defaultMessage:"Add to Watchlist for notifications"},eH={id:"comingSoon_watch_soon_at_home",defaultMessage:"Watch soon at home"};var eQ=e=>{let{fetching:t,titles:i,comingSoonType:a}=e,n=(0,ex.Z)(),{calendarLinkBuilder:s}=(0,x.WOb)(),l=(0,T.EJ)(),d=a===A.M4k.Movie,c=i.map((e,t)=>(0,r.jsx)(eG,{slotNumber:t+1,model:e},e.titleId)),{link:p,description:u,title:m}=d?{description:n.formatMessage(ez),title:n.formatMessage(eU),link:s({refSuffix:b.Cd.SEE_MORE})}:{description:n.formatMessage(eq),title:n.formatMessage(eH),link:void 0},g=("coming-soon-"+a).toLowerCase(),h=(0,ey.JY)({id:g,height:"video-slates",title:m,description:u,link:p,shouldRender:()=>(0,eL.isDevStage)()?i.length>0:i.length>5},{fetching:t});return(0,r.jsx)(ey.GN,{...h,children:(0,r.jsx)(o.Shoveler,{className:"coming-soon-titles",onPageChange:l,children:c})})};let eY=(e,t)=>{if(!e)return[];switch(t){case A.M4k.Tv:return e.comingSoonTV?.edges;case A.M4k.Movie:default:return e.comingSoonMovie?.edges}},eX=e=>{let{fetching:t,data:i,type:a}=e,n=eY(i,a),s=(0,m.b)(n).reduce((e,t)=>{let{titleText:i,latestTrailer:r,releaseDate:a}=t;if(!i||!r||!a)return e;let{month:n,day:s,year:o}=a;if(!n||!s||!o)return e;let{runtime:l,thumbnail:d,name:{value:c}}=r;if(!l)return e;let p=new Date(o,n-1,s,0,0,0,0),u=t.meterRanking?.currentRank;return e.push({titleId:t.id,titleText:i.text,videoId:r.id,releaseDate:p,runtimeSeconds:l.value,slate:{caption:c,maxHeight:d.height,maxWidth:d.width,url:d.url},currentRank:u,hasShowtimes:(t.cinemas?.total??0)>0}),e},[]);return(0,r.jsx)(eQ,{fetching:!!t,comingSoonType:a,titles:s})};var eK=e=>(0,r.jsx)(b.xm,{value:e.type===A.M4k.Movie?b.Cd.COMING_SOON:b.Cd.COMING_SOON_TV,children:(0,r.jsx)(eX,{...e})});let eJ=C()`
    query comingSoonMovieQuery(
        $movieReleasingOnOrAfter: Date!
        $movieViewerLocation: ShowtimesLocation!
        $regionOverride: String!
    ) {
        comingSoonMovie: comingSoon(
            first: 50
            comingSoonType: MOVIE
            releasingOnOrAfter: $movieReleasingOnOrAfter
            regionOverride: $regionOverride
            sort: [{ sortBy: POPULARITY, sortOrder: ASC }]
        ) {
            edges {
                node {
                    ...BaseTitleCard
                    ...TitleCardTrailer
                    releaseDate {
                        day
                        month
                        year
                    }
                    latestTrailer {
                        name {
                            value
                        }
                        runtime {
                            value
                        }
                        thumbnail {
                            height
                            width
                            url
                        }
                    }
                    cinemas(
                        first: 0
                        request: { location: $movieViewerLocation }
                    ) {
                        total
                    }
                    meterRanking {
                        currentRank
                    }
                }
            }
        }
    }
    ${eR.sq}
    ${eR.F4}
`,e0=(0,eD.O)({query:()=>{let e=eO(),t=(0,ef.wT)(),i=eT.B().context.sidecar?.localizationResponse.userCountryCode??"US",[r]=(0,eA.E)({query:eJ,variables:{movieReleasingOnOrAfter:e,movieViewerLocation:t,regionOverride:i},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!1}});return r},component:e=>{let t={...e,type:A.M4k.Movie};return(0,r.jsx)(eK,{...t})}});var e1=i(78270),e2=i(23842),e3=i(49175);let e4=e=>{let{classname:t,items:i,buttonText:a}=e,{showtimesTitleLinkBuilder:n}=(0,x.WOb)(),{createPrompt:s}=(0,e3.V1)(),l=(0,T.EJ)();return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(o.Shoveler,{onPageChange:l,children:i.map((e,i)=>(0,r.jsx)(e2.c,{className:t,data:e,index:i+1,alternateButton:e8(a,e,i,n)},e.id))}),s()]})},e8=(e,t,i,r)=>({text:e,props:{ariaLabel:e,preIcon:"ticket",href:r({tconst:t.id,refSuffix:{t:b.Cd.EMPTY,n:i+1}})}}),e5=e=>{let{showtimesLinkBuilder:t}=(0,x.WOb)(),i=(0,m.b)(e.data?.showtimesTitles?.edges).slice(0,30);(0,e1.b)(i);let a=(0,u.N)({id:"in_theaters_title",defaultMessage:"In theaters"}),n=(0,u.N)({id:"in_theaters_description",defaultMessage:"Showtimes near you"}),s=(0,u.N)({id:"in_theaters_showtimes_button_text",defaultMessage:"Showtimes"}),o=(0,ey.JY)({id:"in-theaters",height:"title-cards",title:a,description:n,link:t({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>i.length>5},e);return(0,r.jsx)(ey.GN,{...o,children:(0,r.jsx)(e4,{classname:"in-theaters-title",items:i,buttonText:s})})};var e6=e=>(0,r.jsx)(b.xm,{value:b.Cd.IN_THEATERS,children:(0,r.jsx)(e5,{...e})});let e7=C()`
    query InTheatersHomepage($inTheatersLocation: ShowtimesLocation!) {
        showtimesTitles(
            first: 30
            location: $inTheatersLocation
            queryMetadata: { sortField: SHOWTIMES_COUNT, sortOrder: DESC }
        ) {
            edges {
                node {
                    ...BaseTitleCard
                    ...TitleCardTrailer
                }
            }
        }
    }
    ${eR.sq}
    ${eR.F4}
`;var e9={InTheatersEntity:(0,eD.O)({query:()=>{let e=(0,ef.wT)(),[t]=(0,eA.E)({query:e7,variables:{inTheatersLocation:e},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!1}});return t},component:e=>(0,r.jsx)(e6,{...e})}),TopBoxOfficeEntity:ek,ComingSoonMovieEntity:e0},te=e=>{let{pageQueryData:t}=e,i=a.useRef(null),n=(0,eh.T)(i,{root:null,threshold:0,rootMargin:"200px"});return(0,r.jsx)(X.Z,{name:"ExploreMoviesAndTV",children:(0,r.jsx)("div",{ref:i,children:(0,r.jsxs)(ea,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.CategoryTitle,{"data-testid":"exploreMoviesAndTv_title",children:(0,r.jsx)(ei.q,{id:"homepage_main_category_exploreMoviesAndTV",defaultMessage:"Explore Movies & TV shows"})})}),(0,r.jsx)(er.Z,{groupConfig:e9,pageQueryData:t,hasIntersected:n})]})})})},tt=i(41174),ti=i(73078),tr=i(42712);let ta=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[];return(0,a.useMemo)(()=>{if(!e.length||!t.length)return e;let i=t.map(e=>e.id),r=[],a=[];return e.forEach(e=>{i.includes(e.id)?r.push(e):a.push(e)}),r.sort((e,t)=>i.indexOf(e.id)-i.indexOf(t.id)),[...r,...a]},[e,t])},tn=(e,t,i)=>{let r=t.findIndex(e=>e.provider.id===i);if(r<0)return"unknown";let a=t[r].provider.refTagFragment;return`${e}_${a}_tab_${r+1}`};var ts=i(54137),to=i(14911);let tl={ParamountPlus:"amzn1.imdb.w2w.provider.cbs_aa",AMC_PLUS:"amzn1.imdb.w2w.provider.amcplus",PrimeVideo:"amzn1.imdb.w2w.provider.prime_video.PRIME",Netflix:"amzn1.imdb.w2w.provider.netflix",AppleTV:"amzn1.imdb.w2w.provider.appletv",Hulu:"amzn1.imdb.w2w.provider.hulu",HBO_MAX:"amzn1.imdb.w2w.provider.hbo_max",Peacock:"amzn1.imdb.w2w.provider.peacock",Starz:"amzn1.imdb.w2w.provider.starz",Showtimes:"amzn1.imdb.w2w.provider.showtime"},td=C()`
    query StreamingPicks_WatchNow($titleIds: [ID!]!, $providerId: ID!) {
        titles(ids: $titleIds) {
            id
            watchOption(providerId: $providerId) {
                link(platform: WEB)
                provider {
                    refTagFragment
                }
            }
        }
    }
`,tc=()=>({watchNowText:(0,u.N)({id:"common_buttons_watchNow",defaultMessage:"Watch now"}),includedWithPrimeText:(0,u.N)({id:"streamingPicks_providerDescription_withPrime",defaultMessage:"included with Prime"}),withSubscriptionText:(0,u.N)({id:"streamingPicks_providerDescription_withSubscription",defaultMessage:"with subscription"}),onHuluText:(0,u.N)({id:"streamingPicks_providerDescription_onHulu",defaultMessage:"on Hulu.com and the Hulu app"}),withPrimeVideoChannelsText:(0,u.N)({id:"streamingPicks_providerDescription_withPrimeVideoChannels",defaultMessage:"with Prime Video Channels"})}),tp=(e,t)=>{let i=e.map(e=>e.title.id),[r]=(0,eA.E)({query:td,variables:{titleIds:i,providerId:t},context:{personalized:!1,serverSideCacheable:!0}}),a=r.fetching?{}:r?.data?.titles.reduce((e,t)=>(t?.id&&(e[t?.id]=t?.watchOption),e),{})||{};return{fetching:r.fetching,byTitle:a}},tu=e=>{let{tabIndex:t,providerId:i,providerDescription:a,streamingTitles:n}=e,s=(0,b.Lz)().value,{adPreferencesLinkBuilder:l}=(0,x.WOb)(),d=tc(),c=tp(n,i),p=(0,Q.Ok)().adSlotsInfo,u=(0,T.EJ)(),m=(0,to.Z)();(0,e1.b)(n.map(e=>e.title));let g=(e,t)=>{let i=c.byTitle[e],r={id:e,prefix:s,suffix:`tt_${t+1}`};return i?m({titleId:e,watchOption:i,refMarker:r,adSlotsInfo:p}):{}},h=(e,t,i)=>{let r=g(e,i);if(0!==Object.keys(r).length||c.fetching)return{props:{...r,className:"title-watchnow-button"},text:d.watchNowText,fetching:c.fetching}},f=tm((e=>{switch(e){case tl.PrimeVideo:return d.includedWithPrimeText;case tl.Netflix:case tl.AppleTV:case tl.HBO_MAX:case tl.AMC_PLUS:case tl.Peacock:case tl.ParamountPlus:return d.withSubscriptionText;case tl.Hulu:return d.onHuluText;case tl.Starz:case tl.Showtimes:return d.withSubscriptionText;default:return""}})(i),a);return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)(tg,{className:"streaming-picks-description",children:[f,i===tl.ParamountPlus&&0===t&&(0,r.jsx)(r.Fragment,{children:(0,r.jsx)(ts.$,{includeSpacingDot:!0,adFeedbackUrl:l({refSuffix:b.Cd.EMPTY}),inheritFontSize:!0})})]}),(0,r.jsx)(o.Shoveler,{onPageChange:u,children:n.map((e,t)=>(0,r.jsx)(e2.c,{refTagFromGraph:c.byTitle[e.title.id]?.provider.refTagFragment,index:t+1,className:"streaming-picks-title",data:e.title,alternateButton:h(e.title.id,i,t)},e.title.id))},`${t}-${i}`)]})},tm=(e,t)=>{let i=e||t;return i?`${i[0].toLowerCase()}${i.slice(1)}`:""},tg=s.ZP.p.withConfig({componentId:"sc-14743c42-0"})(["",";margin-bottom:1rem;"],(0,c.setPropertyToSpacingVar)("margin-left","ipt-pageMargin")),th=e=>{let{providerPicks:t,preferredWatchProviders:i=[]}=e,n=(0,b.Lz)().value,s=(0,T.EO)(),l=ta(t.map(e=>({id:e.provider.id,label:e.provider.name.value})),i),[d,c]=(0,a.useState)(l[0]?.id);if(t.length<1)return null;let p=tf(t,d);return p?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(tb,{"data-testid":"streaming-picks-tab-container",children:(0,r.jsx)(o.Tabs,{className:"streaming-picks-tabs",tabs:l,onChange:e=>{c(e),tx(n,t,e,s)}},"tabs")}),(0,r.jsx)("div",{"data-testid":"streaming-picks-shoveler",children:(0,r.jsx)(tu,{...p})})]}):null},tf=(e,t)=>{if(!t)return null;let i=e.findIndex(e=>e.provider.id===t);if(-1===i)return null;let r=e[i];return{tabIndex:i,providerId:t,providerDescription:r.provider.description?.value,streamingTitles:r.titles}},tx=(e,t,i,r)=>{r({refMarkerString:tn(e,t,i),pageAction:"tab-select"})},tb=s.ZP.div.withConfig({componentId:"sc-a6e5c7a6-0"})(["",";margin-bottom:1rem;"],(0,c.setPropertyToSpacingVar)("margin-left","ipt-pageMargin")),tT=e=>{let t=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}}),i=tv(e.data),a=t?ty(e.data):[],n=(0,ey.JY)({id:"streaming-picks",height:"title-cards",shouldRender:()=>i.length>0},e);return(0,r.jsx)(ey.GN,{...n,children:(0,r.jsx)(th,{providerPicks:i,preferredWatchProviders:a})})},tv=e=>e&&e.streamingTitles?e.streamingTitles.filter(e=>e.provider&&e.titles&&e.titles.edges.length>0).map(e=>({provider:e.provider,titles:(0,m.b)(e.titles.edges)})):[],ty=e=>(0,m.b)(e?.user?.preferredStreamingProviders.streamingProviders.edges);var t_=e=>(0,r.jsx)(b.xm,{value:b.Cd.STREAMING_PICKS,children:(0,r.jsx)(tT,{...e})});let tC=C()`
    query HomepageStreamingPicks(
        $includeUserPreferredServices: Boolean! = false
    ) {
        streamingTitles {
            provider {
                id
                name {
                    value
                }
                description {
                    value
                }
                refTagFragment
            }
            titles(first: 25) {
                edges {
                    node {
                        title {
                            ...BaseTitleCard
                            ...TitleCardTrailer
                        }
                    }
                }
            }
        }
        user @include(if: $includeUserPreferredServices) {
            ...UserPreferredServices
        }
    }
    ${eR.sq}
    ${eR.F4}
    ${tr.R}
`,tw=(0,eD.O)({query:e=>{let{isLoggedIn:t}=e??{},i=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}})&&t,[r]=(0,eA.E)({query:tC,variables:{includeUserPreferredServices:i},context:{personalized:i||!1,serverSideCacheable:!1,clientSideBatch:!1}});return r},component:e=>(0,r.jsx)(t_,{...e})}),tS={id:"homepage_main_category_exploreStreaming",defaultMessage:"Explore what’s streaming"},tj={editPreferredServicesButton:"exploreStreaming_editPreferredServicesButton",exploreStreamingtitle:"exploreStreaming_title",setYourPreferredServicesButton:"exploreStreaming_setYourPreferredServicesButton"};var tI={StreamingPicksEntity:tw},tE=e=>{let{pageQueryData:t}=e,i=(0,tt.nu)(),n=a.useRef(null),s=(0,eh.T)(n,{root:null,threshold:0,rootMargin:"300px"}),l=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}});return(0,r.jsx)(X.Z,{name:"ExploreStreaming",children:(0,r.jsx)("div",{ref:n,children:(0,r.jsxs)(ea,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.CategoryTitle,{"data-testid":tj.exploreStreamingtitle,actions:!!l&&(0,r.jsx)(tP,{refSuffix:[b.Cd.STREAMING_PICKS,b.Cd.BUTTON],"data-testid":i?tj.editPreferredServicesButton:tj.setYourPreferredServicesButton}),children:(0,r.jsx)(ei.q,{...tS})})}),(0,r.jsx)(er.Z,{groupConfig:tI,pageQueryData:t,hasIntersected:s})]})})})};let tP=(0,s.ZP)(ti.Z).withConfig({componentId:"sc-2b65d4af-0"})(["","{margin-top:",";}"],c.mediaQueries.breakpoints.below.m,c.spacing.m);var tN=i(81999),tM=i(88854),tk={featuredToday:{component:()=>(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_FEATURED,children:(0,r.jsx)(eu,{slotNamePrefix:"featured-today"})})},eventOscars:{component:()=>{let e=(0,u.N)({id:"editorialCarousel_special_event",defaultMessage:"Spotlight: Oscars (2020)"});return(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_OSCARS,children:(0,r.jsx)(eu,{slotNamePrefix:"event-oscars",title:e})})}}};let tR=(0,tN.vU)({title:{id:"homepage_main_category_featuredToday",defaultMessage:"Featured today"}});var tO=e=>{let{pageQueryData:t}=e,i=(0,ex.Z)(),a=(0,tM.kp)().isValid;return(0,r.jsx)(X.Z,{name:"FeaturedToday",children:(0,r.jsxs)(ea,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:2,children:(0,r.jsxs)(o.PageSection,{children:[a&&(0,r.jsx)(o.CategoryTitle,{children:i.formatMessage(tR.title)}),(0,r.jsx)(er.Z,{groupConfig:tk,pageQueryData:t,hideErrors:!1})]})}),(0,r.jsx)(o.PageGrid.Item,{span:1,children:(0,r.jsx)(U.ZP,{name:H.A.INLINE40})})]})})},tA=i(76857),tD=i(95746);let tL=e=>Object.keys(e).filter(t=>{let i=e[t].transformedArguments;return(0,tD.J)(i?.errors)});var t$=i(23906),tZ=i(24391);let tB=Object.freeze({slidesPerView:1,effect:"slide",autoplay:{delay:5e3},loop:!0,observer:!0,threshold:20});var tV=i(81611),tF=i(51244),tW=i(99672),tG=i(1833);let tz=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-0"})(["height:52px;"]),tU=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-1"})(["height:","px;overflow:hidden;position:relative;","{height:","px;}"],444,c.mediaQueries.breakpoints.only.l,339),tq=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-2"})(["position:absolute;top:0;bottom:0;left:0;right:0;overflow:hidden;background:linear-gradient( 0deg,transparent 0%,transparent 50%,rgba(",",0.7) 78%,rgba(",",1) 100% );.editorial-slots{height:100%;display:flex;flex-direction:column;top:-","px;position:absolute;width:100%;","{top:-","px;}}"],(0,c.getColorVar)("ipt-baseAlt-shade3-rgb"),(0,c.getColorVar)("ipt-baseAlt-shade3-rgb"),296,c.mediaQueries.breakpoints.only.l,226),tH=(0,s.ZP)(o.Poster.Image).withConfig({componentId:"sc-9b43ec2b-3"})(["height:100%;width:100%;left:0;bottom:0;img{height:100%;width:100%;}"]),tQ=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-4"})(["padding:0px 16px;flex:0 0 ","px;","{flex:0 0 ","px;}width:100%;position:relative;overflow:hidden;transition:all 300ms;&.transit-enter{flex-basis:0;}&.transit-enter-active{flex-basis:","px;","{flex-basis:","px;}}&.transit-exit{flex-basis:","px;","{flex-basis:","px;}}&.transit-exit-active{flex-basis:0;}"],113,c.mediaQueries.breakpoints.above.xl,148,113,c.mediaQueries.breakpoints.above.xl,148,113,c.mediaQueries.breakpoints.above.xl,148),tY=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-5"})(["left:16px;bottom:0;width:88px;padding-top:16px;","{width:67px;}"],c.mediaQueries.breakpoints.only.l),tX=s.ZP.a.withConfig({componentId:"sc-9b43ec2b-6"})(["&:hover{cursor:pointer;.editorial-play-icon{",";}}position:absolute;top:0;right:0;left:112px;","{left:83px;padding:16px 8px 0;overflow:hidden;text-decoration:none;}padding:18px 8px 0;overflow:hidden;text-decoration:none;",";"],(0,c.setPropertyToColorVar)("color","ipt-on-base-accent1-color"),c.mediaQueries.breakpoints.only.l,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),tK=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-7"})(["flex:0;width:100%;text-align:left;position:relative;"]),tJ=(0,s.ZP)(tK).withConfig({componentId:"sc-9b43ec2b-8"})(["margin-bottom:3px;&.reactions{display:flex;align-items:flex-end;margin-bottom:10px;","{margin-bottom:6px;}}"],c.mediaQueries.breakpoints.only.l),t0=(0,s.ZP)(tK).withConfig({componentId:"sc-9b43ec2b-9"})(["max-height:40px;"]),t1=(0,s.iv)(["",";text-align:start;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;"],(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),t2=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-10"})([""," ",";font-weight:400;width:100%;display:inline-block;",";white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;max-height:40px;"],t1,(0,c.setTypographyType)("subtitle"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-color")),t3=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-11"})([""," ",";width:100%;display:inline-block;&.reactions{display:block;","{display:none;}}"],t1,(0,c.setTypographyType)("bodySmall"),c.mediaQueries.breakpoints.only.l),t4=(0,s.ZP)(eB.I).withConfig({componentId:"sc-9b43ec2b-12"})(["margin-left:0;margin-top:4px;","{margin-bottom:0;margin-top:2px;}"],c.mediaQueries.breakpoints.only.l),t8=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-13"})(["&:not(.reactions){"," ",";display:inline-block;}&.reactions{",";",";}"],t1,(0,c.setTypographyType)("bodySmall"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color"),(0,c.setTypographyType)("bodySmall")),t5=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-14"})([""," ",";display:block;width:100%;padding:4px 0;",";text-align:left;"],t1,(0,c.setTypographyType)("headline6"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-accent1-color")),t6=(0,s.iv)(["height:32px;width:32px;&.reactions{","{height:28px;width:28px;}}margin-right:8px;",";"],c.mediaQueries.breakpoints.only.l,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-color")),t7=(0,s.ZP)(o.Icon).withConfig({componentId:"sc-9b43ec2b-15"})(["",""],t6);(0,s.ZP)(o.Icon).withConfig({componentId:"sc-9b43ec2b-16"})(["color:#cf1f4a;",""],t6);let t9=(e,t)=>(t+e%t)%t,ie=e=>{let{transformedArguments:t}=e;if(t)return t.promotedVideoData&&(t=t.promotedVideoData),{imageModel:t.posterImage,titleText:t.headline}},it=e=>{let{transformedArguments:t}=e;return t?(t.promotedVideoData&&(t=t.promotedVideoData),{runtime:t.runtime,videoTitle:t.subHeadline,videoId:t.videoId,videoContentType:t.videoContentType,listId:t.listId}):void 0},ii=(e,t,i)=>{let r=t[e]?.slotName,a=i.transformedPlacements[r];if(!a)return;let n=ie(a),s=it(a),o=a.transformedArguments?.promotedVideoData?.adData,l=`${e}-${Math.random()}`;return{slotIndex:e,peekImageModel:n,peekVideoSlateModel:s,adData:o,key:l}},ir=(e,t,i)=>t===t9(e-1,i)?-1:t9(t-e,i),ia=(e,t,i)=>{let r=t.length,a=[],n=e+-1;for(let e=n;e<n+6;e+=1){let n=ii(t9(e,r),t,i);n&&a.push(n)}return a},is=(e,t,i,r)=>{let a=i.length,n=t.slice();if(e<0)for(let t=e;t<0;t+=1){let e=t9(n[0]?.slotIndex-1,a);n.unshift(ii(e,i,r)),n.pop()}else if(e>0)for(let t=0;t<e;t+=1){let e=t9(n[n.length-1]?.slotIndex+1,a);n.push(ii(e,i,r)),n.shift()}return n};var io=e=>{let{slots:t,swiper:i}=e,{videoSingleLinkBuilder:n}=(0,x.WOb)(),[s,o]=(0,a.useState)(0),l=(0,tW.Z)(s),d=(0,tM.kp)(),{makeRefMarker:c}=(0,b.Lz)(),p=(0,u.N)({id:"hero_video_up_next",defaultMessage:"Up next"}),m=ia(0,t,d),[g,h]=(0,a.useState)(m),f=t.length;(0,a.useEffect)(()=>{if(i)return i.on("slideChangeTransitionStart",e),function(){i.off("slideChangeTransitionStart",e)};function e(){let{realIndex:e}=this;o(e)}},[i]),(0,a.useEffect)(()=>{h(is(ir(l||0,s,f),g,t,d))},[s]);let T=(0,a.useRef)(null);return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(tz,{children:(0,r.jsx)(t5,{children:p})}),(0,r.jsx)(tU,{children:(0,r.jsx)(tq,{children:(0,r.jsx)(tF.Z,{className:"editorial-slots",children:g.map(e=>{let t;if(!e)return null;let{slotIndex:i,peekImageModel:a,peekVideoSlateModel:s,adData:o,key:l}=e,{runtime:d,videoId:p,videoTitle:u,listId:m}=s||{},{imageModel:g,titleText:h}=a||{},f=(0,r.jsx)(t7,{type:"inline",className:y()("editorial-play-icon","reactions"),name:"play-circle-outline-large-inline"});if(p){let e=c({t:b.Cd.VIDEO,n:i+1}),r=n({viconst:p,refSuffix:b.Cd.EMPTY,query:m?{listId:m}:void 0});t=(0,tG.Lr)(r,e)}return(0,r.jsx)(tV.Z,{classNames:"transit",nodeRef:T,timeout:300,children:(0,r.jsxs)(tQ,{ref:T,children:[(0,r.jsx)(tY,{children:(0,r.jsx)(tH,{className:"peek-poster-image",imageModel:g,dynamicWidth:!0})}),(0,r.jsxs)(tX,{href:t,children:[(0,r.jsxs)(tJ,{className:"reactions",children:[f,(0,r.jsx)(t8,{className:"reactions",children:d})]}),(0,r.jsx)(t0,{children:(0,r.jsx)(t2,{children:h})}),(0,r.jsx)(tK,{children:(0,r.jsx)(t3,{className:"reactions",children:u})}),!o&&(0,r.jsx)(t4,{associatedConstId:p,entityType:"video"})]})]})},l)})})})})]})},il=i(3820);i(80167);var id=i(59899);let ic="hero-promoted-video-ad",ip=(e,t,i)=>{let r=[];return e&&r.push({slotName:ic}),t.forEach(e=>{i.transformedPlacements[e]&&r.push({slotName:e})}),r},iu=(e,t)=>{let{slotName:i}=e;return(0,r.jsx)(el.Z,{slotName:i},t)},im=s.ZP.div.withConfig({componentId:"sc-244aa702-0"})(["position:relative;margin:8px auto;display:flex;justify-content:center;max-width:1280px;"," ","{flex-direction:column;}"],(0,c.setPropertyToColorVar)("background","ipt-baseAlt-color"),c.mediaQueries.breakpoints.below.l),ig=s.ZP.div.withConfig({componentId:"sc-244aa702-1"})(["flex:846;margin:0 8px;position:relative;overflow:hidden;","{flex:664;}","{flex:100%;}"],c.mediaQueries.breakpoints.only.l,c.mediaQueries.breakpoints.below.l),ih=s.ZP.div.withConfig({componentId:"sc-244aa702-2"})(["flex:402;margin:0 8px 0 4px;position:relative;overflow:hidden;display:flex;flex-direction:column;justify-content:space-between;","{flex:328;}","{flex:0;}"],c.mediaQueries.breakpoints.only.l,c.mediaQueries.breakpoints.below.l),ix=s.ZP.div.withConfig({componentId:"sc-244aa702-3"})(["width:100%;","{display:none;}"],c.mediaQueries.breakpoints.below.l),ib=s.ZP.div.withConfig({componentId:"sc-244aa702-4"})(["padding:16px 16px 0;text-align:left;","{background:none;}"],c.mediaQueries.breakpoints.below.l),iT=(0,s.ZP)(e=>{let{className:t,enableNavigation:i,enableVirtualSlides:n,carouselOptions:s,customNavigation:o,onInitialize:l,children:d}=e,c=(0,a.useRef)(null),p=y()(t,"swiper-container"),[u,m]=(0,a.useState)(d),[g,h]=(0,a.useState)(0),[f,x]=(0,a.useState)(0),[b,T]=(0,a.useState)(),{navigation:v={nextEl:".swiper-button-next",prevEl:".swiper-button-prev"},virtual:_={slides:d,addSlidesBefore:2,addSlidesAfter:2,renderExternal(e){let{slides:t,offset:i}=e;m(t),h(i)}},...C}=s,w=()=>{if(c?.current)try{c.current.update()}catch(e){}},S=function(e){let t,i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:250;return r=>{t&&clearTimeout(t),t=setTimeout(e,i,r)}};return(0,a.useEffect)(()=>{c.current=new il.Z(c.current,{navigation:i&&v,pagination:!1,scrollbar:!1,virtual:n&&_,...C,on:{init(){let{params:e,activeIndex:t}=this,{slidesPerView:i}=e;x(Math.round(i)),T(t),l(c.current.swiper)},slideChange(){let{activeIndex:e}=this;T(e)}}}),l(c.current)},[]),(0,a.useEffect)(()=>w()),(0,a.useEffect)(()=>(window&&window.addEventListener("resize",S(w)),()=>{window&&window.removeEventListener("resize",S(w))}),[]),(0,r.jsxs)("div",{className:p,ref:c,children:[(0,r.jsx)("div",{className:"swiper-wrapper",children:n?u&&u.map(e=>null!==e&&(0,r.jsx)("div",{className:"swiper-slide",style:{left:`${g}px`},children:e},e.key)):a.Children.toArray(d).filter(e=>null!==e).map((e,t)=>(0,r.jsx)(id.E.Provider,{value:{indexInCarousel:t,initialSlidesVisible:f,isInitiallyVisible:t<f,isActive:b===t,carouselElementRef:c},children:(0,r.jsx)("div",{className:"swiper-slide",children:e})},t))}),o]})}).withConfig({componentId:"sc-244aa702-5"})(["height:100%;width:100%;.swiper-slide{width:100%;}"]),iv=s.ZP.a.withConfig({componentId:"sc-244aa702-6"})(["text-decoration:none;",";",";svg{vertical-align:bottom;}&:hover{",";}"],(0,c.setTypographyType)("headline6"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-accent1-color")),iy=(0,s.iv)(["background-image:none;position:absolute;z-index:100;top:30%;outline:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-o-user-select:none;user-select:none;&.swiper-button-disabled{visibility:hidden;}","{&.swiper-button-next,&.swiper-button-prev{visibility:hidden;}}"],c.mediaQueries.breakpoints.below.m),i_=s.ZP.div.withConfig({componentId:"sc-244aa702-7"})(["&.swiper-button-next{right:0;","}"],iy),iC=s.ZP.div.withConfig({componentId:"sc-244aa702-8"})(["&.swiper-button-prev{left:0;","}"],iy),iw=(0,s.ZP)(o.Pager).withConfig({componentId:"sc-244aa702-9"})(["&.swiper-buttons{","{padding:20px 12px;}}"],c.mediaQueries.breakpoints.above.m);var iS=()=>{let e=(0,t$.wL)("AutorotateVideoCarousel"),[t]=(0,tZ.i)(),{trailersLinkBuilder:i}=(0,x.WOb)(),s=(0,T.EO)(),[l,d]=(0,a.useState)(),c=(0,u.N)({id:"hero_video_browse_trailers",defaultMessage:"Browse trailers"}),p=(0,tM.kp)(),m=p.isDebug,g=new Set(tL(p.transformedPlacements));g.forEach(i=>{let r=p.transformedPlacements[i],a=r.transformedArguments?.errors;a&&a.length>0&&(t(e,n.NextMetrics.EDITORIAL_ERROR,1),a.map(t=>{((0,tD.X)(t)||m)&&e.error({code:t.code,creativeId:r.symphonyMetadata?.creativeId,placementId:r.symphonyMetadata?.placementId,componentName:r.componentName,context:t.context})}))});let h=es("hero-video").reduce((e,t)=>g.has(t.name)?e:[...e,t.name],[]),f=!!p.transformedPlacements[ic]&&!g.has(ic),v=h.map(e=>Number(!!p.transformedPlacements[e])).reduce((e,t)=>e+t,0),_=Number(f)+v;if((0,a.useEffect)(()=>{if(l&&!(_<=0))return l.on("slideChangeTransitionEnd",e),function(){l.off("slideChangeTransitionEnd",e)};function e(){let{realIndex:e}=this;(0===e||e===_-1)&&l?.slideToLoop(e,0,!1)}},[l,_]),_<=0)return null;let C=i({refSuffix:b.Cd.SEE_MORE}),w=ip(f,h,p),S=w.map((e,t)=>iu(e,t)),j=_<2,I=(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(iC,{className:y()("swiper-button-prev",{"swiper-button-disabled":j}),children:(0,r.jsx)(iw,{className:"swiper-buttons",direction:"left",isVisible:!0,size:"large",onSelect:()=>{s({refMarkerSuffix:b.Cd.PREVIOUS,pageAction:"prev-button-click"})}})}),(0,r.jsx)(i_,{className:y()("swiper-button-next",{"swiper-button-disabled":j}),children:(0,r.jsx)(iw,{className:"swiper-buttons",direction:"right",isVisible:!0,size:"large",onSelect:()=>{s({refMarkerSuffix:b.Cd.NEXT,pageAction:"next-button-click"})}})})]});return(0,r.jsxs)(im,{children:[(0,r.jsx)(ig,{children:(0,r.jsx)(iT,{carouselOptions:tB,customNavigation:I,enableNavigation:!0,className:tA.oM,onInitialize:d,children:S})}),(0,r.jsxs)(ih,{children:[(0,r.jsx)(ix,{children:(0,r.jsx)(io,{slots:w,swiper:l})}),(0,r.jsx)(ib,{children:(0,r.jsxs)(iv,{href:C,className:"example-headline6",children:[c,(0,r.jsx)(o.Icon,{name:"chevron-right",className:"chevron-right"})]})})]})]})};let ij=()=>(0,r.jsx)(X.Z,{name:"HeroSection",children:(0,r.jsx)(ea,{children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(iE,{children:(0,r.jsx)(iS,{})})})})});var iI=()=>(0,r.jsx)(b.xm,{value:b.Cd.HERO_CAROUSEL,children:(0,r.jsx)(ij,{})});let iE=s.ZP.div.withConfig({componentId:"sc-39f7131b-0"})(["max-width:1280px;"]);var iP=i(84355),iN=i(51415),iM=i(76018);let ik=e=>{let{chips:t}=e;return(0,r.jsx)(iR,{children:t.map((e,t)=>(0,r.jsx)(o.Chip,{label:e.category,href:e.link,className:"chip"},`news-chip-${t}`))})},iR=(0,s.ZP)(o.ChipList).withConfig({componentId:"sc-5d76741-0"})(["",";margin-top:",";"],(0,c.setPropertyToSpacingVar)("padding-left","ipt-pageMargin"),c.spacing.m),iO=()=>{let{newsCelebrityLinkBuilder:e,newsMovieLinkBuilder:t,newsTopLinkBuilder:i,newsTvLinkBuilder:r}=(0,x.WOb)(),a=(0,u.N)({id:"topNews_chip_top_news",defaultMessage:"Top news"}),n=(0,u.N)({id:"topNews_chip_movie_news",defaultMessage:"Movie news"}),s=(0,u.N)({id:"topNews_chip_tv_news",defaultMessage:"TV news"}),o=(0,u.N)({id:"topNews_chip_celebrity_news",defaultMessage:"Celebrity news"});return[{category:a,link:i({refSuffix:[b.Cd.TOP,b.Cd.TAB]})},{category:n,link:t({refSuffix:[b.Cd.MOVIE,b.Cd.TAB]})},{category:s,link:r({refSuffix:[b.Cd.TV,b.Cd.TAB]})},{category:o,link:e({refSuffix:[b.Cd.CELEBRITY,b.Cd.TAB]})}]},iA=e=>e&&(e?.news?e.news.edges??[]:void 0)||[],iD=e=>{let{data:t}=e,{newsTopLinkBuilder:i}=(0,x.WOb)(),a=iO(),n=iA(t),s=(0,ey.JY)({id:"top-news",height:"other",title:(0,u.N)({id:"topNews_header",defaultMessage:"Top news"}),link:i({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>n.length>2},e);return(0,r.jsxs)(ey.GN,{...s,children:[(0,r.jsx)("div",{"data-testid":"news-shoveler",children:(0,r.jsx)(iM.X,{topNewsItems:n})}),(0,r.jsx)("div",{"data-testid":"news-chips",children:(0,r.jsx)(ik,{chips:a})})]})};var iL=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_NEWS,children:(0,r.jsx)(iD,{...e})});let i$={component:e=>(0,r.jsx)(iL,{...e}),shouldRender:e=>!0,fragment:{name:"TopNews",gql:C()`
            fragment TopNews on Query {
                news(category: TOP, first: 5) {
                    edges {
                        ...NewsItem
                    }
                }
            }
            ${iN.s}
        `}},iZ={EditorsPicksEntity:{component:()=>{let e=(0,u.N)({id:"editorialCarousel_editors_picks",defaultMessage:"Editor's picks"});return(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_PICKS,children:(0,r.jsx)(eu,{slotNamePrefix:"editors-picks",title:e})})}},BornTodayEntity:iP.Z,TopNewsEntity:i$};var iB=e=>{let{pageQueryData:t}=e,i=a.useRef(null),n=(0,eh.T)(i,{root:null,threshold:0,rootMargin:"200px"});return(0,r.jsx)(X.Z,{name:"MoreToExplore",children:(0,r.jsx)(ea,{className:"page-grid",children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsxs)("div",{ref:i,children:[(0,r.jsx)(o.CategoryTitle,{"data-testid":"moreToExplore_title",children:(0,r.jsx)(ei.q,{id:"common_more_to_explore",defaultMessage:"More to explore"})}),(0,r.jsx)(er.Z,{groupConfig:iZ,pageQueryData:t,hasIntersected:n})]})})})})};let iV={MostPopularStreamingEntity:i(76574).w},iF=(0,tN.vU)({header:{id:"homepage_main_category_exploreStreaming",defaultMessage:"Explore what's streaming"}});var iW=e=>{let{pageQueryData:t}=e,i=a.useRef(null),n=(0,ex.Z)(),s=(0,eh.T)(i,{root:null,threshold:0,rootMargin:"300px"});return(0,r.jsx)(X.Z,{name:"MostPopularStreaming",children:(0,r.jsx)("div",{ref:i,children:(0,r.jsxs)(ea,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.CategoryTitle,{"data-testid":"morePopularStreaming_title",children:n.formatMessage(iF.header)})}),(0,r.jsx)(er.Z,{groupConfig:iV,pageQueryData:t,hasIntersected:s})]})})})},iG=i(58139);let iz=e=>{let{value:t}=(0,b.Lz)(),{whatToWatchFanFavoritesLinkBuilder:i}=(0,x.WOb)(),{data:n}=e,s=(0,m.b)(n?.fanPicksTitles?.edges),o=n?.fanPicksTitles?.refTag?.ep13nReftag||void 0,l=(0,u.N)({id:"fan_favorites",defaultMessage:"Fan favorites"}),d=(0,u.N)({id:"fan_favorites_description",defaultMessage:"This week's top TV and movies"}),c=(0,ey.JY)({id:"fan-picks",height:"title-cards",title:l,description:d,link:i({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>s.length>5},e);return(0,r.jsx)(ey.GN,{...c,children:(0,r.jsx)(iG.t,{titles:s,cardOverride:e=>e.map((e,i)=>(0,a.createElement)(e2.c,{...e,key:`${t}-${e.data.id}-${i}`,className:"fan-picks-title",refTagFromGraph:o,index:i+1}))})})};var iU=e=>(0,r.jsx)(b.xm,{value:b.Cd.FAN_FAV,children:(0,r.jsx)(iz,{...e})});let iq=C()`
    query FanFavoritesHomepage($fanPicksFirst: Int!, $fanPicksAfter: ID) {
        fanPicksTitles(first: $fanPicksFirst, after: $fanPicksAfter) {
            edges {
                node {
                    ...BaseTitleCard
                    ...TitleCardTrailer
                    ...TitleWatchOption
                }
            }
            refTag {
                ep13nReftag
            }
        }
    }
    ${eR.sq}
    ${eR.F4}
    ${e3.sG.titleWatchOption}
`,iH=(0,eD.O)({query:()=>{let[e]=(0,eA.E)({query:iq,requestPolicy:"cache-and-network",variables:{fanPicksFirst:30},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!0}});return e},component:e=>(0,r.jsx)(iU,{...e})});var iQ=i(96621),iY=i(84314),iX=i(43421),iK=i(60635);let iJ=e=>{let{classname:t,items:i}=e,{createButton:a,createPrompt:n}=(0,e3.V1)(),s=(0,T.EJ)();return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(o.Shoveler,{onPageChange:s,children:i.map((e,i)=>(0,r.jsx)(e2.c,{className:t,data:e,index:i+1,alternateButton:a(e,i)},e.id))}),n()]})},i0=e=>{let{fromYourWatchlistTitles:t}=e;return void 0===t?null:(0,r.jsx)("div",{"data-testid":"logged-in-state",className:"fyw-logged-in",children:(0,r.jsx)(iJ,{classname:"fyw-title",items:t})})},i1={id:"from_your_watchlist",defaultMessage:"From your Watchlist"},i2={id:"from_your_watchlist_description",defaultMessage:"Movies and TV shows that you have watchlisted"},i3=e=>{let{data:t,error:i,isSignedIn:a}=e,n=(0,ex.Z)(),{whatToWatchFromWatchlistLinkBuilder:s}=(0,x.WOb)(),o=t?.predefinedList?.unreleasedCount?.total||0,l=t?(0,m.J)(t?.predefinedList):[];(0,iK.Q)(l);let d=a&&0!==l.length,c=t?.predefinedList?.ratedCount?.total||0,p=n.formatMessage(i1),u=n.formatMessage(i2),g=(0,ey.JY)({id:"from-your-watchlist",height:"title-cards",title:p,description:d?u:void 0,link:s({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>!0},e);return i?null:(0,r.jsx)(ey.GN,{...g,children:i4(a,c,o,l)})},i4=(e,t,i,a)=>e&&a.length>0?(0,r.jsx)(i0,{fromYourWatchlistTitles:a}):(0,r.jsx)(iX.OW,{isLoggedIn:e,hasRatedTitles:!!t&&t>0,hasUnreleasedTitlesInWatchlist:!!i&&i>0});var i8=e=>(0,r.jsx)(b.xm,{value:b.Cd.FROM_YOUR_WATCHLIST,children:(0,r.jsx)(i3,{...e})});let i5=(0,eD.O)({query:e=>{let{isLoggedIn:t}=e??{},[i]=(0,eA.E)({query:iQ.y,requestPolicy:"cache-and-network",variables:{first:30},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!0},pause:!t});return t?i:{fetching:!1,stale:!1}},component:e=>{let t=(0,iY.n)(),i={...e,isSignedIn:t};return(0,r.jsx)(i8,{...i})}});var i6=i(64411),i7=i(79544);let i9=C()`
    query PopularInterests {
        popularInterests(first: 50) {
            edges {
                node {
                    ...InterestCard
                }
            }
        }
    }
    ${i7.b}
`,re=(0,eD.O)({query:e=>{let[t]=(0,eA.E)({query:i9,context:{personalized:!1,serverSideCacheable:!0,clientSideBatch:!0}});return t},component:e=>(0,r.jsx)(i6.Z,{...e})});var rt=i(89578);let ri=(0,eD.O)({query:()=>({fetching:!1,stale:!1}),component:e=>(0,ee.hg)({weblabID:J.lh.IMDB_SUGGESTED_TV_FROM_RATINGS_646975,treatments:{T1:!0}})?(0,r.jsx)(rt.Z,{shouldClientSideBatch:!0}):null}),rr=C()`
    query NameIdsInFavPeople {
        favPeopleNameIds: predefinedList(classType: FAVORITE_ACTORS) {
            nameListItemSearch(
                first: 250
                sort: { by: DATE_ADDED, order: DESC }
            ) {
                edges {
                    listItem: name {
                        id
                    }
                }
            }
        }
    }
`,ra=C()`
    query TitlesFromFavPeople(
        $nameIds: [ID!]!
        $startDate: Date!
        $endDate: Date!
    ) {
        favPeopleTitles: advancedTitleSearch(
            first: 250
            sort: { sortBy: RELEASE_DATE, sortOrder: ASC }
            constraints: {
                titleTypeConstraint: {
                    excludeTitleTypeIds: ["tvEpisode", "podcastEpisode"]
                }
                creditedNameConstraint: { anyNameIds: $nameIds }
                releaseDateConstraint: {
                    releaseDateRange: { start: $startDate, end: $endDate }
                }
            }
        ) {
            edges {
                node {
                    title {
                        ...BaseTitleCard
                        releaseDate {
                            displayableProperty {
                                value {
                                    plainText
                                }
                            }
                        }
                        credits(first: 5, filter: { names: $nameIds }) {
                            edges {
                                node {
                                    name {
                                        id
                                        nameText {
                                            text
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    ${eR.sq}
`;var rn=i(84636),rs=i.n(rn),ro=i(40981),rl=i(18355),rd=i(14149),rc=i(91359),rp=i(70902);let ru=new Date,rm=ru.toISOString().split("T")[0],rg=new Date(ru.getFullYear(),ru.getMonth()-2,ru.getDate()).toISOString().split("T")[0],rh=new Date(ru.getFullYear(),ru.getMonth()+2,ru.getDate()).toISOString().split("T")[0],rf=e=>{let{initialData:t}=e,i=(0,ex.Z)(),n=(0,tt.nu)(),s=(0,b.Lz)().value,{chartStarMeterLinkBuilder:d,titleMainLinkBuilder:c}=(0,x.WOb)(),p=(0,eT.B)().context,u=(0,T.EJ)(),m=(0,o.useBreakpointsAsConfig)(),g=m.xs||m.s,[h,f]=(0,a.useState)(!1),[v,y]=(0,a.useState)(!0),[_,C]=(0,a.useState)((t?.favPeopleNameIds?.nameListItemSearch?.edges??[]).map(e=>e.listItem?.id).filter(Boolean)),[w,S]=(0,a.useState)(rg),[j,I]=(0,a.useState)(rm),[E,P]=(0,a.useState)([]),[{data:N}]=(0,tt.E8)({query:rr,context:{personalized:!0,serverSideCacheable:!1},pause:!n||!(0,l.getIsBrowser)()||_.length>0});(0,a.useEffect)(()=>{N&&C((N?.favPeopleNameIds?.nameListItemSearch?.edges??[]).map(e=>e.listItem?.id).filter(Boolean))},[N]);let[{data:M,fetching:k,error:R}]=(0,tt.E8)({query:ra,variables:{nameIds:_,startDate:w,endDate:j},context:{personalized:!0,serverSideCacheable:!1},pause:!n||!(0,l.getIsBrowser)()||!_.length||!v});if((0,a.useEffect)(()=>{M&&P((M?.favPeopleTitles?.edges??[]).map(e=>e?.node?.title))},[M]),(0,tt.bd)(E.map(e=>({id:e.id}))),!n)return null;let O=i.formatMessage({id:"suggested_tv_from_ratings_upcoming",defaultMessage:"Upcoming"}),A=i.formatMessage({id:"suggested_tv_from_ratings_recent",defaultMessage:"Recent"}),D=i.formatMessage({id:"suggested_tv_from_ratings_switch_aria",defaultMessage:"Switch to show {value} titles"},{value:h?A:O}),L=()=>(0,r.jsxs)(rC,{children:[A,(0,r.jsx)(rw,{ariaLabel:D,checked:h,onChange:()=>{let e=!h;S(e?rm:rg),I(e?rh:rm),f(e),y(!0)}}),O]}),$=!k&&M;return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(en.P,{id:"suggestedFromFavPeople"}),(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsxs)(o.PageSection,{children:[(0,r.jsxs)(rS,{children:[(0,r.jsx)(o.SubSectionTitle,{description:i.formatMessage({id:"favPeople_page_description",defaultMessage:"See recent or upcoming titles from your favorite people"}),children:i.formatMessage({id:"home_favPeople_feature_description",defaultMessage:"Catch up with your favorite people"})}),!g&&(0,r.jsx)(L,{})]}),g&&(0,r.jsx)(L,{}),(k||!M&&!R)&&(0,r.jsx)(rj,{children:(0,r.jsx)(o.Loader,{className:"suggested-titles-loader"})}),R&&!M&&(0,r.jsx)(ry,{children:(0,r.jsx)(rd.ZP,{canRetry:!0,errorMessage:i.formatMessage({id:"home_favPeople_feature_error_state",defaultMessage:"Sorry, there was an issue fetching your favorite names."}),name:"Suggested from favorite people",onClickRetry:()=>y(!0)})}),$&&0===E.length&&(0,r.jsxs)(ry,{children:[(0,r.jsx)(r_,{children:i.formatMessage({id:"home_favPeople_feature_empty_state_1",defaultMessage:"Want better suggestions? Favorite more people!"})}),(0,r.jsx)(o.TextLink,{href:d({refSuffix:b.Cd.SEE_MORE}),text:i.formatMessage({id:"home_favPeople_feature_empty_state_2",defaultMessage:"Start by checking out the most popular celebs"})})]}),$&&E.length>0&&(0,r.jsx)(o.Shoveler,{onPageChange:u,children:E.map((e,t)=>{let a=(0,ew.L)(p,e.originalTitleText,e.titleText)??"",n=rs()(e.credits?.edges??[],"node.name.id");return(0,r.jsx)(o.ShovelerItem,{span:2,children:(0,r.jsxs)(o.PosterCard,{dynamicWidth:!0,children:[(0,r.jsx)(rl.y,{title:{id:e.id,titleText:a,titleTypeId:e.titleType?.id??"",image:e.primaryImage??{}},index:t+1}),(0,r.jsxs)(rv,{children:[(0,r.jsx)(ro.Nf,{canRate:!!e.canRate?.isRatable,hideMaxIMDbRating:!0,hideVoteCountOnSmallBreakpoints:!0,ratingsSummary:e.ratingsSummary?e.ratingsSummary:void 0,showPlaceholderStarIfApplicable:!0,titleId:e.id,titleText:a}),(0,r.jsx)(o.PosterCard.Title,{ariaLabel:i.formatMessage(rc.F.GO_TO,{target:a}),href:c({tconst:e.id,refSuffix:{t:b.Cd.TEXT,n:t+1}}),children:a}),(0,r.jsx)(rT,{children:e.releaseDate?.displayableProperty?.value?.plainText}),(0,r.jsxs)(rb,{children:[n.slice(0,2).map(e=>{let t=e?.node?.name?.nameText?.text;return(0,r.jsx)("div",{children:t},`${s}-creditedName-${e.node.name.id}`)}),n.length>2&&(0,r.jsx)("div",{children:i.formatMessage({id:"home_favPeople_feature_more_people",defaultMessage:"+ {numMore} more"},{numMore:n.length-2})})]}),(0,r.jsx)(rp.Z,{index:t,titleData:e})]})]})},`${s}-item-${e.id}`)})})]})})]})};var rx=e=>(0,r.jsx)(b.xm,{value:b.Cd.SUGGESTED_FROM_FAV_PEOPLE,children:(0,r.jsx)(rf,{...e})});let rb=s.ZP.div.withConfig({componentId:"sc-3c3374c6-0"})(["",";"],(0,c.setTypographyType)("bodySmall")),rT=s.ZP.span.withConfig({componentId:"sc-3c3374c6-1"})(["",";",";margin:"," 0;"],(0,c.setTypographyType)("bodySmall"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color"),c.spacing.xs),rv=s.ZP.div.withConfig({componentId:"sc-3c3374c6-2"})(["display:flex;flex-direction:column;"]),ry=s.ZP.div.withConfig({componentId:"sc-3c3374c6-3"})(["align-items:center;display:flex;flex-direction:column;justify-content:center;margin-left:",";min-height:10rem;"],(0,c.getSpacingVar)("ipt-pageMargin")),r_=s.ZP.div.withConfig({componentId:"sc-3c3374c6-4"})(["font-weight:500;"]),rC=s.ZP.div.withConfig({componentId:"sc-3c3374c6-5"})(["",";align-items:center;display:flex;flex-direction:row;margin-bottom:",";margin-left:",";margin-right:",";width:fit-content;"],(0,c.setTypographyType)("overline"),c.spacing.m,(0,c.getSpacingVar)("ipt-pageMargin"),(0,c.getSpacingVar)("ipt-pageMargin")),rw=(0,s.ZP)(o.Switch).withConfig({componentId:"sc-3c3374c6-6"})(["margin:0 ",";"],c.spacing.xxs),rS=s.ZP.div.withConfig({componentId:"sc-3c3374c6-7"})(["align-items:center;display:flex;flex-direction:row;"]),rj=s.ZP.div.withConfig({componentId:"sc-3c3374c6-8"})(["margin-left:",";text-align:center;width:100%;.suggested-titles-loader{min-height:20rem;}"],(0,c.getSpacingVar)("ipt-pageMargin")),rI=(0,eD.O)({query:()=>{let e=(0,tt.nu)(),t=(0,ee.hg)({weblabID:J.lh.IMDB_SUGGESTED_TV_FROM_RATINGS_646975,treatments:{T1:!0}}),i=e&&t,[r]=(0,tt.E8)({query:rr,context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:i},pause:!i});return r},component:e=>(0,ee.hg)({weblabID:J.lh.IMDB_FAV_PEOPLE_780856,treatments:{T1:!0}})?(0,r.jsx)(rx,{initialData:e.data}):null});var rE=i(49996),rP=i(77845);let rN=e=>{let{items:t,className:i}=e,a=(0,T.EJ)();return(0,r.jsx)(r.Fragment,{children:(0,r.jsx)(o.Shoveler,{className:i,onPageChange:a,children:t.map((e,t)=>(0,r.jsx)(rP.x,{recommendation:e,index:t},e.title.id))})})},rM=e=>{let{data:t,isSignedIn:i}=e,{registrationSignInLinkBuilder:a,whatToWatchTopPicksLinkBuilder:n}=(0,x.WOb)(),s=(0,m.b)(t?.titleRecommendations?.edges),o=(0,u.N)({id:"nav_userMenu_link_signIn",defaultMessage:"Sign in"}),l=(0,u.N)({id:"top_picks",defaultMessage:"Top picks"}),d=(0,u.N)({id:"top_picks_description",defaultMessage:"TV shows and movies just for you"}),c=(0,ey.JY)({id:"top-picks",height:"title-cards",title:l,description:d,link:n({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>s.length>5},e);return(0,r.jsxs)(ey.GN,{...c,children:[!i&&(0,r.jsx)(rk,{href:a({refSuffix:b.Cd.SIGN_IN}),text:o,className:"top-picks-sign-in-link"}),(0,r.jsx)(rN,{items:s,className:"latest-picks"})]})},rk=(0,s.ZP)(o.TextLink).withConfig({componentId:"sc-3828dac7-0"})(["margin-left:",";margin-bottom:",";margin-top:0;font-size:",";display:block;"],(0,c.setPropertyToSpacingVar)("margin","ipt-pageMargin"),c.spacing.m,(0,c.setTypographyType)("bodySmall"));var rR=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_PICKS,children:(0,r.jsx)(rM,{...e})});let rO=C()`
    query TopPicksHomepage(
        $topPicksFirst: Int!
        $topPicksAfter: String
        $placement: String!
    ) {
        titleRecommendations(
            first: $topPicksFirst
            after: $topPicksAfter
            placementContext: { pageType: $placement }
        ) {
            edges {
                node {
                    refTag
                    title {
                        ...BaseTitleCard
                        ...TitleCardTrailer
                        ...TitleWatchOption
                    }
                    explanations {
                        title {
                            id
                            titleText {
                                text
                            }
                            originalTitleText {
                                text
                            }
                        }
                    }
                }
            }
        }
    }
    ${eR.sq}
    ${eR.F4}
    ${e3.sG.titleWatchOption}
`,rA=(0,eD.O)({query:()=>{let{pageType:e}=(0,rE.y)(),[t]=(0,eA.E)({query:rO,variables:{topPicksFirst:30,placement:e},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!0}});return t},component:e=>{let t=(0,iY.n)(),i={...e,isSignedIn:t};return(0,r.jsx)(rR,{...i})}}),rD=e=>{let{data:t,fetching:i}=e,a=(0,m.b)(t?.topMeterTitles?.edges);(0,tt.bd)(a);let n=(0,u.N)({id:"homepage_topTenTitles_title",defaultMessage:"Top 10 on IMDb this week"}),s=(0,ey.JY)({id:"top-ten",height:"title-cards",title:n,shouldRender:()=>o.length>5},e);if(!t?.topMeterTitles&&!i)return null;let o=a.map((e,t)=>({...e,titleText:e.titleText?.text?{text:`${t+1}. ${e.titleText.text}`}:void 0,originalTitleText:e.originalTitleText?.text?{text:`${t+1}. ${e.originalTitleText.text}`}:void 0}));return(0,r.jsx)(ey.GN,{...s,children:(0,r.jsx)(iJ,{classname:"topten-title",items:o})})};var rL=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_TEN_TITLES,children:(0,r.jsx)(rD,{...e})});let r$=C()`
    fragment TopTenTitlesEntry on Title {
        ...BaseTitleCard
        ...TitleCardTrailer
        ...TitleWatchOption
        meterRanking(input: { meterType: TITLE_METER }) {
            currentRank
            rankChange {
                changeDirection
                difference
            }
        }
    }
    ${eR.sq}
    ${eR.F4}
    ${e3.sG.titleWatchOption}
`,rZ=C()`
    query TopMeterTitlesWidget($topTenFirst: Int!) {
        topMeterTitles(
            first: $topTenFirst
            filter: { topMeterTitlesType: ALL }
        ) {
            edges {
                cursor
                node {
                    ...TopTenTitlesEntry
                }
            }
        }
    }
    ${r$}
`;var rB={ReturningToTV:ri,SuggestedFromFavPeople:rI,TopPicks:rA,FromYourWatchlist:i5,TopTenTitles:(0,eD.O)({query:()=>{let[e]=(0,tt.E8)({query:rZ,variables:{topTenFirst:10},context:{personalized:!1,serverSideCacheable:!0,clientSideBatch:!0}});return e},component:e=>(0,r.jsx)(rL,{...e})}),FanFavorites:iH,PopularInterests:re};let rV=(0,s.ZP)(o.CategoryTitle).withConfig({componentId:"sc-14c9c056-0"})(["margin-bottom:0;"]),rF=s.ZP.div.withConfig({componentId:"sc-14c9c056-1"})(["padding-bottom:",";","{display:flex;justify-content:space-between;align-items:flex-end;}"],c.spacing.s,c.mediaQueries.breakpoints.above.l),rW=(0,s.ZP)(o.TextButton).withConfig({componentId:"sc-14c9c056-2"})(["margin-left:calc("," - ",");","{margin-left:calc( "," - "," );}","{margin-left:calc( "," - "," );}"],(0,c.getSpacingVarValue)("ipt-pageMargin"),c.spacing.xs,c.mediaQueries.breakpoints.only.xs,(0,c.getSpacingVarValue)("ipt-pageMargin"),c.spacing.m,c.mediaQueries.breakpoints.only.l,(0,c.getSpacingVarValue)("ipt-pageMargin"),c.spacing.m);var rG=e=>{let{pageQueryData:t}=e,{whatToWatchLinkBuilder:i}=(0,x.WOb)(),n=a.useRef(null),s=(0,eh.T)(n,{root:null,threshold:0}),l=(0,u.N)({id:"homepage_main_category_whatToWatch",defaultMessage:"What to watch"}),d=(0,u.N)({id:"homepage_main_button_browseWhatToWatch",defaultMessage:"Get more recommendations"});return(0,r.jsx)(X.Z,{name:"WhatToWatch",children:(0,r.jsxs)(ea,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(rF,{ref:n,children:(0,r.jsx)(rV,{"data-testid":"whatToWatch_title",actions:(0,r.jsx)(rW,{"data-testid":"wtw-button",href:i({refSuffix:[b.Cd.WHAT_TO_WATCH,b.Cd.BUTTON]}),postIcon:"chevron-right",children:d}),children:l})})}),(0,r.jsx)(er.Z,{groupConfig:rB,pageQueryData:t,hideErrors:!1,hasIntersected:s})]})})};let rz=e=>!!(0,ec.S)()[e],rU=e=>{let{slotName:t,logComponentName:i}=e,a=rz(t);return(0,r.jsx)(X.Z,{name:i,children:a&&(0,r.jsx)(ea,{className:"page-grid",gutterBias:"center",children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.PageSection,{children:(0,r.jsx)(el.Z,{slotName:t})})})})})},rq=e=>{(0,K.P)(J.lh.IMDB_SIX_DEGREES_HOME_SNACK_648093);let t=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_HOME_STREAMING_WIDGET_958820,treatments:{T1:!0,T2:!0}});return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)(Q.ZP,{children:[(0,r.jsx)(et.Z,{}),(0,r.jsx)(z.Z,{}),(0,r.jsx)(q.Z,{}),(0,r.jsxs)(X.Z,{name:"TopAd",children:[(0,r.jsx)(G.z,{}),(0,r.jsx)(o.PageBackground,{baseColor:"baseAlt",className:Y.R,children:(0,r.jsx)(o.PageContentContainer,{children:(0,r.jsx)(U.ZP,{name:H.A.INLINE20})})})]}),(0,r.jsxs)(rH,{children:[(0,r.jsx)(iI,{}),(0,r.jsx)(tO,{...e}),(0,r.jsx)(W.S,{}),(0,r.jsx)(rU,{slotName:"center-1",logComponentName:"BestOf"}),(0,r.jsx)(B,{delayOnIntersection:!0}),(0,r.jsx)(rG,{...e}),(0,r.jsx)(eg,{...e}),t?(0,r.jsx)(iW,{...e}):(0,r.jsx)(tE,{...e}),(0,r.jsx)(te,{...e}),(0,r.jsx)(iB,{...e})]})]})})},rH=(0,s.ZP)(o.PageContentContainer).withConfig({componentId:"sc-6c67ef41-0"})(["position:relative;"]);var rQ=i(50967),rY=!0,rX=e=>(0,r.jsx)(rQ.Z,{baseColor:"baseAlt",orientContent:"full",hideAdWrap:!0,cti:n.CTIS.HOME_CTI,children:(0,r.jsx)(rq,{...e})})}},function(e){e.O(0,[7406,5601,3078,2161,5163,2727,4272,3036,5058,5522,967,634,5079,4538,9096,9380,3842,2550,3855,3329,9031,4829,9307,4658,2888,9774,179],function(){return e(e.s=87314)}),_N_E=e.O()}]);