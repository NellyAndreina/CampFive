(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[5405],{87314:function(e,t,i){(window.__NEXT_P=window.__NEXT_P||[]).push(["/",function(){return i(15702)}])},77845:function(e,t,i){"use strict";i.d(t,{x:function(){return E}});var r=i(52322),n=i(2784),a=i(14973),s=i(30382),o=i.n(s),l=i(19596),d=i(88169),c=i(86704),p=i(75824),m=i(86958),g=i(66724),u=i(11438),h=i(63370),f=i(19031);let x=e=>{let{isOpen:t,isNotInterested:i,interestStateOnClick:n,recommendation:a,onClose:s}=e,o=(0,p.N)({id:"common_listItem_notInterested",defaultMessage:"Not interested"});return(0,r.jsx)(f.Pz,{isOpen:t,onClose:s,title:a.title,contentOverride:()=>(0,r.jsx)(r.Fragment,{children:!!a&&(0,r.jsx)(b,{recommendation:a})}),actionOverride:()=>(0,r.jsx)(v,{ariaLabel:o,preIcon:i?"thumb-down-filled":"thumb-down",onClick:n})})},b=e=>{let t=(0,m.B)().context,{titleMainLinkBuilder:i}=(0,g.WOb)(),{recommendation:n,className:a}=e,s=(0,p.N)({id:"titleRecommendationPrompt_attributionHeading",defaultMessage:"Because of your interest in"});return(0,r.jsxs)(y,{className:a,children:[(0,r.jsx)("div",{className:"heading",children:s}),(0,r.jsx)("div",{className:"content",children:n.explanations.slice(0,2).map((e,n)=>{let{title:a}=e,s=(0,h.L)(t,a.originalTitleText,a.titleText);return(0,r.jsx)(r.Fragment,{children:!!s&&(0,r.jsx)(d.TextLink,{className:"link",href:i({tconst:a.id,refSuffix:u.Cd.EMPTY}),text:s,inheritColor:!0},n)})})})]})};var T=e=>{let{recommendation:{refTag:t}}=e;return(0,r.jsx)(u.xm,{value:[u.Cd.TITLE_RECOMMENDATION_PROMPT,(0,u.Qk)({refStr:t,explanation:"reftag is dynamic and passed down from graph"})],children:(0,r.jsx)(x,{...e})})};let v=(0,l.ZP)(d.SecondaryButton).withConfig({componentId:"sc-646c92ea-0"})(["width:30%;padding-left:",";"],c.spacing.l),y=l.ZP.div.withConfig({componentId:"sc-646c92ea-1"})(["margin:0;padding:"," "," "," ",";","{padding:"," 0 "," 0;}.content{"," ","}.heading{padding-bottom:",";",";","}.link{text-decoration:none;display:flex;flex-direction:column;","}"],c.spacing.xs,c.spacing.s,c.spacing.s,c.spacing.s,c.mediaQueries.breakpoints.above.m,c.spacing.xs,c.spacing.s,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"),(0,c.setTypographyType)("bodySmall"),c.spacing.xxs,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color"),(0,c.setTypographyType)("bodySmall"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"));var w=i(31885),_=i(17503),C=i(14438);let j={id:"common_featureHeader_link_info",defaultMessage:"More information"},S=o()`
    mutation UpdateTitleInterest(
        $titleId: ID!
        $interestLevel: InterestLevel!
    ) {
        updateTitleInterest(
            input: { titleId: $titleId, interestLevel: $interestLevel }
        ) {
            success
        }
    }
`,P=(e,t)=>{let[i,s]=(0,n.useState)(!1),[o,l]=(0,n.useState)(!1),[,d]=(0,_.Z)(S),{makeRefMarker:c}=(0,u.Lz)(),m=(0,C.EO)(),g=e.title.id,h=c([{t:u.Cd.TITLE,n:t+1},(0,u.Qk)({refStr:e.refTag,explanation:"This refmarker is vended dynamically from the graph"})]);return{iconButtonProps:{name:"info",label:(0,p.N)(j),onClick:()=>{s(!0),m({refMarkerString:h,pageAction:"overflow-expand",hitType:a.HitType.POP_UP,customPageMetadata:{id:g}})}},prompt:(0,r.jsx)(T,{isNotInterested:o,interestStateOnClick:()=>{let e=o?w.FhM.Ambivalent:w.FhM.NotInterested;m({refMarkerString:h,pageAction:o?"reverse-not-interested":"not-interested",customPageMetadata:{id:g}}),d({titleId:g,interestLevel:e}),l(!o)},isOpen:i,onClose:()=>s(!1),recommendation:e})}};var I=i(49175),N=i(23842);let E=e=>{let{recommendation:t,index:i}=e,{createButton:n,createPrompt:a}=(0,I.V1)(),{iconButtonProps:s,prompt:o}=P(t,i);return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(N.c,{className:"top-picks-title",data:t.title,refTagFromGraph:t.refTag,index:i+1,alternateButton:n(t.title,i),iconButtons:[s]},t.title.id),a(),o]})}},43421:function(e,t,i){"use strict";i.d(t,{OW:function(){return b}});var r=i(52322);i(2784);var n=i(53665),a=i(19596),s=i(88169),o=i(86704),l=i(66724),d=i(11438);let c={id:"from_your_watchlist_empty_title",defaultMessage:"Your watchlist is empty"},p={id:"from_your_watchlist_empty_content",defaultMessage:"Save shows and movies to keep track of what you want to watch."},m={id:"from_your_watchlist_all_rated_title",defaultMessage:"No available releases"},g={id:"from_your_watchlist_all_rated_content",defaultMessage:"Add more shows and movies to keep track of what you want to watch."},u={id:"from_your_watchlist_logged_out",defaultMessage:"Sign in to access your Watchlist"},h={id:"from_your_watchlist_logged_out_content",defaultMessage:"Save shows and movies to keep track of what you want to watch."},f={id:"from_your_watchlist_empty_button",defaultMessage:"Browse popular movies"},x={id:"from_your_watchlist_logged_out_button",defaultMessage:"Sign in to IMDb"},b=e=>{let{isLoggedIn:t,hasRatedTitles:i,hasUnreleasedTitlesInWatchlist:a}=e,s=(0,n.Z)(),{chartMovieMeterLinkBuilder:o,registrationSignInLinkBuilder:b}=(0,l.WOb)(),C=i||a,j=t?C?m:c:u,S=t?o({refSuffix:d.Cd.EMPTY_MESSAGE}):b({refSuffix:d.Cd.SIGN_IN});return(0,r.jsxs)(T,{className:"from-your-watchlist__state__container",children:[(0,r.jsx)(v,{className:"from-your-watchlist__ribbon",inWatchlist:!1,ariaLabel:s.formatMessage(j)}),(0,r.jsxs)(y,{className:"from-your-watchlist__status-prompt__container",children:[(0,r.jsx)(w,{className:"from-your-watchlist__status-prompt__title",children:s.formatMessage(j)}),(0,r.jsx)("div",{"data-testid":"empty-state-content",className:"from-your-watchlist_status-prompt_content",children:s.formatMessage(t?C?g:p:h)})]}),(0,r.jsx)(_,{className:"from-your-watchlist__state__button",width:"double-padding",href:S,children:s.formatMessage(t?f:x)})]})},T=(0,a.ZP)(s.PageSection).withConfig({componentId:"sc-5b81157c-0"})([""," text-align:center;padding:",";"],(0,o.setPropertyToSpacingVar)("margin","ipt-pageMargin"),o.spacing.l),v=(0,a.ZP)(s.WatchlistRibbon).withConfig({componentId:"sc-5b81157c-1"})(["pointer-events:none;"]),y=a.ZP.div.withConfig({componentId:"sc-5b81157c-2"})(["margin-top:",";"],o.spacing.xs),w=a.ZP.div.withConfig({componentId:"sc-5b81157c-3"})(["font-weight:bold;"]),_=(0,a.ZP)(s.SecondaryButton).withConfig({componentId:"sc-5b81157c-4"})(["margin-top:",";"],o.spacing.xl)},51415:function(e,t,i){"use strict";i.d(t,{n:function(){return g},s:function(){return u}});var r=i(52322),n=i(88169),a=i(86704),s=i(72779),o=i.n(s),l=i(30382),d=i.n(l);i(2784);var c=i(53665),p=i(19596),m=i(72113);let g=e=>{let t=(0,c.Z)(),{headline:i,link:a,publicationDate:s,source:l,image:d,className:p,newsText:g,imageSize:u}=e,f=t.formatDate(new Date(s),{day:"numeric",month:"short"}),x=d?.maxHeight&&d?.maxHeight>100||d?.maxWidth&&d?.maxWidth>100?d:void 0,b=o()("news-item",p),{color:T,type:v}=(0,m.G)(),y=o()(T("textPrimary"),v("subtitle"),"line-clamp-2"),w=o()(v("subtitle2"),"line-clamp-3"),_=(0,r.jsxs)(h,{className:b,href:a,"aria-label":i,"data-testid":"news-item",children:[(0,r.jsx)(n.PosterImage,{imageModel:x,size:u||"60",imageType:"none",className:"poster"}),(0,r.jsxs)("div",{className:"content",children:[(0,r.jsx)("div",{"data-testid":"headline",className:o()({[y]:g},{[w]:!g}),children:i}),!!g&&(0,r.jsx)("div",{"data-testid":"news-text",className:o()("line-clamp-3",v("bodySmall")),children:g}),(0,r.jsxs)("div",{className:o()("metadata flex flex-wrap gap-x-s",T("textSecondary")),children:[(0,r.jsx)("div",{className:"publicationDate",children:f}),(0,r.jsx)("div",{children:l})]})]})]});return(0,r.jsx)(n.ShovelerItem,{span:4,children:_})},u=d()`
    fragment NewsItem on NewsEdge {
        node {
            id
            articleTitle {
                plainText
            }
            date
            image {
                caption {
                    plainText
                }
                url
                height
                width
            }
            source {
                homepage {
                    label
                }
                trustedSource
            }
            text {
                plainText
            }
        }
    }
`,h=p.ZP.a.withConfig({componentId:"sc-e01589e7-0"})(["align-items:flex-start;color:inherit;display:flex;text-decoration-style:none;text-decoration:none;&:hover{opacity:0.8;}.poster{flex-shrink:0;}.content{flex-grow:1;padding-left:",";}.metadata{",";margin-top:",";}"],a.spacing.m,(0,a.setTypographyType)("copyright"),a.spacing.xxs)},76018:function(e,t,i){"use strict";i.d(t,{X:function(){return d}});var r=i(52322),n=i(27722);i(2784);var a=i(66724),s=i(11438),o=i(6935),l=i(51415);let d=e=>{let{newsSingleLinkBuilder:t}=(0,a.WOb)(),{topNewsItems:i}=e,d=i?.filter(e=>!!e.node.text.plainText);if(!d||d.length<1)return null;let c=d[0],p=t({niconst:c.node.id,refSuffix:{t:s.Cd.TOP,n:1}}),m=(0,o.K0)(c.node.image,c.node.articleTitle.plainText||""),g=d.slice(1,5).map((e,i)=>{let{node:n}=e,a=n.articleTitle.plainText,d=t({niconst:n.id,refSuffix:{t:s.Cd.TOP,n:i+2}}),c=(0,o.K0)(n.image,a);return(0,r.jsx)("div",{"data-testid":n.id,children:(0,r.jsx)(l.n,{newsId:n.id,headline:a,link:d,image:c,source:n.source.homepage?.label||"",publicationDate:n.date})},n.id)});return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("div",{className:"px-pageMargin",children:[(0,r.jsx)(l.n,{newsId:c.node.id,newsText:c.node.text.plainText,imageSize:"s",headline:c.node.articleTitle.plainText||"",link:p,image:m,source:c.node.source.homepage?.label||"",publicationDate:c.node.date}),(0,r.jsx)("div",{className:"grid-cols-2 gap-m pt-m col-span-2 hidden s:grid",children:g})]}),(0,r.jsx)("div",{className:"pt-m s:hidden",children:(0,r.jsx)(n.Shoveler,{children:g.map(e=>(0,r.jsx)(n.ShovelerItem,{span:4,children:e},e.key))})})]})}},96621:function(e,t,i){"use strict";i.d(t,{y:function(){return o}});var r=i(30382),n=i.n(r),a=i(85018),s=i(49175);let o=n()`
    query FromYourWatchlist($first: Int!) {
        predefinedList(classType: WATCH_LIST) {
            items(
                first: $first
                filter: { rated: EXCLUDE, released: INCLUDE }
                sort: { by: POPULARITY, order: ASC }
            ) {
                edges {
                    node {
                        item {
                            ...BaseTitleCard
                            ...TitleCardTrailer
                            ...TitleWatchOption
                        }
                    }
                }
            }
            ratedCount: items(first: 0, filter: { rated: INCLUDE }) {
                total
            }
            unreleasedCount: items(first: 0, filter: { released: EXCLUDE }) {
                total
            }
        }
    }
    ${a.sq}
    ${a.F4}
    ${s.sG.titleWatchOption}
`},72113:function(e,t,i){"use strict";i.d(t,{G:function(){return p}});var r=i(27722),n=i(72779),a=i.n(n),s=i(2784);let o=(e,t,i)=>{let r="default"===t?e:`${e}-${t}`,n=`text-on-${r}`,s="default"===i?e:`${e}-${i}`,o=i?`bg-${s}`:void 0;return a()(n,o)},l=e=>`border-${e}-border`,d=e=>`type-${e}`,c=e=>{let t,i,{type:r,color:n,bg:s,themeName:l}=e;return n&&(t=o(l,n,s)),r&&(i=d(r)),a()(t,i)},p=()=>{let{palette:{name:e}}=(0,s.useContext)(r.Theme);return{type:e=>d(e),color:(t,i)=>o(e,t,i),borderColor:()=>l(e),classes:t=>{let{type:i,color:r,bg:n}=t;return c({type:i,color:r,bg:n,themeName:e})}}}},3072:function(e,t,i){"use strict";i.d(t,{B:function(){return r}});let r=(e,t,i)=>{let r=n(e),a=n(t),s=i.formatDate(r,{day:"numeric",month:"long"}),o=i.formatDate(a,{day:"numeric",month:"long"});return r.getMonth()===a.getMonth()?s+"-"+i.formatDate(a,{day:"numeric"}):s+"-"+o};function n(e){return new Date(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate())}},29363:function(e,t,i){"use strict";i.d(t,{T:function(){return s}});var r=i(2784),n=i(93855),a=i(99546);let s=(e,t)=>{let[i,s]=(0,r.useState)(!1),[o,l]=(0,r.useState)(!1);(0,r.useEffect)(()=>{i&&!o&&l(!0)},[i,o]);let d=(0,n.Jf)(e,o,s);return(0,a.S)(e,d,t),o}},78716:function(e,t,i){"use strict";i.d(t,{p:function(){return d}});var r=i(2784),n=i(93855),a=i(99546),s=i(89105),o=i(4363);let l={fetching:!0,stale:!1},d=e=>{let{queryOptions:t,ref:i,pause:d,options:c,onIntersection:p}=e,m=(0,s.OV)(),g=!c?.disableAds&&m,[u,h]=(0,r.useState)(!1),[f,x]=(0,r.useState)(!1),b=(0,n.Jf)(i,!c?.continueObserving&&f,h);(0,a.S)(i,b,{...c?.intersectionOptions}),(0,r.useEffect)(()=>{u&&p?.()},[u]);let T=!c?.disableIntersection&&!u,[v,y]=(0,o.E)({...t,pause:g||T||d||!1});return((0,r.useEffect)(()=>{v?.data&&x(!0)},[v?.data]),v.data||v.error)?[v,y]:[l,y]}},73013:function(e,t,i){"use strict";i.d(t,{S:function(){return n}});var r=i(86958);let n=()=>r.B()?.context?.sidecar?.placementMap||{}},96115:function(e,t,i){"use strict";i.d(t,{P:function(){return p}});var r=i(88169),n=i(2784),a=i(75824),s=i(66724),o=i(11438),l=i(72416),d=i(48687);let c="sxdshidesnack",p=e=>{let{sixDegreesLinkBuilder:t}=(0,s.WOb)(),i=(0,a.N)({id:"homepage_six_degrees_snack_msg",defaultMessage:"Try IMDb's new daily game Six Degrees."}),p=(0,a.N)({id:"homepage_six_degrees_snack_link",defaultMessage:"Play now"}),m=(0,d.hg)({weblabID:e,treatments:{T1:!0}}),{sendSnack:g}=(0,r.useSnackbar)(),u=(0,l.ID)(c);(0,n.useEffect)(()=>{m&&!u&&g({type:"manual",primaryText:i,textLinks:[{text:p,href:t({refSuffix:[o.Cd.SNACK,o.Cd.GAMES,o.Cd.SIX_DEGREES]}),onClick:()=>(0,l._2)(c,!0)}],closeLabel:"Close",onClose:()=>(0,l._2)(c,!0)})},[])}},68139:function(e,t,i){"use strict";i.d(t,{X:function(){return n},k:function(){return a}});var r=i(63370);let n=e=>{let t=e?.series?.originalTitleText?.text,i=e?.series?.titleText?.text;return(0,r.K)({titleText:i,originalTitleText:t})},a=(e,t)=>{let i=t?.series.originalTitleText?.text,n=t?.series.titleText?.text;return(0,r.L)(e,i,n)}},30124:function(e,t,i){"use strict";var r=i(52322);i(2784);var n=i(10105),a=i(54588),s=i(14149);t.Z=function(e){let{groupConfig:t,pageQueryData:i,hideErrors:o,hasIntersected:l=!0}=e,{data:d,config:c,error:p,fetching:m=!1,retry:g,shouldRenderError:u=!1,allErrorsRetryable:h=!0}=i,f=!!(g&&h);return m||!l?(0,r.jsx)(n.ZP,{"data-testid":"entity-group-loader",height:"feature"}):o&&u?null:(0,r.jsxs)(r.Fragment,{children:[!!u&&(0,r.jsx)(s.ZP,{error:p,name:c?.queryName,canRetry:f,onClickRetry:()=>f&&g()}),!u&&Object.entries(t).map(e=>{let[t,i]=e;if(i.shouldRender&&d&&!1===i.shouldRender(d))return null;let n=i.component;return(0,r.jsx)(a.Z,{name:t,parent:"PageQueryEntity",children:(0,r.jsx)(n,{data:d,fetching:m,error:p})},t)})]})}},60635:function(e,t,i){"use strict";function r(e){(e||[]).forEach(e=>{let t=e.id,i=e?.userRating?.value;i&&window.imdb?.ratings?.addRating(t,i)})}i.d(t,{Q:function(){return r}})},15702:function(e,t,i){"use strict";i.r(t),i.d(t,{__N_SSP:function(){return r4},default:function(){return r3}});var r=i(52322),n=i(2784),a=i(25436),s=i(19596),o=i(88169),l=i(14865),d=i(4337),c=i(86704),p=i(10965),m=i(75824),g=i(16214),u=i(78716),h=i(55634),f=i(59002),x=i(66724),b=i(11438),T=i(14438),v=i(72779),y=i.n(v),w=i(30382),_=i.n(w),C=i(82925),j=i(15030),S=i(6935);let P=_()`
    fragment PopularCelebrity on Name {
        id
        nameText {
            text
        }
        primaryImage {
            caption {
                plainText
            }
            url
            height
            width
        }
        meterRanking {
            currentRank
            rankChange {
                changeDirection
                difference
            }
        }
    }
`,I={CARD:"popular-celebrity-card",CURRENT_RANK:"popular-celebrity-current-rank",NAME_TEXT:"popular-celebrity-name-text",RANK:"popular-celebrity-rank",RANK_CHANGE:"popular-celebrity-rank-change"},N=e=>{let{className:t,refMarkerSuffix:i,popularCelebrityData:a}=e,{nameMainLinkBuilder:s}=(0,x.WOb)(),l=(0,n.useContext)(C.Theme),d=y()(t,I.CARD),{id:c,primaryImage:p,meterRanking:m}=a,g=a.nameText?.text??"",u=(0,S.K0)(p,g);return(0,r.jsxs)(E,{className:d,href:s({nconst:c,refSuffix:i}),"data-testid":I.CARD,children:[(0,r.jsxs)(o.Avatar,{dynamicWidth:!0,children:[(0,r.jsx)(o.Avatar.Image,{imageModel:u}),(0,r.jsx)(o.Avatar.Overlay,{className:"overlayClasses"})]}),(0,r.jsxs)(k,{className:I.RANK,"data-testid":I.RANK,children:[(0,r.jsx)("div",{className:y()(I.CURRENT_RANK,`${I.CURRENT_RANK}--${l.palette.name}`),children:m?.currentRank}),m?.rankChange&&(0,r.jsxs)(M,{className:y()(I.RANK_CHANGE,`${I.RANK_CHANGE}--${l.palette.name}`),children:[" (",(0,r.jsx)(j.x,{difference:m?.rankChange.changeDirection==="FLAT"?void 0:m?.rankChange.difference,direction:m?.rankChange.changeDirection}),")"]})]}),(0,r.jsx)(O,{className:y()(I.NAME_TEXT,`${I.NAME_TEXT}--${l.palette.name}`),"data-testid":I.NAME_TEXT,children:g})]})},E=s.ZP.a.withConfig({componentId:"sc-5a012df2-0"})(["",";width:100%;text-align:center;overflow:hidden;display:flex;flex-direction:column;&:hover{opacity:0.7;}"],(0,c.setTypographyType)("body")),k=s.ZP.div.withConfig({componentId:"sc-5a012df2-1"})(["display:inline-flex;justify-content:center;width:100%;margin-top:",";line-height:1em;.","--light{",";padding-right:",";}.","--dark{",";padding-right:",";}.","--light{",";}.","--dark{",";}"],c.spacing.s,I.CURRENT_RANK,(0,c.setPropertyToColorVar)("color","ipt-on-base-textPrimary-color"),c.spacing.xxs,I.CURRENT_RANK,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"),c.spacing.xxs,I.RANK_CHANGE,(0,c.setPropertyToColorVar)("color","ipt-on-base-textSecondary-color"),I.RANK_CHANGE,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),M=s.ZP.div.withConfig({componentId:"sc-5a012df2-2"})(["display:flex;align-items:center;"]),O=s.ZP.div.withConfig({componentId:"sc-5a012df2-3"})(["white-space:nowrap;overflow:hidden;text-overflow:ellipsis;&.","--light{",";}&.","--dark{",";}"],I.NAME_TEXT,(0,c.setPropertyToColorVar)("color","ipt-on-base-textPrimary-color"),I.NAME_TEXT,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"));N.fragments={popularCelebrity:P};let R=_()`
    query PopularCelebrities {
        topMeterNames(first: 50) {
            edges {
                node {
                    ...PopularCelebrity
                }
            }
        }
    }

    ${N.fragments.popularCelebrity}
`;var A=i(31885);let D=(e,t)=>e.filter(e=>e?.nameText&&e?.meterRanking?.rankChange?.changeDirection===A.UQd.Up).sort((e,t)=>(t.meterRanking?.rankChange?.difference||0)-(e.meterRanking?.rankChange?.difference||0)).slice(0,t),Z={TITLE:"popular-celebrities-title",SHOVELER:"popular-celebrities-shoveler",ITEM_CARD:"popular-celebrities-item-card"},$=e=>{let{delayOnIntersection:t,csmOnLoadHandler:i,csaOnLoadHandler:a,cel_widget_id:s,className:d}=e,c=(0,n.useRef)(null),v=(0,T.EJ)(),{chartStarMeterLinkBuilder:y}=(0,x.WOb)(),w=(0,m.N)({id:"popularCelebrities_title",defaultMessage:"Most popular celebrities"}),_=(0,m.N)({id:"popularCelebrities_topRising_subHeader",defaultMessage:"Top rising"}),C=(0,m.N)({id:"popularCelebrities_topMeter_subHeader",defaultMessage:"By ranking"}),[j]=(0,u.p)({queryOptions:{query:R,context:{personalized:!1,serverSideCacheable:!0}},ref:c,pause:l.isNode,options:{disableIntersection:!t,disableAds:!0}});(0,f.LQ)(j,i,a);let{fetching:S,data:P,error:I}=j;if(I)return null;let N=(0,g.b)(P?.topMeterNames?.edges);if(!S&&(!N||0===N.length))return null;let E=D(N,2);return(0,r.jsx)(f.Lz,{componentId:h.NG.PopularCelebrities,children:(0,r.jsx)(o.PageSection,{"data-testid":s,className:d,children:(0,r.jsxs)("div",{ref:c,children:[(0,r.jsx)(o.SubSectionTitle,{href:y({refSuffix:b.Cd.SEE_MORE}),className:Z.TITLE,children:w}),(0,r.jsx)(p.Z,{loading:S,height:230,children:(0,r.jsx)(F,{className:Z.SHOVELER,onPageChange:v,children:[...L(E,b.Cd.TOP,_),...L(N,b.Cd.RANK,C,E.filter(e=>e.meterRanking?.currentRank&&e.meterRanking?.currentRank<=4))]})})]})})})},L=(e,t,i,n)=>{let a=1,s=n?.map(e=>e.id)??[],o=[];for(let n=0;n<e.length;n++){let l=e[n];if(!l.nameText||!l.meterRanking||s.includes(l.id))continue;let c=1===a?i:null,p=(0,r.jsx)(d.SubGridItem,{span:2,className:Z.ITEM_CARD,children:(0,r.jsxs)("div",{children:[!!c&&(0,r.jsx)(B,{children:c}),(0,r.jsx)(N,{refMarkerSuffix:{t:t,n:a},popularCelebrityData:l,className:`${Z.ITEM_CARD}-${t}-${a}`})]})},`${t}_${a}`);o.push(p),a++}return o};var V=e=>(0,r.jsx)(b.xm,{value:b.Cd.POPULAR_CELEBRITIES,children:(0,r.jsx)($,{...e})});let B=s.ZP.div.withConfig({componentId:"sc-790c21c3-0"})(["",";",";padding-bottom:",";white-space:nowrap;overflow:visible;"],(0,c.setPropertyToColorVar)("color","ipt-accent1-color"),(0,c.setTypographyType)("overline"),c.spacing.s),F=(0,s.ZP)(o.Shoveler).withConfig({componentId:"sc-790c21c3-1"})([".","{align-self:end;}"],Z.ITEM_CARD);var W=i(21915),G=i(86857),q=i(80380),z=i(55129),U=i(29914),H=i(22431),Q=i(82453),Y=i(21768),X=i(54588),K=i(96115),J=i(83163),ee=i(48687),et=i(82008),ei=i(20608),er=i(30124);let en=(0,s.ZP)(o.PageGrid).withConfig({componentId:"sc-42bf884a-0"})(["",""],(0,c.setPropertyToColorVar)("background","ipt-baseAlt-bg"));var ea=i(64934);let es=e=>{let t=[],i=1,r=1;for(let n=0;n<30;n+=1)eo(n)?(t.push({name:`geo-${e}-${i}`,isGeo:!0,slotNumber:i}),i++):(t.push({name:`${e}-${r}`,isGeo:!1,slotNumber:r}),r++);return t},eo=e=>e<=3||(!(e>24)||!(e<29))&&e%2==1;var el=i(92550),ed=e=>{let t=e.carouselTitle,i=e.carouselDescription,n=e.slotNamePrefix,a=e.refMarkerPrefix,s=(0,T.EJ)(a),l=es(n).map(e=>(0,r.jsx)(el.Z,{slotName:e.name,className:"editorial-item",refMarker:{prefix:a,suffix:`${e.isGeo?"geo_":""}${e.slotNumber}`}},n+"-editorial-item-"+e.slotNumber));return(0,r.jsxs)(r.Fragment,{children:[!!t&&(0,r.jsx)(o.SubSectionTitle,{description:i,children:t}),(0,r.jsx)(o.Shoveler,{className:"editorial-carousel",onPageChange:s,children:l})]})},ec=i(73013);let ep=e=>{let t=e+"-mso";return!(0>Object.values((0,ec.S)()).findIndex(e=>t===e.symphonyMetadata?.msoGroupName))},em=e=>{let{slotNamePrefix:t,title:i,description:n}=e,a=(0,b.Lz)().value,s=ep(t),l=ep(`geo-${t}`);if(!s&&!l)return null;let d=i?void 0:"none";return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(ea.P,{id:t}),(0,r.jsx)(o.PageSection,{topPadding:d,bottomPadding:d,children:(0,r.jsx)(ed,{carouselTitle:i,carouselDescription:n,slotNamePrefix:t,refMarkerPrefix:a})})]})};var eg={imdbOriginals:{component:()=>{let e=(0,m.N)({id:"editorialCarousel_imdb_originals",defaultMessage:"IMDb Originals"}),t=(0,m.N)({id:"editorialCarousel_imdb_originals_description",defaultMessage:"Celebrity interviews, trending entertainment stories, and expert analysis"});return(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_IMDB_ORIG,children:(0,r.jsx)(em,{slotNamePrefix:"imdb-originals",title:e,description:t})})}}},eu=e=>{let{pageQueryData:t}=e;return(0,r.jsx)(X.Z,{name:"ExclusiveVideos",children:(0,r.jsx)(en,{className:"page-grid",children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsxs)("div",{children:[(0,r.jsx)(o.CategoryTitle,{children:(0,r.jsx)(ei.q,{id:"homepage_main_category_exclusiveVideos",defaultMessage:"Exclusive videos"})}),(0,r.jsx)(er.Z,{groupConfig:eg,pageQueryData:t,hideErrors:!1})]})})})})},eh=i(29363),ef=i(85846),ex=i(53665),eb=i(86958),eT=i(3072),ev=i(84220),ey=i(12563);let ew=s.ZP.a.withConfig({componentId:"sc-cd926779-0"})(["text-decoration:none;display:block;width:80%;",";",";white-space:nowrap;overflow:hidden;padding-left:",";"],(0,c.setTypographyType)("body"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-color"),c.spacing.s),e_=s.ZP.div.withConfig({componentId:"sc-cd926779-1"})(["overflow:hidden;text-overflow:ellipsis;"]),eC=(0,s.ZP)(o.WatchlistRibbon).withConfig({componentId:"sc-cd926779-2"})(["flex-shrink:0;"]),ej=s.ZP.div.withConfig({componentId:"sc-cd926779-3"})(["display:flex;padding:"," ",";&:hover{opacity:0.8;}","{width:50%;}&.boxOfficeTitle:nth-of-type(even){background:linear-gradient( to right,rgb('ipt-on-baseAlt-color' 0),rgb('ipt-on-baseAlt-color' 0.06) );background:linear-gradient( to right,rgb(var(--ipt-on-baseAlt-rgb) 0),rgb(var(--ipt-on-baseAlt-rgb) 0.06) );}"],c.spacing.s,c.spacing.m,c.mediaQueries.breakpoints.above.s),eS=s.ZP.div.withConfig({componentId:"sc-cd926779-4"})(["margin-top:auto;margin-bottom:auto;"]),eP=s.ZP.div.withConfig({componentId:"sc-cd926779-5"})(["",";",";line-height:1.5em;"],(0,c.setTypographyType)("overline"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),eI=s.ZP.div.withConfig({componentId:"sc-cd926779-6"})(["border-right:1px solid;",";height:18px;margin:auto "," auto ",";display:inline-block;"],(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-accent1-color"),c.spacing.s,c.spacing.xs);var eN=e=>{let{makeRefMarker:t}=(0,b.Lz)(),{rankNumber:i,title:n,titleId:a,titlePageLink:s,weekendGrossAmount:l,showtimesLink:d}=e,{onClick:c,ariaLabel:p,isInWatchlist:m,isPending:g}=(0,ey.X)(a,t({t:b.Cd.WATCHLIST_RIBBON,n:i}));return(0,r.jsxs)(ej,{className:"boxOfficeTitle",children:[(0,r.jsx)(eS,{children:i}),(0,r.jsx)(eI,{}),(0,r.jsx)(eC,{size:"m",onClick:c,ariaLabel:p,isLoading:g,inWatchlist:m}),(0,r.jsxs)(ew,{href:s,className:"boxOfficeTitleLink",children:[(0,r.jsx)(e_,{children:n}),(0,r.jsx)(eP,{children:l})]}),!!d&&(0,r.jsx)(o.IconButton,{className:"boxOffice-showtimes-link",name:"ticket",href:d,label:n+"showtimes link",onColor:"accent2"})]})},eE=i(68139),ek=i(63370);let eM=(e,t,i)=>i.formatNumber(e,{style:"currency",currency:t,notation:"compact",compactDisplay:"short",currencyDisplay:"symbol"}),eO=(e,t,i,r,n)=>{if(!e||!e.title||!e.weekendGross)return;let{title:a,weekendGross:s}=e,o=(0,ek.L)(n,a.originalTitleText,a.titleText),l=(0,eE.k)(n,a.series),d=l?`${l}: ${o}`:`${o}`,c=a.id,p=eM(s.total.amount,s.total.currency,r),m=i.titleMainLinkBuilder({tconst:c,refSuffix:{t:b.Cd.EMPTY,n:t}}),g=a.cinemas?.total?i.showtimesTitleLinkBuilder({tconst:c,refSuffix:{t:b.Cd.EMPTY,n:t}}):void 0;return{rankNumber:t,titleName:d,titleId:c,titlePageLink:m,weekendGrossAmount:p,showtimesLink:g}},eR=e=>{let t=(0,ex.Z)(),i=(0,x.WOb)(),r=(0,eb.B)().context;return e?(e?.boxOfficeWeekendChart?.entries??[]).map((e,n)=>eO(e,n+1,i,t,r)).filter(e=>void 0!==e).map(e=>e):[]},eA=(e,t)=>{let{data:i}=e;if(i?.boxOfficeWeekendChart?.weekendStartDate&&i?.boxOfficeWeekendChart?.weekendEndDate)return(0,eT.B)(new Date(i.boxOfficeWeekendChart.weekendStartDate),new Date(i.boxOfficeWeekendChart.weekendEndDate),t)},eD=e=>{let{data:t}=e,i=(0,ex.Z)(),{chartBoxOfficeLinkBuilder:n}=(0,x.WOb)(),a=eR(t),s=eA({data:t},i),o=(0,m.N)({id:"topBoxOffice_header_top_us",defaultMessage:"Top box office (US)"}),l=s?i.formatMessage({id:"topBoxOffice_header_description_date",defaultMessage:"Weekend of {dateRange}"},{dateRange:s}):"",d=(0,ev.JY)({id:"top-box-office",height:"other",title:o,description:l,link:n({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>a.length>4},e),c=a.map((e,t)=>(0,r.jsx)(eN,{rankNumber:e.rankNumber,title:e.titleName,titleId:e.titleId,titlePageLink:e.titlePageLink,weekendGrossAmount:e.weekendGrossAmount,showtimesLink:e.showtimesLink},t));return(0,r.jsx)(ev.GN,{...d,children:(0,r.jsx)(e$,{"data-testid":"boxOfficeList",children:(0,r.jsx)(eZ,{children:c})})})},eZ=s.ZP.div.withConfig({componentId:"sc-b5b47714-0"})(["list-style:none;display:flex;flex-direction:column;","{display:flex;flex-wrap:wrap;max-height:14rem;width:100%;}"],c.mediaQueries.breakpoints.above.s),e$=s.ZP.div.withConfig({componentId:"sc-b5b47714-1"})(["","{display:flex;}"],c.mediaQueries.breakpoints.above.s);var eL=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_BOX_OFFICE,children:(0,r.jsx)(eD,{...e})});let eV={component:e=>(0,r.jsx)(eL,{...e}),shouldRender:e=>!0,fragment:{name:"TopBoxOffice",variables:e=>{let{requestContext:t}=e;return{location:{value:(0,ef.QJ)(t),type:"ShowtimesLocation!"}}},gql:_()`
            fragment TopBoxOffice on Query {
                boxOfficeWeekendChart(limit: 6) {
                    weekendStartDate
                    weekendEndDate
                    entries {
                        title {
                            id
                            titleText {
                                text
                            }
                            originalTitleText {
                                text
                            }
                            series {
                                series {
                                    titleText {
                                        text
                                    }
                                    originalTitleText {
                                        text
                                    }
                                }
                            }
                            cinemas(
                                first: 0
                                request: { location: $location }
                            ) {
                                total
                            }
                        }
                        weekendGross {
                            total {
                                amount
                                currency
                            }
                        }
                    }
                }
            }
        `}};var eB=i(85018);let eF=()=>{let e=new Date;return new Date(e.getUTCFullYear(),e.getUTCMonth(),e.getUTCDate()+1).toISOString().split("T")[0]};var eW=i(4363),eG=i(20937),eq=i(11778),ez=i(31129),eU=i(69380),eH=i(22073);let eQ=(0,s.ZP)(eU.Q).withConfig({componentId:"sc-e7a6d986-0"})(["padding-left:2.75rem;"]),eY=(0,s.ZP)(o.TextLink).withConfig({componentId:"sc-e7a6d986-1"})(["padding-left:0;padding-bottom:0;"]);var eX=e=>{let t=(0,ex.Z)(),{slotNumber:i,model:{titleText:n,titleId:a,releaseDate:s,slate:o,runtimeSeconds:l,videoId:d,hasShowtimes:c}}=e,{makeRefMarker:p}=(0,b.Lz)(),{showtimesTitleLinkBuilder:m,titleMainLinkBuilder:g,videoSingleLinkBuilder:u}=(0,x.WOb)(),{onClick:h,ariaLabel:f,isInWatchlist:T,isPending:v}=(0,ey.X)(a,p({t:b.Cd.WATCHLIST_RIBBON,n:i+1})),y=n+" "+t.formatMessage({id:"comingSoon_trailer_ariaLabel_suffix",defaultMessage:"trailer"}),w=t.formatMessage({id:"comingSoon_get_tickets",defaultMessage:"Get tickets"}),_=u({viconst:d,refSuffix:{t:b.Cd.POSTER,n:i}}),C={title:n,href:g({tconst:a,refSuffix:{t:b.Cd.TEXT,n:i}}),subtitle:t.formatDate(s,{month:"short",day:"numeric"})},j={ariaLabel:y,imageProps:{aspectRatio:"16:9",imageModel:o},overlayProps:{gradientType:"radial",iconName:"play-circle-outline",text:(0,eH.L)(l)},href:_},S={children:c&&(0,r.jsx)(eY,{"data-testid":"coming-soon-ticket-link",text:w,href:m({tconst:a,refSuffix:{t:b.Cd.EMPTY,n:i}}),touchTarget:!0})},P=(0,r.jsx)(eQ,{associatedConstId:d,entityType:"video"});return(0,r.jsx)(ez.SlateCard,{className:"coming-soon-title",watchlistProps:{size:"m",onClick:h,ariaLabel:f,isLoading:v,inWatchlist:T},titleProps:C,slateProps:j,actionProps:S,dynamicWidth:!0,size:"s",children:P})};let eK={id:"comingSoon_trailers_for_upcoming_releases",defaultMessage:"Trailers for upcoming releases"},eJ={id:"comingSoon_coming_soon_to_theaters",defaultMessage:"Coming soon to theaters"},e0={id:"comingSoon_add_to_watchlist_for_notifications",defaultMessage:"Add to Watchlist for notifications"},e1={id:"comingSoon_watch_soon_at_home",defaultMessage:"Watch soon at home"};var e2=e=>{let{fetching:t,titles:i,comingSoonType:n}=e,a=(0,ex.Z)(),{calendarLinkBuilder:s}=(0,x.WOb)(),l=(0,T.EJ)(),d=n===A.M4k.Movie,c=i.map((e,t)=>(0,r.jsx)(eX,{slotNumber:t+1,model:e},e.titleId)),{link:p,description:m,title:g}=d?{description:a.formatMessage(eK),title:a.formatMessage(eJ),link:s({refSuffix:b.Cd.SEE_MORE})}:{description:a.formatMessage(e0),title:a.formatMessage(e1),link:void 0},u=("coming-soon-"+n).toLowerCase(),h=(0,ev.JY)({id:u,height:"video-slates",title:g,description:m,link:p,shouldRender:()=>(0,eq.isDevStage)()?i.length>0:i.length>5},{fetching:t});return(0,r.jsx)(ev.GN,{...h,children:(0,r.jsx)(o.Shoveler,{className:"coming-soon-titles",onPageChange:l,children:c})})};let e4=(e,t)=>{if(!e)return[];switch(t){case A.M4k.Tv:return e.comingSoonTV?.edges;case A.M4k.Movie:default:return e.comingSoonMovie?.edges}},e3=e=>{let{fetching:t,data:i,type:n}=e,a=e4(i,n),s=(0,g.b)(a).reduce((e,t)=>{let{titleText:i,latestTrailer:r,releaseDate:n}=t;if(!i||!r||!n)return e;let{month:a,day:s,year:o}=n;if(!a||!s||!o)return e;let{runtime:l,thumbnail:d,name:{value:c}}=r;if(!l)return e;let p=new Date(o,a-1,s,0,0,0,0),m=t.meterRanking?.currentRank;return e.push({titleId:t.id,titleText:i.text,videoId:r.id,releaseDate:p,runtimeSeconds:l.value,slate:{caption:c,maxHeight:d.height,maxWidth:d.width,url:d.url},currentRank:m,hasShowtimes:(t.cinemas?.total??0)>0}),e},[]);return(0,r.jsx)(e2,{fetching:!!t,comingSoonType:n,titles:s})};var e8=e=>(0,r.jsx)(b.xm,{value:e.type===A.M4k.Movie?b.Cd.COMING_SOON:b.Cd.COMING_SOON_TV,children:(0,r.jsx)(e3,{...e})});let e7=_()`
    query comingSoonMovieQuery(
        $movieReleasingOnOrAfter: Date!
        $movieViewerLocation: ShowtimesLocation!
        $regionOverride: String!
    ) {
        comingSoonMovie: comingSoon(
            first: 50
            comingSoonType: MOVIE
            releasingOnOrAfter: $movieReleasingOnOrAfter
            regionOverride: $regionOverride
            sort: [{ sortBy: POPULARITY, sortOrder: ASC }]
        ) {
            edges {
                node {
                    ...BaseTitleCard
                    ...TitleCardTrailer
                    releaseDate {
                        day
                        month
                        year
                    }
                    latestTrailer {
                        name {
                            value
                        }
                        runtime {
                            value
                        }
                        thumbnail {
                            height
                            width
                            url
                        }
                    }
                    cinemas(
                        first: 0
                        request: { location: $movieViewerLocation }
                    ) {
                        total
                    }
                    meterRanking {
                        currentRank
                    }
                }
            }
        }
    }
    ${eB.sq}
    ${eB.F4}
`,e5=(0,eG.O)({query:()=>{let e=eF(),t=(0,ef.wT)(),i=eb.B().context.sidecar?.localizationResponse.userCountryCode??"US",[r]=(0,eW.E)({query:e7,variables:{movieReleasingOnOrAfter:e,movieViewerLocation:t,regionOverride:i},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!1}});return r},component:e=>{let t={...e,type:A.M4k.Movie};return(0,r.jsx)(e8,{...t})}});var e6=i(78270),e9=i(23842),te=i(49175);let tt=e=>{let{classname:t,items:i,buttonText:n}=e,{showtimesTitleLinkBuilder:a}=(0,x.WOb)(),{createPrompt:s}=(0,te.V1)(),l=(0,T.EJ)();return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(o.Shoveler,{onPageChange:l,children:i.map((e,i)=>(0,r.jsx)(e9.c,{className:t,data:e,index:i+1,alternateButton:ti(n,e,i,a)},e.id))}),s()]})},ti=(e,t,i,r)=>({text:e,props:{ariaLabel:e,preIcon:"ticket",href:r({tconst:t.id,refSuffix:{t:b.Cd.EMPTY,n:i+1}})}}),tr=e=>{let{showtimesLinkBuilder:t}=(0,x.WOb)(),i=(0,g.b)(e.data?.showtimesTitles?.edges).slice(0,30);(0,e6.b)(i);let n=(0,m.N)({id:"in_theaters_title",defaultMessage:"In theaters"}),a=(0,m.N)({id:"in_theaters_description",defaultMessage:"Showtimes near you"}),s=(0,m.N)({id:"in_theaters_showtimes_button_text",defaultMessage:"Showtimes"}),o=(0,ev.JY)({id:"in-theaters",height:"title-cards",title:n,description:a,link:t({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>i.length>5},e);return(0,r.jsx)(ev.GN,{...o,children:(0,r.jsx)(tt,{classname:"in-theaters-title",items:i,buttonText:s})})};var tn=e=>(0,r.jsx)(b.xm,{value:b.Cd.IN_THEATERS,children:(0,r.jsx)(tr,{...e})});let ta=_()`
    query InTheatersHomepage($inTheatersLocation: ShowtimesLocation!) {
        showtimesTitles(
            first: 30
            location: $inTheatersLocation
            queryMetadata: { sortField: SHOWTIMES_COUNT, sortOrder: DESC }
        ) {
            edges {
                node {
                    ...BaseTitleCard
                    ...TitleCardTrailer
                }
            }
        }
    }
    ${eB.sq}
    ${eB.F4}
`;var ts={InTheatersEntity:(0,eG.O)({query:()=>{let e=(0,ef.wT)(),[t]=(0,eW.E)({query:ta,variables:{inTheatersLocation:e},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!1}});return t},component:e=>(0,r.jsx)(tn,{...e})}),TopBoxOfficeEntity:eV,ComingSoonMovieEntity:e5},to=e=>{let{pageQueryData:t}=e,i=n.useRef(null),a=(0,eh.T)(i,{root:null,threshold:0,rootMargin:"200px"});return(0,r.jsx)(X.Z,{name:"ExploreMoviesAndTV",children:(0,r.jsx)("div",{ref:i,children:(0,r.jsxs)(en,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.CategoryTitle,{"data-testid":"exploreMoviesAndTv_title",children:(0,r.jsx)(ei.q,{id:"homepage_main_category_exploreMoviesAndTV",defaultMessage:"Explore Movies & TV shows"})})}),(0,r.jsx)(er.Z,{groupConfig:ts,pageQueryData:t,hasIntersected:a})]})})})},tl=i(41174),td=i(73078),tc=i(42712);let tp=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[];return(0,n.useMemo)(()=>{if(!e.length||!t.length)return e;let i=t.map(e=>e.id),r=[],n=[];return e.forEach(e=>{i.includes(e.id)?r.push(e):n.push(e)}),r.sort((e,t)=>i.indexOf(e.id)-i.indexOf(t.id)),[...r,...n]},[e,t])},tm=(e,t,i)=>{let r=t.findIndex(e=>e.provider.id===i);if(r<0)return"unknown";let n=t[r].provider.refTagFragment;return`${e}_${n}_tab_${r+1}`};var tg=i(54137),tu=i(14911);let th={ParamountPlus:"amzn1.imdb.w2w.provider.cbs_aa",AMC_PLUS:"amzn1.imdb.w2w.provider.amcplus",PrimeVideo:"amzn1.imdb.w2w.provider.prime_video.PRIME",Netflix:"amzn1.imdb.w2w.provider.netflix",AppleTV:"amzn1.imdb.w2w.provider.appletv",Hulu:"amzn1.imdb.w2w.provider.hulu",HBO_MAX:"amzn1.imdb.w2w.provider.hbo_max",Peacock:"amzn1.imdb.w2w.provider.peacock",Starz:"amzn1.imdb.w2w.provider.starz",Showtimes:"amzn1.imdb.w2w.provider.showtime"},tf=_()`
    query StreamingPicks_WatchNow($titleIds: [ID!]!, $providerId: ID!) {
        titles(ids: $titleIds) {
            id
            watchOption(providerId: $providerId) {
                link(platform: WEB)
                provider {
                    refTagFragment
                }
            }
        }
    }
`,tx=()=>({watchNowText:(0,m.N)({id:"common_buttons_watchNow",defaultMessage:"Watch now"}),includedWithPrimeText:(0,m.N)({id:"streamingPicks_providerDescription_withPrime",defaultMessage:"included with Prime"}),withSubscriptionText:(0,m.N)({id:"streamingPicks_providerDescription_withSubscription",defaultMessage:"with subscription"}),onHuluText:(0,m.N)({id:"streamingPicks_providerDescription_onHulu",defaultMessage:"on Hulu.com and the Hulu app"}),withPrimeVideoChannelsText:(0,m.N)({id:"streamingPicks_providerDescription_withPrimeVideoChannels",defaultMessage:"with Prime Video Channels"})}),tb=(e,t)=>{let i=e.map(e=>e.title.id),[r]=(0,eW.E)({query:tf,variables:{titleIds:i,providerId:t},context:{personalized:!1,serverSideCacheable:!0}}),n=r.fetching?{}:r?.data?.titles.reduce((e,t)=>(t?.id&&(e[t?.id]=t?.watchOption),e),{})||{};return{fetching:r.fetching,byTitle:n}},tT=e=>{let{tabIndex:t,providerId:i,providerDescription:n,streamingTitles:a}=e,s=(0,b.Lz)().value,{adPreferencesLinkBuilder:l}=(0,x.WOb)(),d=tx(),c=tb(a,i),p=(0,Q.Ok)().adSlotsInfo,m=(0,T.EJ)(),g=(0,tu.Z)();(0,e6.b)(a.map(e=>e.title));let u=(e,t)=>{let i=c.byTitle[e],r={id:e,prefix:s,suffix:`tt_${t+1}`};return i?g({titleId:e,watchOption:i,refMarker:r,adSlotsInfo:p}):{}},h=(e,t,i)=>{let r=u(e,i);if(0!==Object.keys(r).length||c.fetching)return{props:{...r,className:"title-watchnow-button"},text:d.watchNowText,fetching:c.fetching}},f=tv((e=>{switch(e){case th.PrimeVideo:return d.includedWithPrimeText;case th.Netflix:case th.AppleTV:case th.HBO_MAX:case th.AMC_PLUS:case th.Peacock:case th.ParamountPlus:return d.withSubscriptionText;case th.Hulu:return d.onHuluText;case th.Starz:case th.Showtimes:return d.withSubscriptionText;default:return""}})(i),n);return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)(ty,{className:"streaming-picks-description",children:[f,i===th.ParamountPlus&&0===t&&(0,r.jsx)(r.Fragment,{children:(0,r.jsx)(tg.$,{includeSpacingDot:!0,adFeedbackUrl:l({refSuffix:b.Cd.EMPTY}),inheritFontSize:!0})})]}),(0,r.jsx)(o.Shoveler,{onPageChange:m,children:a.map((e,t)=>(0,r.jsx)(e9.c,{refTagFromGraph:c.byTitle[e.title.id]?.provider.refTagFragment,index:t+1,className:"streaming-picks-title",data:e.title,alternateButton:h(e.title.id,i,t)},e.title.id))},`${t}-${i}`)]})},tv=(e,t)=>{let i=e||t;return i?`${i[0].toLowerCase()}${i.slice(1)}`:""},ty=s.ZP.p.withConfig({componentId:"sc-14743c42-0"})(["",";margin-bottom:1rem;"],(0,c.setPropertyToSpacingVar)("margin-left","ipt-pageMargin")),tw=e=>{let{providerPicks:t,preferredWatchProviders:i=[]}=e,a=(0,b.Lz)().value,s=(0,T.EO)(),l=tp(t.map(e=>({id:e.provider.id,label:e.provider.name.value})),i),[d,c]=(0,n.useState)(l[0]?.id);if(t.length<1)return null;let p=t_(t,d);return p?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(tj,{"data-testid":"streaming-picks-tab-container",children:(0,r.jsx)(o.Tabs,{className:"streaming-picks-tabs",tabs:l,onChange:e=>{c(e),tC(a,t,e,s)}},"tabs")}),(0,r.jsx)("div",{"data-testid":"streaming-picks-shoveler",children:(0,r.jsx)(tT,{...p})})]}):null},t_=(e,t)=>{if(!t)return null;let i=e.findIndex(e=>e.provider.id===t);if(-1===i)return null;let r=e[i];return{tabIndex:i,providerId:t,providerDescription:r.provider.description?.value,streamingTitles:r.titles}},tC=(e,t,i,r)=>{r({refMarkerString:tm(e,t,i),pageAction:"tab-select"})},tj=s.ZP.div.withConfig({componentId:"sc-a6e5c7a6-0"})(["",";margin-bottom:1rem;"],(0,c.setPropertyToSpacingVar)("margin-left","ipt-pageMargin")),tS=e=>{let t=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}}),i=tP(e.data),n=t?tI(e.data):[],a=(0,ev.JY)({id:"streaming-picks",height:"title-cards",shouldRender:()=>i.length>0},e);return(0,r.jsx)(ev.GN,{...a,children:(0,r.jsx)(tw,{providerPicks:i,preferredWatchProviders:n})})},tP=e=>e&&e.streamingTitles?e.streamingTitles.filter(e=>e.provider&&e.titles&&e.titles.edges.length>0).map(e=>({provider:e.provider,titles:(0,g.b)(e.titles.edges)})):[],tI=e=>(0,g.b)(e?.user?.preferredStreamingProviders.streamingProviders.edges);var tN=e=>(0,r.jsx)(b.xm,{value:b.Cd.STREAMING_PICKS,children:(0,r.jsx)(tS,{...e})});let tE=_()`
    query HomepageStreamingPicks(
        $includeUserPreferredServices: Boolean! = false
    ) {
        streamingTitles {
            provider {
                id
                name {
                    value
                }
                description {
                    value
                }
                refTagFragment
            }
            titles(first: 25) {
                edges {
                    node {
                        title {
                            ...BaseTitleCard
                            ...TitleCardTrailer
                        }
                    }
                }
            }
        }
        user @include(if: $includeUserPreferredServices) {
            ...UserPreferredServices
        }
    }
    ${eB.sq}
    ${eB.F4}
    ${tc.R}
`,tk=(0,eG.O)({query:e=>{let{isLoggedIn:t}=e??{},i=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}})&&t,[r]=(0,eW.E)({query:tE,variables:{includeUserPreferredServices:i},context:{personalized:i||!1,serverSideCacheable:!1,clientSideBatch:!1}});return r},component:e=>(0,r.jsx)(tN,{...e})}),tM={id:"homepage_main_category_exploreStreaming",defaultMessage:"Explore what’s streaming"},tO={editPreferredServicesButton:"exploreStreaming_editPreferredServicesButton",exploreStreamingtitle:"exploreStreaming_title",setYourPreferredServicesButton:"exploreStreaming_setYourPreferredServicesButton"};var tR={StreamingPicksEntity:tk},tA=e=>{let{pageQueryData:t}=e,i=(0,tl.nu)(),a=n.useRef(null),s=(0,eh.T)(a,{root:null,threshold:0,rootMargin:"300px"}),l=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}});return(0,r.jsx)(X.Z,{name:"ExploreStreaming",children:(0,r.jsx)("div",{ref:a,children:(0,r.jsxs)(en,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.CategoryTitle,{"data-testid":tO.exploreStreamingtitle,actions:!!l&&(0,r.jsx)(tD,{refSuffix:[b.Cd.STREAMING_PICKS,b.Cd.BUTTON],"data-testid":i?tO.editPreferredServicesButton:tO.setYourPreferredServicesButton}),children:(0,r.jsx)(ei.q,{...tM})})}),(0,r.jsx)(er.Z,{groupConfig:tR,pageQueryData:t,hasIntersected:s})]})})})};let tD=(0,s.ZP)(td.Z).withConfig({componentId:"sc-2b65d4af-0"})(["","{margin-top:",";}"],c.mediaQueries.breakpoints.below.m,c.spacing.m);var tZ=i(81999),t$=i(88854),tL={featuredToday:{component:()=>(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_FEATURED,children:(0,r.jsx)(em,{slotNamePrefix:"featured-today"})})},eventOscars:{component:()=>{let e=(0,m.N)({id:"editorialCarousel_special_event",defaultMessage:"Spotlight: Oscars (2020)"});return(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_OSCARS,children:(0,r.jsx)(em,{slotNamePrefix:"event-oscars",title:e})})}}};let tV=(0,tZ.vU)({title:{id:"homepage_main_category_featuredToday",defaultMessage:"Featured today"}});var tB=e=>{let{pageQueryData:t}=e,i=(0,ex.Z)(),n=(0,t$.kp)().isValid;return(0,r.jsx)(X.Z,{name:"FeaturedToday",children:(0,r.jsxs)(en,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:2,children:(0,r.jsxs)(o.PageSection,{children:[n&&(0,r.jsx)(o.CategoryTitle,{children:i.formatMessage(tV.title)}),(0,r.jsx)(er.Z,{groupConfig:tL,pageQueryData:t,hideErrors:!1})]})}),(0,r.jsx)(o.PageGrid.Item,{span:1,children:(0,r.jsx)(z.ZP,{name:H.A.INLINE40})})]})})},tF=i(76857),tW=i(95746);let tG=e=>Object.keys(e).filter(t=>{let i=e[t].transformedArguments;return(0,tW.J)(i?.errors)});var tq=i(23906),tz=i(24391);let tU=Object.freeze({slidesPerView:1,effect:"slide",autoplay:{delay:5e3},loop:!0,observer:!0,threshold:20});var tH=i(81611),tQ=i(51244),tY=i(99672),tX=i(1833);let tK=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-0"})(["height:52px;"]),tJ=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-1"})(["height:","px;overflow:hidden;position:relative;","{height:","px;}"],444,c.mediaQueries.breakpoints.only.l,339),t0=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-2"})(["position:absolute;top:0;bottom:0;left:0;right:0;overflow:hidden;background:linear-gradient( 0deg,transparent 0%,transparent 50%,rgba(",",0.7) 78%,rgba(",",1) 100% );.editorial-slots{height:100%;display:flex;flex-direction:column;top:-","px;position:absolute;width:100%;","{top:-","px;}}"],(0,c.getColorVar)("ipt-baseAlt-shade3-rgb"),(0,c.getColorVar)("ipt-baseAlt-shade3-rgb"),296,c.mediaQueries.breakpoints.only.l,226),t1=(0,s.ZP)(o.Poster.Image).withConfig({componentId:"sc-9b43ec2b-3"})(["height:100%;width:100%;left:0;bottom:0;img{height:100%;width:100%;}"]),t2=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-4"})(["padding:0px 16px;flex:0 0 ","px;","{flex:0 0 ","px;}width:100%;position:relative;overflow:hidden;transition:all 300ms;&.transit-enter{flex-basis:0;}&.transit-enter-active{flex-basis:","px;","{flex-basis:","px;}}&.transit-exit{flex-basis:","px;","{flex-basis:","px;}}&.transit-exit-active{flex-basis:0;}"],113,c.mediaQueries.breakpoints.above.xl,148,113,c.mediaQueries.breakpoints.above.xl,148,113,c.mediaQueries.breakpoints.above.xl,148),t4=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-5"})(["left:16px;bottom:0;width:88px;padding-top:16px;","{width:67px;}"],c.mediaQueries.breakpoints.only.l),t3=s.ZP.a.withConfig({componentId:"sc-9b43ec2b-6"})(["&:hover{cursor:pointer;.editorial-play-icon{",";}}position:absolute;top:0;right:0;left:112px;","{left:83px;padding:16px 8px 0;overflow:hidden;text-decoration:none;}padding:18px 8px 0;overflow:hidden;text-decoration:none;",";"],(0,c.setPropertyToColorVar)("color","ipt-on-base-accent1-color"),c.mediaQueries.breakpoints.only.l,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),t8=s.ZP.div.withConfig({componentId:"sc-9b43ec2b-7"})(["flex:0;width:100%;text-align:left;position:relative;"]),t7=(0,s.ZP)(t8).withConfig({componentId:"sc-9b43ec2b-8"})(["margin-bottom:3px;&.reactions{display:flex;align-items:flex-end;margin-bottom:10px;","{margin-bottom:6px;}}"],c.mediaQueries.breakpoints.only.l),t5=(0,s.ZP)(t8).withConfig({componentId:"sc-9b43ec2b-9"})(["max-height:40px;"]),t6=(0,s.iv)(["",";text-align:start;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;"],(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),t9=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-10"})([""," ",";font-weight:400;width:100%;display:inline-block;",";white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;max-height:40px;"],t6,(0,c.setTypographyType)("subtitle"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-color")),ie=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-11"})([""," ",";width:100%;display:inline-block;&.reactions{display:block;","{display:none;}}"],t6,(0,c.setTypographyType)("bodySmall"),c.mediaQueries.breakpoints.only.l),it=(0,s.ZP)(eU.I).withConfig({componentId:"sc-9b43ec2b-12"})(["margin-left:0;margin-top:4px;","{margin-bottom:0;margin-top:2px;}"],c.mediaQueries.breakpoints.only.l),ii=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-13"})(["&:not(.reactions){"," ",";display:inline-block;}&.reactions{",";",";}"],t6,(0,c.setTypographyType)("bodySmall"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color"),(0,c.setTypographyType)("bodySmall")),ir=s.ZP.span.withConfig({componentId:"sc-9b43ec2b-14"})([""," ",";display:block;width:100%;padding:4px 0;",";text-align:left;"],t6,(0,c.setTypographyType)("headline6"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-accent1-color")),ia=(0,s.iv)(["height:32px;width:32px;&.reactions{","{height:28px;width:28px;}}margin-right:8px;",";"],c.mediaQueries.breakpoints.only.l,(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-color")),is=(0,s.ZP)(o.Icon).withConfig({componentId:"sc-9b43ec2b-15"})(["",""],ia);(0,s.ZP)(o.Icon).withConfig({componentId:"sc-9b43ec2b-16"})(["color:#cf1f4a;",""],ia);let io=(e,t)=>(t+e%t)%t,il=e=>{let{transformedArguments:t}=e;if(t)return t.promotedVideoData&&(t=t.promotedVideoData),{imageModel:t.posterImage,titleText:t.headline}},id=e=>{let{transformedArguments:t}=e;return t?(t.promotedVideoData&&(t=t.promotedVideoData),{runtime:t.runtime,videoTitle:t.subHeadline,videoId:t.videoId,videoContentType:t.videoContentType,listId:t.listId}):void 0},ic=(e,t,i)=>{let r=t[e]?.slotName,n=i.transformedPlacements[r];if(!n)return;let a=il(n),s=id(n),o=n.transformedArguments?.promotedVideoData?.adData,l=`${e}-${Math.random()}`;return{slotIndex:e,peekImageModel:a,peekVideoSlateModel:s,adData:o,key:l}},ip=(e,t,i)=>t===io(e-1,i)?-1:io(t-e,i),im=(e,t,i)=>{let r=t.length,n=[],a=e+-1;for(let e=a;e<a+6;e+=1){let a=ic(io(e,r),t,i);a&&n.push(a)}return n},ig=(e,t,i,r)=>{let n=i.length,a=t.slice();if(e<0)for(let t=e;t<0;t+=1){let e=io(a[0]?.slotIndex-1,n);a.unshift(ic(e,i,r)),a.pop()}else if(e>0)for(let t=0;t<e;t+=1){let e=io(a[a.length-1]?.slotIndex+1,n);a.push(ic(e,i,r)),a.shift()}return a};var iu=e=>{let{slots:t,swiper:i}=e,{videoSingleLinkBuilder:a}=(0,x.WOb)(),[s,o]=(0,n.useState)(0),l=(0,tY.Z)(s),d=(0,t$.kp)(),{makeRefMarker:c}=(0,b.Lz)(),p=(0,m.N)({id:"hero_video_up_next",defaultMessage:"Up next"}),g=im(0,t,d),[u,h]=(0,n.useState)(g),f=t.length;(0,n.useEffect)(()=>{if(i)return i.on("slideChangeTransitionStart",e),function(){i.off("slideChangeTransitionStart",e)};function e(){let{realIndex:e}=this;o(e)}},[i]),(0,n.useEffect)(()=>{h(ig(ip(l||0,s,f),u,t,d))},[s]);let T=(0,n.useRef)(null);return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(tK,{children:(0,r.jsx)(ir,{children:p})}),(0,r.jsx)(tJ,{children:(0,r.jsx)(t0,{children:(0,r.jsx)(tQ.Z,{className:"editorial-slots",children:u.map(e=>{let t;if(!e)return null;let{slotIndex:i,peekImageModel:n,peekVideoSlateModel:s,adData:o,key:l}=e,{runtime:d,videoId:p,videoTitle:m,listId:g}=s||{},{imageModel:u,titleText:h}=n||{},f=(0,r.jsx)(is,{type:"inline",className:y()("editorial-play-icon","reactions"),name:"play-circle-outline-large-inline"});if(p){let e=c({t:b.Cd.VIDEO,n:i+1}),r=a({viconst:p,refSuffix:b.Cd.EMPTY,query:g?{listId:g}:void 0});t=(0,tX.Lr)(r,e)}return(0,r.jsx)(tH.Z,{classNames:"transit",nodeRef:T,timeout:300,children:(0,r.jsxs)(t2,{ref:T,children:[(0,r.jsx)(t4,{children:(0,r.jsx)(t1,{className:"peek-poster-image",imageModel:u,dynamicWidth:!0})}),(0,r.jsxs)(t3,{href:t,children:[(0,r.jsxs)(t7,{className:"reactions",children:[f,(0,r.jsx)(ii,{className:"reactions",children:d})]}),(0,r.jsx)(t5,{children:(0,r.jsx)(t9,{children:h})}),(0,r.jsx)(t8,{children:(0,r.jsx)(ie,{className:"reactions",children:m})}),!o&&(0,r.jsx)(it,{associatedConstId:p,entityType:"video"})]})]})},l)})})})})]})},ih=i(3820);i(80167);var ix=i(59899);let ib="hero-promoted-video-ad",iT=(e,t,i)=>{let r=[];return e&&r.push({slotName:ib}),t.forEach(e=>{i.transformedPlacements[e]&&r.push({slotName:e})}),r},iv=(e,t)=>{let{slotName:i}=e;return(0,r.jsx)(el.Z,{slotName:i},t)},iy=s.ZP.div.withConfig({componentId:"sc-244aa702-0"})(["position:relative;margin:8px auto;display:flex;justify-content:center;max-width:1280px;"," ","{flex-direction:column;}"],(0,c.setPropertyToColorVar)("background","ipt-baseAlt-color"),c.mediaQueries.breakpoints.below.l),iw=s.ZP.div.withConfig({componentId:"sc-244aa702-1"})(["flex:846;margin:0 8px;position:relative;overflow:hidden;","{flex:664;}","{flex:100%;}"],c.mediaQueries.breakpoints.only.l,c.mediaQueries.breakpoints.below.l),i_=s.ZP.div.withConfig({componentId:"sc-244aa702-2"})(["flex:402;margin:0 8px 0 4px;position:relative;overflow:hidden;display:flex;flex-direction:column;justify-content:space-between;","{flex:328;}","{flex:0;}"],c.mediaQueries.breakpoints.only.l,c.mediaQueries.breakpoints.below.l),iC=s.ZP.div.withConfig({componentId:"sc-244aa702-3"})(["width:100%;","{display:none;}"],c.mediaQueries.breakpoints.below.l),ij=s.ZP.div.withConfig({componentId:"sc-244aa702-4"})(["padding:16px 16px 0;text-align:left;","{background:none;}"],c.mediaQueries.breakpoints.below.l),iS=(0,s.ZP)(e=>{let{className:t,enableNavigation:i,enableVirtualSlides:a,carouselOptions:s,customNavigation:o,onInitialize:l,children:d}=e,c=(0,n.useRef)(null),p=y()(t,"swiper-container"),[m,g]=(0,n.useState)(d),[u,h]=(0,n.useState)(0),[f,x]=(0,n.useState)(0),[b,T]=(0,n.useState)(),{navigation:v={nextEl:".swiper-button-next",prevEl:".swiper-button-prev"},virtual:w={slides:d,addSlidesBefore:2,addSlidesAfter:2,renderExternal(e){let{slides:t,offset:i}=e;g(t),h(i)}},..._}=s,C=()=>{if(c?.current)try{c.current.update()}catch(e){}},j=function(e){let t,i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:250;return r=>{t&&clearTimeout(t),t=setTimeout(e,i,r)}};return(0,n.useEffect)(()=>{c.current=new ih.Z(c.current,{navigation:i&&v,pagination:!1,scrollbar:!1,virtual:a&&w,..._,on:{init(){let{params:e,activeIndex:t}=this,{slidesPerView:i}=e;x(Math.round(i)),T(t),l(c.current.swiper)},slideChange(){let{activeIndex:e}=this;T(e)}}}),l(c.current)},[]),(0,n.useEffect)(()=>C()),(0,n.useEffect)(()=>(window&&window.addEventListener("resize",j(C)),()=>{window&&window.removeEventListener("resize",j(C))}),[]),(0,r.jsxs)("div",{className:p,ref:c,children:[(0,r.jsx)("div",{className:"swiper-wrapper",children:a?m&&m.map(e=>null!==e&&(0,r.jsx)("div",{className:"swiper-slide",style:{left:`${u}px`},children:e},e.key)):n.Children.toArray(d).filter(e=>null!==e).map((e,t)=>(0,r.jsx)(ix.E.Provider,{value:{indexInCarousel:t,initialSlidesVisible:f,isInitiallyVisible:t<f,isActive:b===t,carouselElementRef:c},children:(0,r.jsx)("div",{className:"swiper-slide",children:e})},t))}),o]})}).withConfig({componentId:"sc-244aa702-5"})(["height:100%;width:100%;.swiper-slide{width:100%;}"]),iP=s.ZP.a.withConfig({componentId:"sc-244aa702-6"})(["text-decoration:none;",";",";svg{vertical-align:bottom;}&:hover{",";}"],(0,c.setTypographyType)("headline6"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textPrimary-color"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-accent1-color")),iI=(0,s.iv)(["background-image:none;position:absolute;z-index:100;top:30%;outline:none;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-o-user-select:none;user-select:none;&.swiper-button-disabled{visibility:hidden;}","{&.swiper-button-next,&.swiper-button-prev{visibility:hidden;}}"],c.mediaQueries.breakpoints.below.m),iN=s.ZP.div.withConfig({componentId:"sc-244aa702-7"})(["&.swiper-button-next{right:0;","}"],iI),iE=s.ZP.div.withConfig({componentId:"sc-244aa702-8"})(["&.swiper-button-prev{left:0;","}"],iI),ik=(0,s.ZP)(o.Pager).withConfig({componentId:"sc-244aa702-9"})(["&.swiper-buttons{","{padding:20px 12px;}}"],c.mediaQueries.breakpoints.above.m);var iM=()=>{let e=(0,tq.wL)("AutorotateVideoCarousel"),[t]=(0,tz.i)(),{trailersLinkBuilder:i}=(0,x.WOb)(),s=(0,T.EO)(),[l,d]=(0,n.useState)(),c=(0,m.N)({id:"hero_video_browse_trailers",defaultMessage:"Browse trailers"}),p=(0,t$.kp)(),g=p.isDebug,u=new Set(tG(p.transformedPlacements));u.forEach(i=>{let r=p.transformedPlacements[i],n=r.transformedArguments?.errors;n&&n.length>0&&(t(e,a.NextMetrics.EDITORIAL_ERROR,1),n.map(t=>{((0,tW.X)(t)||g)&&e.error({code:t.code,creativeId:r.symphonyMetadata?.creativeId,placementId:r.symphonyMetadata?.placementId,componentName:r.componentName,context:t.context})}))});let h=es("hero-video").reduce((e,t)=>u.has(t.name)?e:[...e,t.name],[]),f=!!p.transformedPlacements[ib]&&!u.has(ib),v=h.map(e=>Number(!!p.transformedPlacements[e])).reduce((e,t)=>e+t,0),w=Number(f)+v;if((0,n.useEffect)(()=>{if(l&&!(w<=0))return l.on("slideChangeTransitionEnd",e),function(){l.off("slideChangeTransitionEnd",e)};function e(){let{realIndex:e}=this;(0===e||e===w-1)&&l?.slideToLoop(e,0,!1)}},[l,w]),w<=0)return null;let _=i({refSuffix:b.Cd.SEE_MORE}),C=iT(f,h,p),j=C.map((e,t)=>iv(e,t)),S=w<2,P=(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(iE,{className:y()("swiper-button-prev",{"swiper-button-disabled":S}),children:(0,r.jsx)(ik,{className:"swiper-buttons",direction:"left",isVisible:!0,size:"large",onSelect:()=>{s({refMarkerSuffix:b.Cd.PREVIOUS,pageAction:"prev-button-click"})}})}),(0,r.jsx)(iN,{className:y()("swiper-button-next",{"swiper-button-disabled":S}),children:(0,r.jsx)(ik,{className:"swiper-buttons",direction:"right",isVisible:!0,size:"large",onSelect:()=>{s({refMarkerSuffix:b.Cd.NEXT,pageAction:"next-button-click"})}})})]});return(0,r.jsxs)(iy,{children:[(0,r.jsx)(iw,{children:(0,r.jsx)(iS,{carouselOptions:tU,customNavigation:P,enableNavigation:!0,className:tF.oM,onInitialize:d,children:j})}),(0,r.jsxs)(i_,{children:[(0,r.jsx)(iC,{children:(0,r.jsx)(iu,{slots:C,swiper:l})}),(0,r.jsx)(ij,{children:(0,r.jsxs)(iP,{href:_,className:"example-headline6",children:[c,(0,r.jsx)(o.Icon,{name:"chevron-right",className:"chevron-right"})]})})]})]})};let iO=()=>(0,r.jsx)(X.Z,{name:"HeroSection",children:(0,r.jsx)(en,{children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(iA,{children:(0,r.jsx)(iM,{})})})})});var iR=()=>(0,r.jsx)(b.xm,{value:b.Cd.HERO_CAROUSEL,children:(0,r.jsx)(iO,{})});let iA=s.ZP.div.withConfig({componentId:"sc-39f7131b-0"})(["max-width:1280px;"]);var iD=i(84355),iZ=i(51415),i$=i(76018);let iL=e=>{let{chips:t}=e;return(0,r.jsx)(iV,{children:t.map((e,t)=>(0,r.jsx)(o.Chip,{label:e.category,href:e.link,className:"chip"},`news-chip-${t}`))})},iV=(0,s.ZP)(o.ChipList).withConfig({componentId:"sc-5d76741-0"})(["",";margin-top:",";"],(0,c.setPropertyToSpacingVar)("padding-left","ipt-pageMargin"),c.spacing.m),iB=()=>{let{newsCelebrityLinkBuilder:e,newsMovieLinkBuilder:t,newsTopLinkBuilder:i,newsTvLinkBuilder:r}=(0,x.WOb)(),n=(0,m.N)({id:"topNews_chip_top_news",defaultMessage:"Top news"}),a=(0,m.N)({id:"topNews_chip_movie_news",defaultMessage:"Movie news"}),s=(0,m.N)({id:"topNews_chip_tv_news",defaultMessage:"TV news"}),o=(0,m.N)({id:"topNews_chip_celebrity_news",defaultMessage:"Celebrity news"});return[{category:n,link:i({refSuffix:[b.Cd.TOP,b.Cd.TAB]})},{category:a,link:t({refSuffix:[b.Cd.MOVIE,b.Cd.TAB]})},{category:s,link:r({refSuffix:[b.Cd.TV,b.Cd.TAB]})},{category:o,link:e({refSuffix:[b.Cd.CELEBRITY,b.Cd.TAB]})}]},iF=e=>e&&(e?.news?e.news.edges??[]:void 0)||[],iW=e=>{let{data:t}=e,{newsTopLinkBuilder:i}=(0,x.WOb)(),n=iB(),a=iF(t),s=(0,ev.JY)({id:"top-news",height:"other",title:(0,m.N)({id:"topNews_header",defaultMessage:"Top news"}),link:i({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>a.length>2},e);return(0,r.jsxs)(ev.GN,{...s,children:[(0,r.jsx)("div",{"data-testid":"news-shoveler",children:(0,r.jsx)(i$.X,{topNewsItems:a})}),(0,r.jsx)("div",{"data-testid":"news-chips",children:(0,r.jsx)(iL,{chips:n})})]})};var iG=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_NEWS,children:(0,r.jsx)(iW,{...e})});let iq={component:e=>(0,r.jsx)(iG,{...e}),shouldRender:e=>!0,fragment:{name:"TopNews",gql:_()`
            fragment TopNews on Query {
                news(category: TOP, first: 5) {
                    edges {
                        ...NewsItem
                    }
                }
            }
            ${iZ.s}
        `}},iz={EditorsPicksEntity:{component:()=>{let e=(0,m.N)({id:"editorialCarousel_editors_picks",defaultMessage:"Editor's picks"});return(0,r.jsx)(b.xm,{value:b.Cd.EDITORIAL_CAROUSEL_PICKS,children:(0,r.jsx)(em,{slotNamePrefix:"editors-picks",title:e})})}},BornTodayEntity:iD.Z,TopNewsEntity:iq};var iU=e=>{let{pageQueryData:t}=e,i=n.useRef(null),a=(0,eh.T)(i,{root:null,threshold:0,rootMargin:"200px"});return(0,r.jsx)(X.Z,{name:"MoreToExplore",children:(0,r.jsx)(en,{className:"page-grid",children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsxs)("div",{ref:i,children:[(0,r.jsx)(o.CategoryTitle,{"data-testid":"moreToExplore_title",children:(0,r.jsx)(ei.q,{id:"common_more_to_explore",defaultMessage:"More to explore"})}),(0,r.jsx)(er.Z,{groupConfig:iz,pageQueryData:t,hasIntersected:a})]})})})})};let iH={MostPopularStreamingEntity:i(76574).w},iQ=(0,tZ.vU)({header:{id:"homepage_main_category_exploreStreaming",defaultMessage:"Explore what's streaming"}});var iY=e=>{let{pageQueryData:t}=e,i=n.useRef(null),a=(0,ex.Z)(),s=(0,eh.T)(i,{root:null,threshold:0,rootMargin:"300px"});return(0,r.jsx)(X.Z,{name:"MostPopularStreaming",children:(0,r.jsx)("div",{ref:i,children:(0,r.jsxs)(en,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.CategoryTitle,{"data-testid":"morePopularStreaming_title",children:a.formatMessage(iQ.header)})}),(0,r.jsx)(er.Z,{groupConfig:iH,pageQueryData:t,hasIntersected:s})]})})})},iX=i(58139);let iK=e=>{let{value:t}=(0,b.Lz)(),{whatToWatchFanFavoritesLinkBuilder:i}=(0,x.WOb)(),{data:a}=e,s=(0,g.b)(a?.fanPicksTitles?.edges),o=a?.fanPicksTitles?.refTag?.ep13nReftag||void 0,l=(0,m.N)({id:"fan_favorites",defaultMessage:"Fan favorites"}),d=(0,m.N)({id:"fan_favorites_description",defaultMessage:"This week's top TV and movies"}),c=(0,ev.JY)({id:"fan-picks",height:"title-cards",title:l,description:d,link:i({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>s.length>5},e);return(0,r.jsx)(ev.GN,{...c,children:(0,r.jsx)(iX.t,{titles:s,cardOverride:e=>e.map((e,i)=>(0,n.createElement)(e9.c,{...e,key:`${t}-${e.data.id}-${i}`,className:"fan-picks-title",refTagFromGraph:o,index:i+1}))})})};var iJ=e=>(0,r.jsx)(b.xm,{value:b.Cd.FAN_FAV,children:(0,r.jsx)(iK,{...e})});let i0=_()`
    query FanFavoritesHomepage($fanPicksFirst: Int!, $fanPicksAfter: ID) {
        fanPicksTitles(first: $fanPicksFirst, after: $fanPicksAfter) {
            edges {
                node {
                    ...BaseTitleCard
                    ...TitleCardTrailer
                    ...TitleWatchOption
                }
            }
            refTag {
                ep13nReftag
            }
        }
    }
    ${eB.sq}
    ${eB.F4}
    ${te.sG.titleWatchOption}
`,i1=(0,eG.O)({query:()=>{let[e]=(0,eW.E)({query:i0,requestPolicy:"cache-and-network",variables:{fanPicksFirst:30},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!0}});return e},component:e=>(0,r.jsx)(iJ,{...e})});var i2=i(96621),i4=i(84314),i3=i(43421),i8=i(60635);let i7=e=>{let{classname:t,items:i}=e,{createButton:n,createPrompt:a}=(0,te.V1)(),s=(0,T.EJ)();return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(o.Shoveler,{onPageChange:s,children:i.map((e,i)=>(0,r.jsx)(e9.c,{className:t,data:e,index:i+1,alternateButton:n(e,i)},e.id))}),a()]})},i5=e=>{let{fromYourWatchlistTitles:t}=e;return void 0===t?null:(0,r.jsx)("div",{"data-testid":"logged-in-state",className:"fyw-logged-in",children:(0,r.jsx)(i7,{classname:"fyw-title",items:t})})},i6={id:"from_your_watchlist",defaultMessage:"From your Watchlist"},i9={id:"from_your_watchlist_description",defaultMessage:"Movies and TV shows that you have watchlisted"},re=e=>{let{data:t,error:i,isSignedIn:n}=e,a=(0,ex.Z)(),{whatToWatchFromWatchlistLinkBuilder:s}=(0,x.WOb)(),o=t?.predefinedList?.unreleasedCount?.total||0,l=t?(0,g.J)(t?.predefinedList):[];(0,i8.Q)(l);let d=n&&0!==l.length,c=t?.predefinedList?.ratedCount?.total||0,p=a.formatMessage(i6),m=a.formatMessage(i9),u=(0,ev.JY)({id:"from-your-watchlist",height:"title-cards",title:p,description:d?m:void 0,link:s({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>!0},e);return i?null:(0,r.jsx)(ev.GN,{...u,children:rt(n,c,o,l)})},rt=(e,t,i,n)=>e&&n.length>0?(0,r.jsx)(i5,{fromYourWatchlistTitles:n}):(0,r.jsx)(i3.OW,{isLoggedIn:e,hasRatedTitles:!!t&&t>0,hasUnreleasedTitlesInWatchlist:!!i&&i>0});var ri=e=>(0,r.jsx)(b.xm,{value:b.Cd.FROM_YOUR_WATCHLIST,children:(0,r.jsx)(re,{...e})});let rr=(0,eG.O)({query:e=>{let{isLoggedIn:t}=e??{},[i]=(0,eW.E)({query:i2.y,requestPolicy:"cache-and-network",variables:{first:30},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!0},pause:!t});return t?i:{fetching:!1,stale:!1}},component:e=>{let t=(0,i4.n)(),i={...e,isSignedIn:t};return(0,r.jsx)(ri,{...i})}});var rn=i(64411),ra=i(79544);let rs=_()`
    query PopularInterests {
        popularInterests(first: 50) {
            edges {
                node {
                    ...InterestCard
                }
            }
        }
    }
    ${ra.b}
`,ro=(0,eG.O)({query:e=>{let[t]=(0,eW.E)({query:rs,context:{personalized:!1,serverSideCacheable:!0,clientSideBatch:!0}});return t},component:e=>(0,r.jsx)(rn.Z,{...e})});var rl=i(89578);let rd=(0,eG.O)({query:()=>({fetching:!1,stale:!1}),component:e=>(0,ee.hg)({weblabID:J.lh.IMDB_SUGGESTED_TV_FROM_RATINGS_646975,treatments:{T1:!0}})?(0,r.jsx)(rl.Z,{shouldClientSideBatch:!0}):null}),rc=_()`
    query NameIdsInFavPeople {
        favPeopleNameIds: predefinedList(classType: FAVORITE_ACTORS) {
            nameListItemSearch(
                first: 250
                sort: { by: DATE_ADDED, order: DESC }
            ) {
                edges {
                    listItem: name {
                        id
                    }
                }
            }
        }
    }
`,rp=_()`
    query TitlesFromFavPeople(
        $nameIds: [ID!]!
        $startDate: Date!
        $endDate: Date!
    ) {
        favPeopleTitles: advancedTitleSearch(
            first: 250
            sort: { sortBy: RELEASE_DATE, sortOrder: ASC }
            constraints: {
                titleTypeConstraint: {
                    excludeTitleTypeIds: ["tvEpisode", "podcastEpisode"]
                }
                creditedNameConstraint: { anyNameIds: $nameIds }
                releaseDateConstraint: {
                    releaseDateRange: { start: $startDate, end: $endDate }
                }
            }
        ) {
            edges {
                node {
                    title {
                        ...BaseTitleCard
                        releaseDate {
                            displayableProperty {
                                value {
                                    plainText
                                }
                            }
                        }
                        credits(first: 5, filter: { names: $nameIds }) {
                            edges {
                                node {
                                    name {
                                        id
                                        nameText {
                                            text
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    ${eB.sq}
`;var rm=i(84636),rg=i.n(rm),ru=i(40981),rh=i(18355),rf=i(14149),rx=i(91359),rb=i(70902);let rT=new Date,rv=rT.toISOString().split("T")[0],ry=new Date(rT.getFullYear(),rT.getMonth()-2,rT.getDate()).toISOString().split("T")[0],rw=new Date(rT.getFullYear(),rT.getMonth()+2,rT.getDate()).toISOString().split("T")[0],r_=e=>{let{initialData:t}=e,i=(0,ex.Z)(),a=(0,tl.nu)(),s=(0,b.Lz)().value,{chartStarMeterLinkBuilder:d,titleMainLinkBuilder:c}=(0,x.WOb)(),p=(0,eb.B)().context,m=(0,T.EJ)(),g=(0,o.useBreakpointsAsConfig)(),u=g.xs||g.s,[h,f]=(0,n.useState)(!1),[v,y]=(0,n.useState)(!0),[w,_]=(0,n.useState)((t?.favPeopleNameIds?.nameListItemSearch?.edges??[]).map(e=>e.listItem?.id).filter(Boolean)),[C,j]=(0,n.useState)(ry),[S,P]=(0,n.useState)(rv),[I,N]=(0,n.useState)([]),[{data:E}]=(0,tl.E8)({query:rc,context:{personalized:!0,serverSideCacheable:!1},pause:!a||!(0,l.getIsBrowser)()||w.length>0});(0,n.useEffect)(()=>{E&&_((E?.favPeopleNameIds?.nameListItemSearch?.edges??[]).map(e=>e.listItem?.id).filter(Boolean))},[E]);let[{data:k,fetching:M,error:O}]=(0,tl.E8)({query:rp,variables:{nameIds:w,startDate:C,endDate:S},context:{personalized:!0,serverSideCacheable:!1},pause:!a||!(0,l.getIsBrowser)()||!w.length||!v});if((0,n.useEffect)(()=>{k&&N((k?.favPeopleTitles?.edges??[]).map(e=>e?.node?.title))},[k]),(0,tl.bd)(I.map(e=>({id:e.id}))),!a)return null;let R=i.formatMessage({id:"suggested_tv_from_ratings_upcoming",defaultMessage:"Upcoming"}),A=i.formatMessage({id:"suggested_tv_from_ratings_recent",defaultMessage:"Recent"}),D=i.formatMessage({id:"suggested_tv_from_ratings_switch_aria",defaultMessage:"Switch to show {value} titles"},{value:h?A:R}),Z=()=>(0,r.jsxs)(rE,{children:[A,(0,r.jsx)(rk,{ariaLabel:D,checked:h,onChange:()=>{let e=!h;j(e?rv:ry),P(e?rw:rv),f(e),y(!0)}}),R]}),$=!M&&k;return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(ea.P,{id:"suggestedFromFavPeople"}),(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsxs)(o.PageSection,{children:[(0,r.jsxs)(rM,{children:[(0,r.jsx)(o.SubSectionTitle,{description:i.formatMessage({id:"favPeople_page_description",defaultMessage:"See recent or upcoming titles from your favorite people"}),children:i.formatMessage({id:"home_favPeople_feature_description",defaultMessage:"Catch up with your favorite people"})}),!u&&(0,r.jsx)(Z,{})]}),u&&(0,r.jsx)(Z,{}),(M||!k&&!O)&&(0,r.jsx)(rO,{children:(0,r.jsx)(o.Loader,{className:"suggested-titles-loader"})}),O&&!k&&(0,r.jsx)(rI,{children:(0,r.jsx)(rf.ZP,{canRetry:!0,errorMessage:i.formatMessage({id:"home_favPeople_feature_error_state",defaultMessage:"Sorry, there was an issue fetching your favorite names."}),name:"Suggested from favorite people",onClickRetry:()=>y(!0)})}),$&&0===I.length&&(0,r.jsxs)(rI,{children:[(0,r.jsx)(rN,{children:i.formatMessage({id:"home_favPeople_feature_empty_state_1",defaultMessage:"Want better suggestions? Favorite more people!"})}),(0,r.jsx)(o.TextLink,{href:d({refSuffix:b.Cd.SEE_MORE}),text:i.formatMessage({id:"home_favPeople_feature_empty_state_2",defaultMessage:"Start by checking out the most popular celebs"})})]}),$&&I.length>0&&(0,r.jsx)(o.Shoveler,{onPageChange:m,children:I.map((e,t)=>{let n=(0,ek.L)(p,e.originalTitleText,e.titleText)??"",a=rg()(e.credits?.edges??[],"node.name.id");return(0,r.jsx)(o.ShovelerItem,{span:2,children:(0,r.jsxs)(o.PosterCard,{dynamicWidth:!0,children:[(0,r.jsx)(rh.y,{title:{id:e.id,titleText:n,titleTypeId:e.titleType?.id??"",image:e.primaryImage??{}},index:t+1}),(0,r.jsxs)(rP,{children:[(0,r.jsx)(ru.Nf,{canRate:!!e.canRate?.isRatable,hideMaxIMDbRating:!0,hideVoteCountOnSmallBreakpoints:!0,ratingsSummary:e.ratingsSummary?e.ratingsSummary:void 0,showPlaceholderStarIfApplicable:!0,titleId:e.id,titleText:n}),(0,r.jsx)(o.PosterCard.Title,{ariaLabel:i.formatMessage(rx.F.GO_TO,{target:n}),href:c({tconst:e.id,refSuffix:{t:b.Cd.TEXT,n:t+1}}),children:n}),(0,r.jsx)(rS,{children:e.releaseDate?.displayableProperty?.value?.plainText}),(0,r.jsxs)(rj,{children:[a.slice(0,2).map(e=>{let t=e?.node?.name?.nameText?.text;return(0,r.jsx)("div",{children:t},`${s}-creditedName-${e.node.name.id}`)}),a.length>2&&(0,r.jsx)("div",{children:i.formatMessage({id:"home_favPeople_feature_more_people",defaultMessage:"+ {numMore} more"},{numMore:a.length-2})})]}),(0,r.jsx)(rb.Z,{index:t,titleData:e})]})]})},`${s}-item-${e.id}`)})})]})})]})};var rC=e=>(0,r.jsx)(b.xm,{value:b.Cd.SUGGESTED_FROM_FAV_PEOPLE,children:(0,r.jsx)(r_,{...e})});let rj=s.ZP.div.withConfig({componentId:"sc-3c3374c6-0"})(["",";"],(0,c.setTypographyType)("bodySmall")),rS=s.ZP.span.withConfig({componentId:"sc-3c3374c6-1"})(["",";",";margin:"," 0;"],(0,c.setTypographyType)("bodySmall"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color"),c.spacing.xs),rP=s.ZP.div.withConfig({componentId:"sc-3c3374c6-2"})(["display:flex;flex-direction:column;"]),rI=s.ZP.div.withConfig({componentId:"sc-3c3374c6-3"})(["align-items:center;display:flex;flex-direction:column;justify-content:center;margin-left:",";min-height:10rem;"],(0,c.getSpacingVar)("ipt-pageMargin")),rN=s.ZP.div.withConfig({componentId:"sc-3c3374c6-4"})(["font-weight:500;"]),rE=s.ZP.div.withConfig({componentId:"sc-3c3374c6-5"})(["",";align-items:center;display:flex;flex-direction:row;margin-bottom:",";margin-left:",";margin-right:",";width:fit-content;"],(0,c.setTypographyType)("overline"),c.spacing.m,(0,c.getSpacingVar)("ipt-pageMargin"),(0,c.getSpacingVar)("ipt-pageMargin")),rk=(0,s.ZP)(o.Switch).withConfig({componentId:"sc-3c3374c6-6"})(["margin:0 ",";"],c.spacing.xxs),rM=s.ZP.div.withConfig({componentId:"sc-3c3374c6-7"})(["align-items:center;display:flex;flex-direction:row;"]),rO=s.ZP.div.withConfig({componentId:"sc-3c3374c6-8"})(["margin-left:",";text-align:center;width:100%;.suggested-titles-loader{min-height:20rem;}"],(0,c.getSpacingVar)("ipt-pageMargin")),rR=(0,eG.O)({query:()=>{let e=(0,tl.nu)(),t=(0,ee.hg)({weblabID:J.lh.IMDB_SUGGESTED_TV_FROM_RATINGS_646975,treatments:{T1:!0}}),i=e&&t,[r]=(0,tl.E8)({query:rc,context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:i},pause:!i});return r},component:e=>(0,ee.hg)({weblabID:J.lh.IMDB_FAV_PEOPLE_780856,treatments:{T1:!0}})?(0,r.jsx)(rC,{initialData:e.data}):null});var rA=i(49996),rD=i(77845);let rZ=e=>{let{items:t,className:i}=e,n=(0,T.EJ)();return(0,r.jsx)(r.Fragment,{children:(0,r.jsx)(o.Shoveler,{className:i,onPageChange:n,children:t.map((e,t)=>(0,r.jsx)(rD.x,{recommendation:e,index:t},e.title.id))})})},r$=e=>{let{data:t,isSignedIn:i}=e,{registrationSignInLinkBuilder:n,whatToWatchTopPicksLinkBuilder:a}=(0,x.WOb)(),s=(0,g.b)(t?.titleRecommendations?.edges),o=(0,m.N)({id:"nav_userMenu_link_signIn",defaultMessage:"Sign in"}),l=(0,m.N)({id:"top_picks",defaultMessage:"Top picks"}),d=(0,m.N)({id:"top_picks_description",defaultMessage:"TV shows and movies just for you"}),c=(0,ev.JY)({id:"top-picks",height:"title-cards",title:l,description:d,link:a({refSuffix:b.Cd.SEE_MORE}),shouldRender:()=>s.length>5},e);return(0,r.jsxs)(ev.GN,{...c,children:[!i&&(0,r.jsx)(rL,{href:n({refSuffix:b.Cd.SIGN_IN}),text:o,className:"top-picks-sign-in-link"}),(0,r.jsx)(rZ,{items:s,className:"latest-picks"})]})},rL=(0,s.ZP)(o.TextLink).withConfig({componentId:"sc-3828dac7-0"})(["margin-left:",";margin-bottom:",";margin-top:0;font-size:",";display:block;"],(0,c.setPropertyToSpacingVar)("margin","ipt-pageMargin"),c.spacing.m,(0,c.setTypographyType)("bodySmall"));var rV=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_PICKS,children:(0,r.jsx)(r$,{...e})});let rB=_()`
    query TopPicksHomepage(
        $topPicksFirst: Int!
        $topPicksAfter: String
        $placement: String!
    ) {
        titleRecommendations(
            first: $topPicksFirst
            after: $topPicksAfter
            placementContext: { pageType: $placement }
        ) {
            edges {
                node {
                    refTag
                    title {
                        ...BaseTitleCard
                        ...TitleCardTrailer
                        ...TitleWatchOption
                    }
                    explanations {
                        title {
                            id
                            titleText {
                                text
                            }
                            originalTitleText {
                                text
                            }
                        }
                    }
                }
            }
        }
    }
    ${eB.sq}
    ${eB.F4}
    ${te.sG.titleWatchOption}
`,rF=(0,eG.O)({query:()=>{let{pageType:e}=(0,rA.y)(),[t]=(0,eW.E)({query:rB,variables:{topPicksFirst:30,placement:e},context:{personalized:!0,serverSideCacheable:!1,clientSideBatch:!0}});return t},component:e=>{let t=(0,i4.n)(),i={...e,isSignedIn:t};return(0,r.jsx)(rV,{...i})}}),rW=e=>{let{data:t,fetching:i}=e,n=(0,g.b)(t?.topMeterTitles?.edges);(0,tl.bd)(n);let a=(0,m.N)({id:"homepage_topTenTitles_title",defaultMessage:"Top 10 on IMDb this week"}),s=(0,ev.JY)({id:"top-ten",height:"title-cards",title:a,shouldRender:()=>o.length>5},e);if(!t?.topMeterTitles&&!i)return null;let o=n.map((e,t)=>({...e,titleText:e.titleText?.text?{text:`${t+1}. ${e.titleText.text}`}:void 0,originalTitleText:e.originalTitleText?.text?{text:`${t+1}. ${e.originalTitleText.text}`}:void 0}));return(0,r.jsx)(ev.GN,{...s,children:(0,r.jsx)(i7,{classname:"topten-title",items:o})})};var rG=e=>(0,r.jsx)(b.xm,{value:b.Cd.TOP_TEN_TITLES,children:(0,r.jsx)(rW,{...e})});let rq=_()`
    fragment TopTenTitlesEntry on Title {
        ...BaseTitleCard
        ...TitleCardTrailer
        ...TitleWatchOption
        meterRanking(input: { meterType: TITLE_METER }) {
            currentRank
            rankChange {
                changeDirection
                difference
            }
        }
    }
    ${eB.sq}
    ${eB.F4}
    ${te.sG.titleWatchOption}
`,rz=_()`
    query TopMeterTitlesWidget($topTenFirst: Int!) {
        topMeterTitles(
            first: $topTenFirst
            filter: { topMeterTitlesType: ALL }
        ) {
            edges {
                cursor
                node {
                    ...TopTenTitlesEntry
                }
            }
        }
    }
    ${rq}
`;var rU={ReturningToTV:rd,SuggestedFromFavPeople:rR,TopPicks:rF,FromYourWatchlist:rr,TopTenTitles:(0,eG.O)({query:()=>{let[e]=(0,tl.E8)({query:rz,variables:{topTenFirst:10},context:{personalized:!1,serverSideCacheable:!0,clientSideBatch:!0}});return e},component:e=>(0,r.jsx)(rG,{...e})}),FanFavorites:i1,PopularInterests:ro};let rH=(0,s.ZP)(o.CategoryTitle).withConfig({componentId:"sc-14c9c056-0"})(["margin-bottom:0;"]),rQ=s.ZP.div.withConfig({componentId:"sc-14c9c056-1"})(["padding-bottom:",";","{display:flex;justify-content:space-between;align-items:flex-end;}"],c.spacing.s,c.mediaQueries.breakpoints.above.l),rY=(0,s.ZP)(o.TextButton).withConfig({componentId:"sc-14c9c056-2"})(["margin-left:calc("," - ",");","{margin-left:calc( "," - "," );}","{margin-left:calc( "," - "," );}"],(0,c.getSpacingVarValue)("ipt-pageMargin"),c.spacing.xs,c.mediaQueries.breakpoints.only.xs,(0,c.getSpacingVarValue)("ipt-pageMargin"),c.spacing.m,c.mediaQueries.breakpoints.only.l,(0,c.getSpacingVarValue)("ipt-pageMargin"),c.spacing.m);var rX=e=>{let{pageQueryData:t}=e,{whatToWatchLinkBuilder:i}=(0,x.WOb)(),a=n.useRef(null),s=(0,eh.T)(a,{root:null,threshold:0}),l=(0,m.N)({id:"homepage_main_category_whatToWatch",defaultMessage:"What to watch"}),d=(0,m.N)({id:"homepage_main_button_browseWhatToWatch",defaultMessage:"Get more recommendations"});return(0,r.jsx)(X.Z,{name:"WhatToWatch",children:(0,r.jsxs)(en,{className:"page-grid",children:[(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(rQ,{ref:a,children:(0,r.jsx)(rH,{"data-testid":"whatToWatch_title",actions:(0,r.jsx)(rY,{"data-testid":"wtw-button",href:i({refSuffix:[b.Cd.WHAT_TO_WATCH,b.Cd.BUTTON]}),postIcon:"chevron-right",children:d}),children:l})})}),(0,r.jsx)(er.Z,{groupConfig:rU,pageQueryData:t,hideErrors:!1,hasIntersected:s})]})})};let rK=e=>!!(0,ec.S)()[e],rJ=e=>{let{slotName:t,logComponentName:i}=e,n=rK(t);return(0,r.jsx)(X.Z,{name:i,children:n&&(0,r.jsx)(en,{className:"page-grid",gutterBias:"center",children:(0,r.jsx)(o.PageGrid.Item,{span:3,children:(0,r.jsx)(o.PageSection,{children:(0,r.jsx)(el.Z,{slotName:t})})})})})},r0=e=>{(0,K.P)(J.lh.IMDB_SIX_DEGREES_HOME_SNACK_648093);let t=(0,ee.hg)({weblabID:J.lh.IMDB_NEXT_HOME_STREAMING_WIDGET_958820,treatments:{T1:!0,T2:!0}});return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)(Q.ZP,{children:[(0,r.jsx)(et.Z,{}),(0,r.jsx)(q.Z,{}),(0,r.jsx)(U.Z,{}),(0,r.jsxs)(X.Z,{name:"TopAd",children:[(0,r.jsx)(G.z,{}),(0,r.jsx)(o.PageBackground,{baseColor:"baseAlt",className:Y.R,children:(0,r.jsx)(o.PageContentContainer,{children:(0,r.jsx)(z.ZP,{name:H.A.INLINE20})})})]}),(0,r.jsxs)(r1,{children:[(0,r.jsx)(iR,{}),(0,r.jsx)(tB,{...e}),(0,r.jsx)(W.S,{}),(0,r.jsx)(rJ,{slotName:"center-1",logComponentName:"BestOf"}),(0,r.jsx)(V,{delayOnIntersection:!0}),(0,r.jsx)(rX,{...e}),(0,r.jsx)(eu,{...e}),t?(0,r.jsx)(iY,{...e}):(0,r.jsx)(tA,{...e}),(0,r.jsx)(to,{...e}),(0,r.jsx)(iU,{...e})]})]})})},r1=(0,s.ZP)(o.PageContentContainer).withConfig({componentId:"sc-6c67ef41-0"})(["position:relative;"]);var r2=i(50967),r4=!0,r3=e=>(0,r.jsx)(r2.Z,{baseColor:"baseAlt",orientContent:"full",hideAdWrap:!0,cti:a.CTIS.HOME_CTI,children:(0,r.jsx)(r0,{...e})})}},function(e){e.O(0,[7406,5601,3078,2161,5163,2727,4272,3036,5058,5522,967,634,5079,4538,9096,9380,3842,2550,3855,7644,9031,4829,9307,4516,2888,9774,179],function(){return e(e.s=87314)}),_N_E=e.O()}]);