"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9031],{35223:function(e,t,r){r.d(t,{TY:function(){return a},gA:function(){return n},z7:function(){return i}});let i={ADD_TO_LIST:"btp_atl",TRAILER:"btp_trlr",RETRY:"btp_ta",RATING_ROW:"btp_rt",RATING_DISPLAY:"btp_rt_ds",RATE_TRIGGER:"btp_rt_tg",METADATA_LIST:"btp_ml",GENRE_LIST:"btp_gl",PRODUCTION_STATUS:"btp_ps",SET_PREFERRED_SERVICES:"btp_sps"},a={ratingButtonRatedAriaLabel:{id:"common_ariaLabels_ratingButtonRated",defaultMessage:"Your rating: {rating}"},ratingButtonUnratedAriaLabel:{id:"common_ariaLabels_ratingButtonUnrated",defaultMessage:"Rate {titleName}"},ratingPromptRateLabel:{id:"common_ratingPrompt_rate",defaultMessage:"Rate"},closePrompt:{id:"common_ariaLabel_closePrompt",defaultMessage:"Close Prompt"},addToList:{id:"common_add_to_list_buttonText",defaultMessage:"Add to list"},trailer:{id:"common_buttons_trailer",defaultMessage:"Trailer"}},n="released"},19031:function(e,t,r){r.d(t,{Pz:function(){return eR},qo:function(){return ew},tN:function(){return eS}});var i=r(52322),a=r(30382),n=r.n(a),o=r(2784),s=r(53665),d=r(19596),l=r(88169),c=r(86704),p=r(45274),g=r(42712),u=r(41174),f=r(49666),m=r(4363),h=r(85846),x=r(95441),T=r(83163),b=r(48687),y=r(94475),v=r(10105),P=r(35223),_=r(4649),I=r(94471),w=r(75824),C=r(22073),S=r(82338),R=r(66724),j=r(11438),E=r(63370),O=r(6935),k=r(92847);let A=e=>{let{originalTitleText:t,titleText:r,id:a,primaryImage:n,titleType:s,titleGenres:d,ratingsSummary:p,canRate:g}=e.titleData,{palette:{baseColor:u}}=(0,o.useContext)(l.ThemeContext),m=(0,f.ik)(),{titleMainLinkBuilder:h}=(0,R.WOb)(),{rating:x}=(0,l.useRatingsContext)(a),T=(0,I.P)(x,"user"),b=(0,I.P)(p?.aggregateRating,"imdb"),y=(0,E.K)({originalTitleText:t,titleText:r}),v=(0,w.N)(P.TY.ratingButtonRatedAriaLabel,{rating:T||""}),_=(0,w.N)(P.TY.ratingButtonUnratedAriaLabel,{titleName:y}),A=(0,w.N)(P.TY.ratingPromptRateLabel),$=h({tconst:a,refSuffix:j.Cd.TEXT}),W=h({tconst:a,refSuffix:j.Cd.POSTER}),G=function(e){let t=[],{releaseYear:r,runtime:i,certificate:a}=e,n=(0,S.y)(r,e.titleType?.canHaveEpisodes);return n&&t.push(n),i?.seconds&&t.push((0,C.L)(i.seconds,C.A.HOURS_MINUTES_EXPLICIT)),a?.rating&&t.push(a.rating),t}(e.titleData);return(0,i.jsxs)(L,{className:u,children:[(0,i.jsx)(M,{children:(0,i.jsx)(l.Poster,{imageProps:{imageModel:(0,O.Gs)(n,y),imageType:s?.id,size:"xs"},dynamicWidth:!0,ariaLabel:y,href:W})}),(0,i.jsxs)(B,{children:[(0,i.jsx)(Z,{href:$,titleTextClass:"prompt-title-text",typographyType:(y?.length??0)>65?`${(0,c.setTypographyType)("subtitle")}`:"",children:y}),G.length>0&&(0,i.jsx)(l.InlineList,{showDividers:!0,inline:!0,noWrap:!0,"data-testid":P.z7.METADATA_LIST,children:G.map(e=>(0,i.jsx)(l.InlineListItem,{children:e},e))}),!!d&&d.genres.length>0&&(0,i.jsx)(l.InlineList,{showDividers:!0,inline:!0,noWrap:!0,"data-testid":P.z7.GENRE_LIST,children:d.genres.map(e=>(0,i.jsx)(l.InlineListItem,{children:e.genre.text},`${e.genre.text}`))}),!!(b||g?.isRatable)&&(0,i.jsxs)(N,{"data-testid":P.z7.RATING_ROW,children:[!!b&&(0,i.jsx)(l.RatingStar,{className:P.z7.RATING_DISPLAY,formattedRating:b,maxRating:10}),!!g?.isRatable&&!!y&&!m&&(0,i.jsx)(k.T,{title:{id:a,titleText:y,canRate:g.isRatable},ratingTriggerComponent:e=>{let{onUserRatingClick:t}=e;return(0,i.jsx)(D,{ariaLabelRated:v,ariaLabelUnrated:_,formattedRating:T,className:b?void 0:"standalone-star",onClick:t,rateLabel:A})}})]})]})]})},M=d.ZP.div.withConfig({componentId:"sc-5b5e8697-0"})(["width:4.5rem;"]),L=d.ZP.div.withConfig({componentId:"sc-5b5e8697-1"})(["display:flex;"," margin-bottom:",";margin-top:",";max-width:100%;padding-left:",";padding-right:",";","{padding-left:0;padding-right:0;margin-top:0;}&.base{","}&.baseAlt{","}"],(0,c.setTypographyType)("bodySmall"),c.spacing.s,c.spacing.xxs,c.spacing.s,c.spacing.s,c.mediaQueries.breakpoints.above.m,(0,c.setPropertyToColorVar)("color","ipt-on-base-textSecondary-color"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textSecondary-color")),B=d.ZP.div.withConfig({componentId:"sc-5b5e8697-2"})(["display:flex;flex-direction:column;padding-left:",";overflow:hidden;"],c.spacing.s),Z=(0,d.ZP)(l.Title).withConfig({componentId:"sc-5b5e8697-3"})(["margin-bottom:",";padding:0;"," .prompt-title-text{max-height:7.4rem;}"],c.spacing.xxs,e=>(0,d.iv)(["",""],e.typographyType)),N=d.ZP.div.withConfig({componentId:"sc-5b5e8697-4"})([""," .standalone-star{padding:0;min-width:0;}"],(0,c.setTypographyType)("body")),D=(0,d.ZP)(l.RateButton).withConfig({componentId:"sc-5b5e8697-5"})(["height:fit-content;"]);var $=r(15323);let W=e=>{let{labelTitle:t,listContent:r,"data-testid":a}=e;return(0,i.jsxs)(F,{"data-testid":a,children:[(0,i.jsx)(Y,{children:t}),(0,i.jsx)(V,{children:r?.filter(e=>"object"==typeof e&&null!==e&&"text"in e).map((e,t)=>{let r=e.text,a=t>0?` • ${r}`:r;return i.jsx(o.Fragment,{children:a},r)})})]})},G=e=>{let{data:t}=e,r=(0,s.Z)(),a=t?.productionBudget?.budget.amount,n=t?.lifetimeGross?.total.amount,o=t?.openingWeekendGross?.gross.total.amount,d=t?.worldwideGross?.total.amount,l=(0,$.AO)(t?.productionBudget),c=(0,$.yK)(t?.lifetimeGross),p=(0,$.UJ)(t?.openingWeekendGross),g=(0,$.pM)(t?.worldwideGross);return a||n||o||d?(0,i.jsx)(U,{"data-testid":"title-boxoffice-section",children:(0,i.jsxs)(z,{children:[!!a&&!!l&&(0,i.jsx)(W,{labelTitle:r.formatMessage(l.label),listContent:l.props.listContent,"data-testid":l.props["data-testid"]}),!!n&&!!c&&(0,i.jsx)(W,{labelTitle:r.formatMessage(c.label),listContent:c.props.listContent,"data-testid":c.props["data-testid"]}),!!o&&!!p&&(0,i.jsx)(W,{labelTitle:r.formatMessage(p.label),listContent:p.props.listContent,"data-testid":p.props["data-testid"]}),!!d&&!!g&&(0,i.jsx)(W,{labelTitle:r.formatMessage(g.label),listContent:g.props.listContent,"data-testid":g.props["data-testid"]})]})}):null},U=d.ZP.div.withConfig({componentId:"sc-8e95b90d-0"})(["margin:0 "," "," ",";","{margin:0 0 "," 0;}"],c.spacing.s,c.spacing.m,c.spacing.s,c.mediaQueries.breakpoints.above.m,c.spacing.m),z=d.ZP.div.withConfig({componentId:"sc-8e95b90d-1"})(["display:flex;flex-direction:column;","{flex-flow:row wrap;}"],c.mediaQueries.breakpoints.above.m),F=d.ZP.div.withConfig({componentId:"sc-8e95b90d-2"})(["display:grid;margin-bottom:",";","{width:50%;}"],c.spacing.s,c.mediaQueries.breakpoints.above.m),Y=d.ZP.div.withConfig({componentId:"sc-8e95b90d-3"})([""," font-weight:bold;"],(0,l.setTypographyType)("bodySmall")),V=d.ZP.div.withConfig({componentId:"sc-8e95b90d-4"})(["",""],(0,l.setTypographyType)("bodySmall"));var Q=r(14342),H=r(11602);let K=n()`
    fragment BaseTitlePrompt__Track on Title {
        id
        trackNotificationPreferences @include(if: $isProPage) {
            ...TrackPreferences
        }
    }
    ${H.vW}
`,X=e=>{let{data:t}=e;return t?(0,i.jsx)(q,{id:t.id,data:t.trackNotificationPreferences,displayTrackOptionsMenu:!1,buttonProps:{width:"full-width"},buttonType:"secondaryButton"}):null},q=(0,d.ZP)(Q.ZP).withConfig({componentId:"sc-e967ba0e-0"})(["width:100%;"]),J=n()`
    fragment BaseTitlePrompt__Trailer on Title {
        id
        latestTrailer @skip(if: $isProPage) {
            id
        }
    }
`,ee=e=>{let{data:t}=e,r=(0,s.Z)(),{videoSingleLinkBuilder:a}=(0,R.WOb)(),n=t?.latestTrailer?.id,o=n?a({viconst:n,refSuffix:j.Cd.TRAILER}):void 0;return o?(0,i.jsx)(l.SecondaryButton,{width:"full-width",preIcon:"play-arrow",href:o,"data-testid":P.z7.TRAILER,children:r.formatMessage(P.TY.trailer)}):null};var et=r(2870);let er=e=>{let{titleId:t}=e;return t?(0,i.jsx)(et.f,{titleId:t}):null};var ei=r(73078),ea=r(28160),en=r(85591),eo=r(82453),es=r(14911),ed=r(4958);let el=e=>{let{titleId:t,category:r,watchOptions:a,refMarker:n}=e,o=r.toUpperCase().replace("IMDB","IMDb"),s=(0,eo.Ok)().adSlotsInfo,d=(0,es.Z)();return(0,i.jsxs)(eu,{children:[(0,i.jsx)(ef,{"data-testid":`${o}-title`,children:o}),(0,i.jsx)(l.List,{"data-testid":`${o}-list`,children:!!t&&a.map(e=>{let a=d({titleId:t,watchOption:e,refMarker:n,adSlotsInfo:s}),o="shw"===e.provider.refTagFragment?e.title.value:e.provider.name.value,l=e.provider?.logos?.icon;return(0,i.jsx)(em,{...a,children:(0,i.jsxs)(eh,{children:[!!l?.url&&!!l?.width&&!!l?.height&&(0,i.jsx)(ex,{imageModel:{caption:o,url:l.url,maxWidth:l.width,maxHeight:l.height},size:50}),(0,i.jsxs)(eT,{children:[(0,i.jsx)(eb,{children:o}),(0,i.jsx)(ey,{children:e.description?.value})]})]})},`${r}-${e.link}`)})})]})},ec=e=>{let{titleId:t,watchOptionsCategories:r,isLoading:a,refMarker:n,preferredProviderIds:o=[]}=e,d=(0,s.Z)(),{organizedWatchOptions:c}=(0,ed.y)({watchOptionsCategories:r||[],preferredProviderIds:o});return a?(0,i.jsx)(eg,{"data-testid":"loader-container",children:(0,i.jsx)(l.Loader,{})}):r&&0!==r.length?(0,i.jsx)(i.Fragment,{children:c.map(e=>(0,i.jsx)(el,{titleId:t,category:e.categoryName.value,watchOptions:e.watchOptions,refMarker:n},e.categoryName.value))}):(0,i.jsx)(ev,{title:d.formatMessage({id:"error_emptyStates_watchOptions_title",defaultMessage:"Watch Options are currently unavailable"}),message:d.formatMessage({id:"error_common_refreshOrTryAgain",defaultMessage:"Please refresh the page or try again later."})})},ep=n()`
    fragment WatchOptionCategories on CategorizedWatchOptions {
        categoryName {
            value
            language
        }
        watchOptions {
            title {
                value
                language
            }
            link(platform: WEB)
            shortTitle {
                value
                language
            }
            description {
                value
                language
            }
            provider {
                id
                name {
                    value
                    language
                }
                logos {
                    icon {
                        url
                        height
                        width
                    }
                }
                refTagFragment
            }
        }
    }
`;ec.fragments={watchOptionsCategories:ep};let eg=d.ZP.div.withConfig({componentId:"sc-f7ff5283-0"})(["align-items:flex-start;display:flex;height:100%;margin:3rem 0;justify-content:center;"]),eu=d.ZP.div.withConfig({componentId:"sc-f7ff5283-1"})(["",""],(0,c.setTypographyType)("body")),ef=d.ZP.div.withConfig({componentId:"sc-f7ff5283-2"})([""," "," text-transform:none;font-size:13px;margin:0;padding:13px 0 7px 15px;","{padding:13px 0 7px;}"],(0,c.setTypographyType)("overline"),(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-accent1-color"),c.mediaQueries.breakpoints.above.m),em=(0,d.ZP)(l.ListItem).withConfig({componentId:"sc-f7ff5283-3"})(["&:first-of-type{border-top:1px solid rgba(",",0.1);}border-bottom:1px solid rgba(",",0.1);height:4rem;","{padding:0;}"],(0,c.getColorVarValue)("ipt-base-rgb"),(0,c.getColorVarValue)("ipt-base-rgb"),c.mediaQueries.breakpoints.above.m),eh=d.ZP.div.withConfig({componentId:"sc-f7ff5283-4"})(["display:flex;"]),ex=(0,d.ZP)(l.PhotoImage).withConfig({componentId:"sc-f7ff5283-5"})(["min-width:","px;margin-top:auto;margin-bottom:auto;margin-right:0.5rem;border-radius:0.25rem;"],50),eT=d.ZP.div.withConfig({componentId:"sc-f7ff5283-6"})(["margin-top:auto;margin-bottom:auto;"]),eb=d.ZP.div.withConfig({componentId:"sc-f7ff5283-7"})(["",""],(0,c.setTypographyType)("subtitle")),ey=d.ZP.div.withConfig({componentId:"sc-f7ff5283-8"})([""," "," ","{max-width:260px;}"],(0,c.setPropertyToColorVar)("color","ipt-on-baseAlt-textHint-color"),(0,c.setTypographyType)("bodySmall"),c.mediaQueries.breakpoints.above.m),ev=(0,d.ZP)(y.G).withConfig({componentId:"sc-f7ff5283-9"})([""," background:initial;"],(0,c.setTypographyType)("body")),eP=n()`
    fragment BaseTitlePrompt__WatchOptions on Title {
        id
        watchOptionsByCategory(location: $location) @skip(if: $isProPage) {
            categorizedWatchOptionsList {
                ...WatchOptionCategories
            }
        }
    }
    ${ep}
`,e_=e=>{let{data:t}=e,{value:r}=(0,j.Lz)(),a=t?.user?.preferredStreamingProviders?(0,en.H)({preferredStreamingProviders:t.user.preferredStreamingProviders}):[],n=(0,ea.L)({preferredServiceIds:a});if(!t)return null;let o=t.watchOptionsByCategory?.categorizedWatchOptionsList,s=o&&o.length>0;return(0,i.jsxs)(i.Fragment,{children:[!!n&&(0,i.jsx)(eI,{refSuffix:[j.Cd.BUTTON],"data-testid":P.z7.SET_PREFERRED_SERVICES,preferredServicesIds:a}),!!s&&(0,i.jsx)(ec,{titleId:t.id,watchOptionsCategories:o,preferredProviderIds:a,refMarker:{prefix:r}})]})},eI=(0,d.ZP)(ei.Z).withConfig({componentId:"sc-699ac8f9-0"})(["margin:"," 0;"],c.spacing.xxs),ew=n()`
    fragment BaseTitlePromptShared on Title {
        id
        plot {
            plotText {
                plainText
            }
        }
        productionStatus {
            currentProductionStage {
                id
                text
            }
        }
        ...BaseTitlePrompt__Track
        ...BaseTitlePrompt__Trailer
        ...BaseTitlePrompt__WatchOptions
    }
    ${J}
    ${eP}
    ${K}
`,eC=n()`
    query Base_Title_Prompt(
        $id: ID!
        $location: WatchOptionsLocation
        $isProPage: Boolean!
        $includeUserPreferredServices: Boolean! = false
        $includeBoxOfficeData: Boolean!
    ) {
        title(id: $id) {
            ...BaseTitlePromptShared
        }
        boxOffice: title(id: $id) @include(if: $includeBoxOfficeData) {
            ...Title_BoxOffice
        }
        user @include(if: $includeUserPreferredServices) {
            ...UserPreferredServices
        }
    }
    ${ew}
    ${g.R}
    ${p.j}
`,eS=e=>{let{titleId:t,pause:r=!1,queryOverride:i}=e,a=(0,h.ic)(),n=(0,f.ik)(),o=(0,u.nu)(),s=(0,b.hg)({weblabID:T.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}})&&!n&&o,d=n&&o,[l,c]=(0,m.E)({query:eC,variables:{id:t,location:a,isProPage:n,includeUserPreferredServices:s,includeBoxOfficeData:d},context:{serverSideCacheable:!1,personalized:n||s},pause:r,...i});return[l,c]},eR=e=>{let{title:t,baseTitlePromptData:r,onClose:a,isOpen:n,queryOverride:o,contentOverride:d,actionOverride:c}=e,p=(0,s.Z)(),g=(0,f.ik)(),[u,m]=eS({titleId:t?.id||"",pause:!!r||!t||!n,queryOverride:o});if(!t||!t.titleText?.text)return null;let h=r?.title??u.data?.title,x=r?.user??u.data?.user,T=u.data?.boxOffice,b=u.fetching,I=u.error,w=h?.productionStatus?.currentProductionStage.id,C=h?.productionStatus?.currentProductionStage.text,S=w&&C&&w!==P.gA;return(0,i.jsx)(ek,{onCloseClicked:a,baseColor:g?"base":"baseAlt",isOpen:n,closePromptLabel:p.formatMessage(P.TY.closePrompt),children:(0,i.jsxs)(ej,{children:[(0,i.jsx)(A,{titleData:t}),!!b&&(0,i.jsx)(v.lI,{height:"feature"}),!b&&(0,i.jsxs)(i.Fragment,{children:[!!h?.plot?.plotText?.plainText&&(0,i.jsx)(eO,{children:h.plot.plotText.plainText}),!!S&&(0,i.jsx)(eA,{"data-testid":P.z7.PRODUCTION_STATUS,children:C}),!!d&&d(u?.data||{}),!!g&&!!T&&(0,i.jsx)(G,{data:T}),(0,i.jsxs)(eE,{children:[!c&&!g&&!!h&&(0,i.jsx)(ee,{data:h}),!!g&&(0,i.jsx)(_.a,{title:t}),!g&&(0,i.jsx)(er,{titleId:t.id}),!!g&&!!h&&(0,i.jsx)(X,{data:h}),!!c&&c(u?.data||{})]}),!g&&!!h&&(0,i.jsx)(e_,{data:{...h,user:x}})]}),!b&&!!I&&(0,i.jsx)(y.G,{title:p.formatMessage({id:"error_common_sorryTryAgain",defaultMessage:"Sorry, there was an error. Please try again."}),displayType:"compact",action:(0,i.jsx)(l.TextLink,{onClick:()=>m(),text:p.formatMessage({id:"common_buttons_retry",defaultMessage:"Try again"}),"data-testid":P.z7.RETRY})})]})})},ej=d.ZP.div.withConfig({componentId:"sc-f3a43855-0"})(["padding-bottom:",";"],c.spacing.l),eE=d.ZP.div.withConfig({componentId:"sc-f3a43855-1"})(["display:flex;margin-bottom:",";padding-left:",";padding-right:",";","{padding-left:0;padding-right:0;}& > :nth-child(1):not(:last-child){margin-right:",";}"],c.spacing.xs,c.spacing.s,c.spacing.s,c.mediaQueries.breakpoints.above.m,c.spacing.xs),eO=d.ZP.div.withConfig({componentId:"sc-f3a43855-2"})([""," margin-bottom:",";padding-left:",";padding-right:",";","{padding-left:0;padding-right:0;}"],(0,x.S)(4),c.spacing.s,c.spacing.s,c.spacing.s,c.mediaQueries.breakpoints.above.m),ek=(0,d.ZP)(l.Prompt).withConfig({componentId:"sc-f3a43855-3"})(["",""],(0,c.setTypographyType)("bodySmall")),eA=d.ZP.div.withConfig({componentId:"sc-f3a43855-4"})(["margin:",";","{margin-left:0;margin-right:0;}"],c.spacing.s,c.mediaQueries.breakpoints.above.m)},4649:function(e,t,r){r.d(t,{a:function(){return c}});var i=r(52322),a=r(2784),n=r(53665),o=r(88169),s=r(63370),d=r(96557),l=r(35223);let c=e=>{let{title:t}=e,r=(0,n.Z)(),c=(0,s.K)({originalTitleText:t?.originalTitleText,titleText:t?.titleText}),[p,g]=(0,a.useState)(!1);return t&&c?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(o.SecondaryButton,{width:"full-width",preIcon:"playlist-add-check","data-testid":l.z7.ADD_TO_LIST,onSelect:()=>g(!0),children:r.formatMessage(l.TY.addToList)}),(0,i.jsx)(d.Z,{constId:t.id,primaryImage:t.primaryImage,primaryText:c,imageType:"name",isOpen:p,onClose:()=>{g(!1)}})]}):null}},45274:function(e,t,r){r.d(t,{j:function(){return n}});var i=r(30382),a=r.n(i);let n=a()`
    fragment Title_BoxOffice on Title {
        id
        titleType {
            id
        }
        productionBudget {
            budget {
                amount
                currency
            }
        }
        lifetimeGross(boxOfficeArea: DOMESTIC) {
            total {
                amount
                currency
            }
        }
        openingWeekendGross(boxOfficeArea: DOMESTIC) {
            gross {
                total {
                    amount
                    currency
                }
            }
            weekendEndDate
        }
        worldwideGross: lifetimeGross(boxOfficeArea: WORLDWIDE) {
            total {
                amount
                currency
            }
        }
    }
`},15323:function(e,t,r){r.d(t,{AO:function(){return c},UJ:function(){return g},pM:function(){return u},yK:function(){return p}});var i=r(53665);let a={id:"title_main_boxoffice_estimated",defaultMessage:"{budget} (estimated)"},n={id:"title_main_boxoffice_budget",defaultMessage:"Budget"},o={id:"title_main_boxoffice_grossdomestic",defaultMessage:"Gross US & Canada"},s={id:"title_main_boxoffice_openingweekenddomestic",defaultMessage:"Opening weekend US & Canada"},d={id:"title_main_boxoffice_cumulativeworldwidegross",defaultMessage:"Gross worldwide"},l=(e,t)=>{let r=(0,i.Z)();if(e&&t)return r.formatNumber(e,{style:"currency",currency:t,minimumFractionDigits:0})},c=e=>{let t=(0,i.Z)(),r=l(e?.budget.amount,e?.budget.currency);if(r)return{label:n,props:{listContent:[{text:t.formatMessage(a,{budget:r})}],"data-testid":"title-boxoffice-budget"}}},p=e=>{let t=l(e?.total.amount,e?.total.currency)??"";if(e)return{label:o,props:{listContent:[{text:t}],"data-testid":"title-boxoffice-grossdomestic"}}},g=e=>{let t=(0,i.Z)(),r=l(e?.gross.total.amount,e?.gross.total.currency)??"";if(e)return{label:s,props:{listContent:[{text:r},{text:t.formatDate(e?.weekendEndDate,{year:"numeric",month:"short",day:"numeric",timeZone:"UTC"})}],"data-testid":"title-boxoffice-openingweekenddomestic"}}},u=e=>{let t=l(e?.total.amount,e?.total.currency)??"";if(e)return{label:d,props:{listContent:[{text:t}],"data-testid":"title-boxoffice-cumulativeworldwidegross"}}}},73078:function(e,t,r){var i=r(52322);r(2784);var a=r(27722),n=r(86704),o=r(75824),s=r(41174),d=r(66724),l=r(31643);t.Z=e=>{let{refSuffix:t,"data-testid":r,preferredServicesIds:c,className:p}=e,g=(0,s.nu)(),{preferencesPreferredServicesLinkBuilder:u}=(0,d.WOb)(),f=g&&(!c||c&&c.length>0),m=(0,o.N)(f?l.T.editPreferredServicesButtonText:l.T.setYourPreferredServicesButtonText);return(0,i.jsx)(a.TextButton,{alignContent:"left",href:u({refSuffix:t}),preIcon:f?n.ICONS.EDIT:n.ICONS.SETTINGS,"data-testid":r,ariaLabel:m,className:p,children:m})}},31643:function(e,t,r){r.d(t,{T:function(){return a},u:function(){return i}});let i="PREFERRED",a={editPreferredServicesButtonText:{id:"userPreferredServices_edit_preferred_services",defaultMessage:"Edit preferred services"},setYourPreferredServicesButtonText:{id:"userPreferredServices_set_your_preferred_services",defaultMessage:"Set your preferred services"}}},4958:function(e,t,r){r.d(t,{y:function(){return n}});var i=r(2784),a=r(31643);let n=e=>{let{watchOptionsCategories:t,preferredProviderIds:r}=e;return{organizedWatchOptions:(0,i.useMemo)(()=>{if(!t||0===t.length)return[];let e=Object.fromEntries(r.map((e,t)=>[e,t])),i=new Map;t.forEach(e=>{e.watchOptions.forEach(t=>{let n=r.includes(t.provider.id)?a.u:e.categoryName.value;i.has(n)||i.set(n,{categoryName:{value:n},watchOptions:[]}),i.get(n).watchOptions.push(t)})});let n=Array.from(i.values());return n.forEach(t=>{t.watchOptions.sort((t,r)=>(e[t.provider.id]??1/0)-(e[r.provider.id]??1/0))}),n.sort((e,t)=>e.categoryName.value===a.u?-1:t.categoryName.value===a.u?1:0)},[t,r])}}},28160:function(e,t,r){r.d(t,{L:function(){return o}});var i=r(41174),a=r(83163),n=r(48687);let o=e=>{let{preferredServiceIds:t}=e,r=(0,i.nu)();return(0,n.hg)({weblabID:a.lh.IMDB_NEXT_USER_PREFERRED_SERVICES_INITIAL_1245110,treatments:{T1:!0}})&&(!r||r&&0===t.length)}},42712:function(e,t,r){r.d(t,{R:function(){return n}});var i=r(30382),a=r.n(i);a()`
    fragment WatchProviders on WatchProviderConnection {
        pageInfo {
            hasNextPage
            endCursor
        }
        edges {
            node {
                id
                isPopular
                isSupported(platform: WEB)
                logos {
                    icon {
                        height
                        width
                        url
                    }
                }
                name {
                    value
                }
                description {
                    value
                }
            }
        }
    }
`;let n=a()`
    fragment UserPreferredServices on User {
        preferredStreamingProviders(first: 100) {
            streamingProviders {
                edges {
                    node {
                        id
                    }
                }
            }
        }
    }
`},85591:function(e,t,r){r.d(t,{H:function(){return i}});let i=e=>e?(e?.preferredStreamingProviders.streamingProviders.edges||[]).map(e=>e.node.id):[]},14911:function(e,t,r){r.d(t,{Z:function(){return h}});var i=r(14438),a=r(25291),n=r.n(a),o=r(22431),s=r(22873);let d=(e,t)=>{let r;if(!t||(window.ad_utils&&(r=window.ad_utils.responsiveAdAPI.getLastAdResponse()),null===r))return Promise.resolve();let i=l(e),a=l(r);if(!c(i,a))return Promise.resolve();let n=a.clickTrackers;return Array.isArray(n)?p(n):Promise.resolve()},l=(e,t)=>{let r=e&&e.slots?e.slots[o.A.PROMOTED_WATCH_BAR]:null;if((0,s.M2)(r)||!(r&&r.slotMarkup))return null;let i=r.slotMarkup;try{return JSON.parse(i)}catch(e){return t&&t("There was an error decoding PWB ad response",e),null}},c=(e,t)=>!!e&&!!t&&e.providerId===t.providerId,p=e=>{let t=[];return e.forEach(e=>{t.push(u(e).catch(t=>console.error("Error when trying to fire tracker : "+e,t)))}),Promise.all(t)};n()(function(e,t){return g(e,t)});let g=(e,t)=>{let r=l(e),i=l(t);if(!c(r,i))return Promise.resolve();let a=i.impressionTrackers;return Array.isArray(a)?p(a):Promise.resolve()},u=e=>new Promise((t,r)=>{let i=new Image;i.addEventListener("load",()=>t(i)),i.addEventListener("error",e=>r(e)),i.src=e}),f=/[^a-zA-Z0-9]/g,m=e=>{let{watchTitleId:t,refMarker:r,watchOption:i,logOffsiteRef:a,adSlotsInfo:n}=e;return()=>{let e=i.provider?.refTagFragment?.replace(f,"").substring(0,12);a({refMarkerString:r,pageAction:e?`watch-${t}-${e}`:`watch-${t}`}),i.promoted&&n&&d(n,i.promoted)}},h=()=>{let e=(0,i.z7)();return t=>{let{titleId:r,watchOption:a,refMarker:n,adSlotsInfo:o}=t,s=n?.prefix?`${n.prefix}_`:"",d=n?.suffix?`_${n.suffix}`:"",l=a.provider?.refTagFragment?`${s}${a.provider.refTagFragment}${d}`:"",c=a.provider?.refTagFragment?`${s}${a.provider.refTagFragment}`:"",p=a.link.startsWith("/"),g=-1!==a.link.indexOf("imdb.com"),u=!p&&!g;return{href:(0,i.jo)(a.link,c),onClick:m({watchTitleId:r,refMarker:l,watchOption:a,logOffsiteRef:e,adSlotsInfo:o}),postIcon:u?"launch":void 0,postIconName:u?"launch":void 0,target:"_blank"}}}}}]);